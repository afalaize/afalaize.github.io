# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 17:35:49 2015

@author: Falaize
"""


def Impact_Energy(rhod, nk, label=''):
    scalar_product = lambda l1, l2: sum([el1*el2 for (el1, el2) in zip(l1, l2)])
    DtHb = map( lambda dtx,dxh: scalar_product(dtx[:2*nk], dxh[:2*nk]), rhod.seq_dtx, rhod.seq_dxH)
    DtHh = map( lambda dtx,dxh: scalar_product(dtx[-2:], dxh[-2:]), rhod.seq_dtx, rhod.seq_dxH)    
    Pdmeca = map( lambda w, z: scalar_product(w[:nk] + w[-1:], z[:nk] + z[-1:]), rhod.seq_w, rhod.seq_z)
    
    ncontact = [e[-1] >0 for e in rhod.seq_x].index(True)
    nendcontact = ncontact+1+[e[-1] <0 for e in rhod.seq_x[ncontact+1:]].index(True)
    nmin = ncontact  # N_duree_Fin+N_time_Fin+20
    nmax = nendcontact
    
    tplot = rhod.seq_t[nmin:nmax]
    DtHh = DtHh[nmin:nmax]
    DtHb = DtHb[nmin:nmax]
    Pdmeca = Pdmeca[nmin:nmax]
    
    import numpy as np
    Te = rhod.fs**-1
    Hh = np.array(map(lambda x: x*Te,DtHh)).cumsum()
    Hb = np.array(map(lambda x: x*Te,DtHb)).cumsum()
    Ed = np.array(map(lambda x: x*Te,Pdmeca)).cumsum()
    
    Hb_end_impact = Hb[-1]
    
    datax = tplot
    datay = [Hb, Ed, Hh, Hh+Hb+Ed]
    labels = [r'$\mathcal{E}_{\mathtt{b}}$',
             r'$\mathcal{E}_{\mathtt{diss}}$', 
             r'$\mathcal{E}_{\mathtt{h}}$',
             r'$\Delta\mathcal{E}$',
             ]
    
    import pp    
    pp = pp.pp_singleplot
    pp.update({'filelabel':'Impact_Energy'+label, 'labels':labels, 'unitx':r'time $t$ (s)', 'unity':r'(J)', 'loc':3, 
    'axedef': (0.19, 0.15, 0.77, 0.8), 'minor':False, 'linestyles':['--r', '-.g', ':c', '-b']})
    from utils.plots import singleplot
    singleplot(datax, datay, **pp)

    DtHb = map( lambda dtx,dxh: sum([e1*e2 for (e1,e2) in zip(dtx[:2*nk], dxh[:2*nk])]),rhod.seq_dtx, rhod.seq_dxH)
    DtHh = map( lambda dtx,dxh: sum([e1*e2 for (e1,e2) in zip(dtx[2*nk+2:], dxh[2*nk+2:])]),rhod.seq_dtx, rhod.seq_dxH)
    
    Pdmeca = map( lambda w, z: sum([e1*e2 for (e1,e2) in zip([w[el] for el in range(nk)+[nk+1]], [z[el] for el in range(nk)+[nk+1]])]), rhod.seq_w, rhod.seq_z)
    
    ncontact = [e[-1]>0 for e in rhod.seq_x].index(True)

    nmin = nmax
    nmax = rhod.nt
    
    tplot = rhod.seq_t[nmin:nmax]
    DtHh = DtHh[nmin:nmax]
    DtHb = DtHb[nmin:nmax]
    Pdmeca = Pdmeca[nmin:nmax]
    
    Te = rhod.fs**-1
    Hb = np.array(map(lambda x: x*Te,DtHb)).cumsum()
    Ed = np.array(map(lambda x: x*Te,Pdmeca)).cumsum()
    
    datax = tplot
    datay = [Hb_end_impact+Hb, Ed, Hb+Ed]
    labels = [r'$\mathcal{E}_{\mathtt{b}}$',
             r'$\mathcal{E}_{\mathtt{diss}}$',
             r'$\Delta\mathcal{E}$',
             ]
    
    import pp    
    pp = pp.pp_singleplot
    pp.update({'filelabel':'Beam_Energy'+label, 'labels':labels, 'unitx':r'time $t$ (s)', 'unity':r'(J)', 'loc':1, 
    'axedef': (0.16, 0.15, 0.75, 0.75), 'minor':False, 'linestyles':['--r', '-.g', '-b']})
    from utils.plots import singleplot
    singleplot(datax, datay, **pp)

def electrical_powers(rhod, nk, label=''):
    DtHp = map( lambda dtx,dxh: sum([e1*e2 for (e1,e2) in zip(dtx[2*nk:2*nk+2], dxh[2*nk:2*nk+2])]),rhod.seq_dtx, rhod.seq_dxH)
    Pdp = map( lambda w, z: sum([e1*e2 for (e1,e2) in zip([w[el] for el in [nk]], [z[el] for el in [nk]])]),rhod.seq_w, rhod.seq_z)
    Psp = map( lambda u, y: sum([e1*e2 for (e1,e2) in zip([u[el] for el in [0,1]], [y[el] for el in [0,1]])]),rhod.seq_u, rhod.seq_y)
    
    ncontact = [e[-1] >0 for e in rhod.seq_x].index(True)
    nmin = ncontact + int(10.*rhod.fs/440)
    nmax = nmin +int(5.*rhod.fs/440)
    
    tplot = rhod.seq_t[nmin:nmax]
    DtHp = DtHp[nmin:nmax]
    Pdp = Pdp[nmin:nmax]
    Psp = Psp[nmin:nmax]
    
    deltaP = [(ele+eld-elp)/np.mean(Psp) for (ele, eld, elp) in zip(DtHp, Pdp, Psp)]
    datax = tplot
    datay = [DtHp, Pdp, Psp, deltaP]
    labels = [r'$\frac{\mathrm{d}\mathcal{E}_{\mathtt{p}}}{\mathrm{d} t}}$',
             r'$\mathcal{Q}_{\mathtt{p}}$',
             r'$\mathcal{P}_{\mathtt{p}}$',
             r'$\Delta\mathcal{P}_{\mathtt{p}}$',
             ]
    
    filelabel='electrical_powers'+label
    
    from utils.plots import multiplot
    from pp import pp_multiplot
    pp = pp_multiplot
    pp.update({'figsize':(12., 7.), 'legendfontsize':20, 'fontsize':20, 'axedef': (0.13, 0.1, 0.95, 0.9, 0.2, 0.3), 'filelabel':filelabel,'labels':labels, 'unitx':r'time $t$ (s)', 'unity':[r'(W)']*4, 'loc':1, 
    'minor':False, 'linestyles':['-b', '-.g', '-b']})
    multiplot(datax, datay, **pp)

def plot_signals(rhod, pars, label=''):
    vout = [e[1] for e in rhod.seq_y]
    import beam
    import numpy as np
    omegap = beam.Psi(pars['kmodes'], pars['L'], pars['relative_zp']*pars['L']) # Modal spatial distribution for the connection with the pickup
    vp = [ (np.matrix(omegap)*np.matrix(e[:nk]).T)[0,0] for e in rhod.seq_x]
    
    ncontact = [e[-1]+pars['lh']>0 for e in rhod.seq_x].index(True)
    nmin = ncontact + int(10.*rhod.fs/pars['f0'])
    nmax = nmin +int(5.*rhod.fs/pars['f0'])
    tplot = rhod.seq_t[nmin:nmax]
    
    data1 = vp[nmin:nmax]
    
    data2 = vout[nmin:nmax] #vp[nmin:nmax]

    datax = tplot
    datay = [data1,data2]
    
    
    from utils.plots import multiplot
    from pp import pp_multiplot
    
    pp = pp_multiplot
    
    pp.update({ 'filelabel': 'signals'+label,
     'labels': ['$q_p(t)$', '$v_0(t)$'],
     'unitx': 'time $t$ (s)',
     'unity': ['(m)', '(V)'],})
    
    multiplot(datax, datay, **pp)

import numpy as np
import sympy as sp
import pypHs

def font_lists():
    lis = list()
    lis.append(('serif', ['Times', 'Bitstream Vera Serif', 'New Century Schoolbook', 'Century Schoolbook L', 'Utopia', 'ITC Bookman', 'Bookman', 'Nimbus Roman No9 L', 'Times New Roman', 'Palatino', 'Charter', 'Computer Modern', 'serif'],))
    lis.append(('sans-serif', ['Bitstream Vera Sans', 'Lucida Grande', 'Verdana', 'Geneva', 'Lucid', 'Arial', 'Helvetica', 'Avant Garde', 'sans-serif'],))
    lis.append(('cursive', ['Apple Chancery', 'Textile', 'Zapf Chancery', 'Sand', 'Script MT', 'Felipa', 'cursive'],))
    lis.append(('fantasy', ['Comic Sans MS', 'Chicago', 'Charcoal', 'Impact', 'Western', 'Humor Sans', 'fantasy'],))
    lis.append(('monospace', ['Bitstream Vera Sans Mono', 'Andale Mono', 'Nimbus Mono L', 'Courier New', 'Courier', 'Fixed', 'Terminal', 'monospace'],))
    return lis
    
fontsize = 35
legendfontsize = 30
linewidth = 2.
def latex_preamble():
    # Path for latex compiler
    import os
    os.environ['PATH'] = os.environ['PATH'] + ':/usr/texbin'
    # Activate use of latex expressions
    from matplotlib.pyplot import rc
    rc('text', usetex=True)
    from matplotlib import rcParams    
    rcParams['text.latex.preamble'] = [' ', ]
#    [
#                                       r'\usepackage{siunitx}',   # i need upright \micro symbols, but you need...
#                                       r'\sisetup{detect-all}',   # ...this to force siunitx to actually use your fonts
#                                       r'\usepackage{helvet}',    # set the normal font here
#                                       r'\usepackage{sansmath}',  # load up the sansmath so that math -> helvet
#                                       r'\sansmath'               # <- tricky! -- gotta actually tell tex to use!
#                                       ]  
def Globalfont():
    font_properties = {'family': 'serif',
                        'weight' : 'normal',          
                        'variant':'small-caps',
                        'size' : fontsize}
    for fonts in font_lists():
        font_properties[fonts[0]] = fonts[1]
    return font_properties


###############################################################################
#%% Plots Parameters

figwidth = 10.
figheight_1 = 5.
figheight_2 = 10.
figheight_3 = 15.

left  = 0.17  # the left side of the subplots of the figure
right = 0.95    # the right side of the subplots of the figure
bottom = 0.15   # the bottom of the subplots of the figure
top = 0.9      # the top of the subplots of the figure
wspace = 0.2   # the amount of width reserved for blank space between subplots
hspace = 0.3  # the amount of height reserved for white space between subplots
axedef = [left , bottom, right, top, wspace, hspace]

def importOrReload(module_name, *names):
    import sys

    if module_name in sys.modules:
        reload(sys.modules[module_name])
    else:
        __import__(module_name, fromlist=names)

    for name in names:
        globals()[name] = getattr(sys.modules[module_name], name)

# use instead of: from TOOLS import MyPlot
importOrReload("TOOLS", "MyPlot")
# use instead of: from TOOLS import MyPlot2
importOrReload("TOOLS", "MyPlot2")
###############################################################################
#%% Physical parameters
import os
path_label = 'all440'
newpath = os.getcwd() + r'/' + path_label
if not os.path.exists(newpath): os.makedirs(newpath)
folder = newpath
nF=0

nF = range(1,9)
nF.reverse()

#%% Simulation parameters
fs = 48000. # [Hz] Sampling frequency
Te = 1./fs # [s] Sampling period
Duree = 5 # [s] Duration of the simulation
nt = int(Duree*fs) # [#] umber of time steps
t = np.arange(nt)*Te # [s] Vector of all the moments

allsig = [0,]*int(fs)

doplots = True
doexportwaves = True

automation_script = """
echo "Build release"
xcodebuild -project """ + '/Users/Falaize/Documents/THESE/LaTex/JSV_Rhodes/CODE_V2/all440/rhodes_xcode' + os.sep +  """rhodes_xcode.xcodeproj -alltargets -configuration Release

echo "Launch exe"
""" + '/Users/Falaize/Documents/THESE/LaTex/JSV_Rhodes/CODE_V2/all440/rhodes_xcode' +  os.path.sep + "build" + os.path.sep + "Release" + os.path.sep + 'rhodes_xcode'

#for Fin in [round(10000*e)/10000. for e in list(np.linspace(50,300,6))]:
for fin in [round(100*(e))/100. for e in list(np.linspace(0.3,0.9,8))]:
    for F0 in [1.,]:
#        for lp in [round(10000*e)/10000. for e in list(np.linspace(5e-4,5*1e-3,10))]:
        for lp in [round(10000*e)/10000. for e in [(1/(F0))*1e-3]]:
#            for dlp in [round(10000*e)/10000. for e in [0] + list(np.linspace(5e-4,2.5*1e-3,5))]:
            for dlp in [round(10000*e)/10000. for e in [-(2**(1/F0**0.7))*1e-4]]:
                # Beam
                f0 = F0*440; # [Hz] Natural frequency of the beam (without damping)
                alpha_b0 = 4.5**(F0)*1e-2 # [s] Decay for the eigenmodes of th ebeam
                E = 180*1e9 # [N/m**2] Young modulus of the Beam (steel = 180*1e9)
                m = 7750. # [kg/m**3] Mass density (steel = 7750)
                r = 1*1e-3 # [m] Radius of the cylinrical beam
                nkmax = 20. # [#] Maximum number of simulated eigen-modes
#%%                
                # HAMMER
                mh = 30*1e-3 # [kg] Mass of the hammer
                relative_zh = 0.1 # [%] relative position of the hammer w.r.t. the total length L of the beam
                alphah = 0.184 # [N.s/m] Felt damping coefficient
                beta = 2.5 # [#] Hysteresis coefficient for the felt
                wh = 1.5*1e-2 # [m] width of the contact with the beam
                lh = 1.5*1e-2 # [m] Height of the felt at rest
                kh = 5*1e5 # [N/m] Stiffness of the felt
                qh0 = -0.2 # [m] Initial position of the hammer measured w.r.t the beam at rest
                
                # PICKUP
#                lp = 0.002 # [m] vertical position of the pick-up w.r.t the beam at rest
            #    dlp = 0.002 # [m] vertical position of the pick-up w.r.t the beam at rest
                relative_zp = 1 # [%] relative position of the pickup along the beam
                fRLC = 5000. # [Hz] frequency of the resonnance for the RLC circuit 
                Cp = 330*1e-9 # [Farads] Capacitance
                R = 1000. # [Ohms] Resistance 
                Lc = 1/(Cp*(2*np.pi*fRLC)**2)# [Henries] Inductance
                Nturns = 100.
                Lc_mag = Lc/(Nturns**2)
                murel = 700.
                dmu = (murel - 1.)/(murel + 1.)
                mu0 = 1 # 4*np.pi*1e-7
                ap = 1e-3
                h0 = 1.
                i0 = 0.
            
                Fin = fin*1300**(F0**0.05) # [N] Initial force applied to the hammer
                qhmax = -0.05 - qh0
                duree_Fin = np.sqrt(qhmax * mh/Fin) # [s] Duration of the application of the force "Fin"
                time_Fin = 0.01 # [s] Initial time of application of the force "Fin"
            
                label_xp = 'f0' + str(f0) + '_lp' + str(lp) + '_dlp' + str(dlp) + '_Fin'+str(Fin)
                mm = nF.pop()
                label_xp = 'test'+str(int(mm))

                ###############################################################################
                
                #%% BEAM
                
                def TineLength(f0, r, m, E):
                    """
                    Return the lengths L of a cylindrical tine with radius r, mass densisty m
                    and Young's modulus E that corresponds to the fondamental frequency f0
                
                    Parameters
                    ----------
                    f0 : float 
                      Fondamental frequency of the vibrating cantilever beam (Hz)
                    
                    r : float
                        Radius of the beam (m)
                    
                    m : float
                        Volumetric densisty of mass for the chosen material of the
                        beam (kg/m**3)    
                        
                    E : float
                        Young's modulus for the chosen material of the beam (N/m**2)
                    
                    Returns
                    -------
                    L : float
                      Return the length of the tine (m)
                      
                    """
                    A = np.pi*r**2 # [m**2] Area of the cross section of the beam
                    I = np.pi*r**4/4. # [m**4] Moment of inertia of plane area for a section of the beam
                    k = np.sqrt(2*np.pi*np.sqrt(m*A/(E*I))*f0) # [1/m] Wave Numer associated to the first eigen-mode
                    L = np.linspace(0,1,10**6) # [m] A vector of Length
                    L = L[np.newaxis,:] # Add an axis to get L as a 2-dimensional array
                    Indexes = np.nonzero((np.abs(np.diff(np.sign(-1./np.cosh(k*L)-np.cos(k*L))))).flatten())[0] # [#] Index of length in L satisfying the eigen-modes cos(k*L)=-1./cosh(k*L)
                    return L[:,Indexes[0]][0] # [m] Corresponding length in L
                
                def ComputeWaveNumbers(nk,L):
                    """
                    Compute the wavenumbers for a cylindrical tine with length L
                
                    Parameters
                    ----------
                    nk : int
                      Number of returned wavenumbers
                    
                    L : float
                        Length of the tine (m)
                    
                    Returns
                    -------
                    k : array of floats
                      List of nk wavenumbers (1/m)
                      
                    """
                    nPeriods = nk/2. 
                    nPoints = nk*1e5 
                    k = np.linspace(0,nPeriods*2*np.pi/L, nPoints) # [1/m] A vector of wavenumners
                    k = k[np.newaxis,:] # Add an axis to get k as a 2-dimensional array
                    Indexes = np.nonzero((np.abs(np.diff(np.sign(-1./np.cosh(k*L)-np.cos(k*L))))).flatten())[0] # [#] Index of wavenumers in k satisfying the eigen-modes cos(k*L)=-1./cosh(k*L)
                    k = k[:,Indexes] # [m] Corresponding wavenumners in k
                    fk = (1./(2*np.pi))*np.sqrt(kappa/rho)*k**2 # [Hz] Frequencies corresponding to k
                    return k, fk
                    
                rho = m*np.pi*r**2. # [kg] Modal mass density 
                kappa = E*np.pi*r**4/4. # [N/m] Modal stiffness
                L = TineLength(f0,r,m,E) # [m] Tine length for the fondamental frequency f0[Hz]
                k, fk = ComputeWaveNumbers(nkmax,L) # [1/m] list of the nkmax first modes for the cantilever beam with length L
                k = k[(fk<fs/2).nonzero()] # [1/m] list of the nk first modes below the Nyquist frequency fe/2
                fk = fk[(fk<fs/2).nonzero()] # [Hz] list of the frequencies associated to the nk first modes
                print fk
                nk = k.shape[0] # [#] number of simulated modes
                alphab = list([alpha_b0*e for e in [e/list(kappa*k.flatten()**4)[0] for e in list(kappa*k.flatten()**4)]]) # [N/m**1] Modal damping coefficient
                ###############################################################################
                #%% Spatial distributions
                
                #HAMMER
                zh = wh+ relative_zh*(L-2*wh); # [m] position of the hammer
                omega = []
                for n in np.arange(nk):
                    kn = k[n]
                    kl = kn*L
                    term1 = np.sqrt(2)*(2*np.sin((kn*wh)/2)*(np.cos(kn*(L-zh))+np.cos(kn*zh)*np.cosh(kl)-np.sin(kn*zh)*np.sinh(kl))-2*np.sinh((kn*wh)/2)*(np.cosh(kn*(L-zh))+np.cos(kl)*np.cosh(kn*zh)+np.sin(kl)*np.sinh(kn*zh)))
                    term2 = np.sqrt(kn)*np.sqrt(kl*(-2+np.cos(2*kl))+kl*np.cosh(2*kl)-np.cosh(kl)*(2*np.sin(kl)+np.cosh(kl)*np.sin(2*kl)))    
                    omega.append(term1/term2)
                omega = np.array([omega]).T
                
                # PickUp
                def Psi(k, L, z):
                    a = (np.sqrt(2) *(np.sin(k*L)*(np.sin(k*z) - np.sinh(k* z)) -
                        np.sinh(k*(L - z))*np.tanh(k* L) +
                       np.sinh(k*L)*(-np.sin(k*z) + np.cos(k* z)*np.tanh(k*L))))
                    c =  ( 2.*np.sin(k*L) + np.cosh(k*L)*np.sin(2*k*L))
                    d = k * L *(-2 + np.cos(2* k*L) )
                    f = k* L * np.cosh(2*k*L)
                    b = (d + f - np.cosh(k*L)*c)/k
                    return a/np.sqrt(b)
                
                zp = relative_zp*L # [m] position of the pickup along the beam
                omegap = Psi(k,L,zp) # Modal spatial distribution for the connection with the pickup
                
                ###############################################################################
                #%%
                
#                import os
#                label = 'Rhodes'+label_xp
#                newpath = os.getcwd() + r'/' + label
#                if not os.path.exists(newpath): os.makedirs(newpath)
#                folder = newpath
                
                rhodes = pypHs.pHobj('rhodes', path=folder)
                
                # definition of x
                rhodes.AddLinearStorageComponents(map(lambda e: 'qb_'+str(e+1), np.arange(nk)),list(kappa*k.flatten()**4))
                rhodes.AddLinearStorageComponents(map(lambda e: 'rhoDtqb_'+str(e+1), np.arange(nk)),[rho**-1]*nk)
                rhodes.AddLinearStorageComponents(['q_C', 'phi_L'],[Cp**-1, Lc_mag**-1])
                rhodes.AddLinearStorageComponents(['mhDtqh'],[mh**-1])
                xnl = sp.symbols('qh')
                hnl = sp.Piecewise((0,xnl<0),((kh/(beta+1))*(xnl)**(beta+1), True))
                rhodes.AddNonLinearStorageComponents([xnl],hnl)
                
                # definition of w
                rhodes.AddLinearDissipativeComponents(map(lambda e: 'Dtqb_'+str(e+1), np.arange(nk)),list(alphab))
                rhodes.AddLinearDissipativeComponents(['ir'],[R])
                wh = sp.symbols('Dtq_h')
                f2 = sp.Piecewise((0,xnl<0),((1./beta)*(xnl)**(beta-1), True))
                Zh = alphah*f2*wh
                rhodes.AddNonLinearDissipativeComponents([wh],[Zh])
                
                # definition of y
                rhodes.AddPorts([sp.symbols('h_0'),sp.symbols('DtPhi_0')],[sp.symbols('i_0'),sp.symbols('v_e')])
                rhodes.AddPorts([sp.symbols('Fin')],[sp.symbols('v_h')])
                
                nx = 2*nk + 4
                nw = nk + 2
                ny = 3
                
                temp1 = sp.Matrix.hstack(sp.zeros(nk), sp.eye(nk))
                temp2 = sp.Matrix.hstack(-sp.eye(nk), sp.zeros(nk))
                
                Jb = sp.Matrix.vstack(temp1, temp2)
                
                Je = sp.Matrix([[0,1./Nturns],[-1./Nturns,0]])
                
                Jh = sp.Matrix([[0,-1],[1,0]])
                
                Jx = sp.diag(Jb,Je,Jh)
                
                temp1 = sp.Matrix.hstack(sp.zeros(nk,1), sp.zeros(nk,1))
                temp2 = sp.Matrix.hstack(sp.zeros(nk,1), sp.Matrix(omega))
                M = sp.Matrix.vstack(temp1, temp2)
                Jx[:2*nk, -2:] = M
                Jx[-2:,:2*nk] = -M.T
                
                Kb = sp.Matrix.vstack(sp.zeros(nk),sp.eye(nk))
                
                Ke = sp.Matrix([[0],[1/Nturns]])
                
                Kh = sp.Matrix([[1], [0]])
                
                K = sp.diag(Kb, Ke, Kh)
                K[nk:2*nk,-1] = -omega                
                
                xp = (sp.Matrix(omegap).T*sp.Matrix(rhodes.x[:nk]))[0,0]
                dtxp = (sp.Matrix(omegap).T*sp.Matrix(rhodes.x[nk:2*nk])/rho)[0,0]
                a1 = lambda xp: (-ap+dlp+xp)**2+lp**2
                a2 = lambda xp: (ap+dlp+xp)**2+lp**2
                f1 = 2*r**2*dmu*ap*( (a1(xp)-2*lp**2)/(a1(xp)**2)-(a2(xp)-2*lp**2)/(a2(xp)**2) )*dtxp              
                Gx = sp.zeros(nx, ny)
                Gx[2*nk,0] = 1
                Gx[2*nk+1, 1] = f1
                Gx[-2, 2] = 1
                
                Gw = sp.Matrix(np.zeros((rhodes.nw(), rhodes.ny())))
                
                Jw = sp.Matrix(np.zeros((rhodes.nw(), rhodes.nw())))
                
                Jy = sp.Matrix(np.zeros((rhodes.ny(), rhodes.ny())))
                
                rhodes.AddStructure(Jx,K,Gx,Jw,Gw,Jy)
                
                
                rhodes.Build(fs=fs, ExportCpp=False, simplify=False, parallelize=False, presolve=True)
                    
                    ###############################################################################
                #%% INPUT
                N_duree_Fin = int(fs*duree_Fin) # [#] number of time steps for the application of the force "Fin"
                N_time_Fin = int(fs*time_Fin) # [#] Index in "t" of the moment of application of the force "Fin"
                u = np.concatenate((np.zeros((1,N_time_Fin)),Fin*np.ones((1,N_duree_Fin)),
                                    np.zeros((1,nt-N_duree_Fin-N_time_Fin))),axis=1) # [N] Sequence of values of the input 
                
                SeqU = map(lambda x: [i0, h0, x], u[0])
                
                ###############################################################################
                #%%
                x0 = [0,]*rhodes.nx()
                x0[-1] = qh0
                
                rhodes.simulation(48e3, seq_u=SeqU, x0=x0, build=False, language='py', exec_script=automation_script)

                Impact_Energy(rhodes, nk, label=label_xp)
                electrical_powers(rhodes, nk, label=label_xp)
                
                #%%
                scalar_product = lambda l1, l2: sum([el1*el2 for (el1, el2) in zip(l1, l2)])
                Pdbeam = map(lambda lw, lz: scalar_product(lw[:nk], lz[:nk]), rhodes.seq_w, rhodes.seq_z)
                Pdelec = map(lambda lw, lz: lw[nk]*lz[nk], rhodes.seq_w, rhodes.seq_z)
                Pdham = map(lambda lw, lz: lw[-1]*lz[-1], rhodes.seq_w, rhodes.seq_z)
                ###############################################################################
                #%%
                from matplotlib.pyplot import rc, plot, xlim, ylim, suptitle, savefig, ylabel, legend, xlabel,close, figure, subplots, subplot, grid
                from struct import pack
                import wave
                
                #close('all')
                close('all')
                vout = [e[0] for e in rhodes.seq_y]
                allsig  += vout
                pos = [ (np.matrix(omegap)*np.matrix(e[:nk]).T)[0,0] for e in rhodes.seq_x]
                vit = [ (np.matrix(omegap)*np.matrix(e[nk:2*nk]).T)[0,0] for e in rhodes.seq_x]

                if doexportwaves:
                    ## GENERATE MONO FILE ##
                    wv = wave.open(folder + '/vout_'+label_xp +'.wav', 'w')
                    wv.setparams((1, 2, fs, 0, 'NONE', 'not compressed'))
                    maxVol=2**15-1.0 #maximum amplitude
                    Normalisation = np.max(np.abs(vout))
                    wvData=""
                    for i in range(0, nt):
                            wvData+=pack('h', int(maxVol*vout[i]/Normalisation))
                    wv.writeframes(wvData)
                    wv.close()
                    
                    ## GENERATE MONO FILE ##
                    wv = wave.open(folder + '/pos_'+label_xp+'.wav', 'w')
                    wv.setparams((1, 2, fs, 0, 'NONE', 'not compressed'))
                    maxVol=2**15-1.0 #maximum amplitude
                    Normalisation = np.max(np.abs(pos))
                    wvData=""
                    for i in range(0, nt):
                            wvData+=pack('h', int(maxVol*pos[i]/Normalisation))
                    wv.writeframes(wvData)
                    wv.close()
    
                    ## GENERATE MONO FILE ##
                    wv = wave.open(folder + '/vit_'+label_xp+'.wav', 'w')
                    wv.setparams((1, 2, fs, 0, 'NONE', 'not compressed'))
                    maxVol=2**15-1.0 #maximum amplitude
                    Normalisation = np.max(np.abs(vit))
                    wvData=""
                    for i in range(0, nt):
                            wvData+=pack('h', int(maxVol*vit[i]/Normalisation))
                    wv.writeframes(wvData)
                    wv.close()
                    
                    from matplotlib.ticker import ScalarFormatter
                    from matplotlib.pyplot import setp, close
                    from matplotlib import cm
                    import numpy as np
                    close('all')
                    figure()
                    axedef = [0.17 , 0.12, 0.95, 0.95, 0., 0.2]
                    
                    figsize = (12,10)
                    
                    xpos_ylabel = -0.15
                    
                    rc('font', **Globalfont())
                    majorformatter = ScalarFormatter(useOffset=False)
                    fig, (ax1, ax2, ax3) = subplots(3,1, figsize=figsize)
                
                    nPeriods = 5
                    dsig = [np.abs(ex-ey) for (ex, ey) in zip(pos[1:], pos[:-1])]
                    n0 = list(np.abs(dsig)).index(np.max(np.abs(dsig)))
                    nmin = n0 +int(5*fs/f0)
                    nmax = nmin + int(nPeriods/f0*fs)
                
                    tplot = t[nmin:nmax]

#                    locator = AutoLocator(nbins=6)
                    
                    ax1.plot(tplot, pos[nmin:nmax], label=r'$q_\mathrm{p}(t)$', linewidth=linewidth)        
                    ax1.set_xlim([tplot[0], tplot[-1]])
                    ax1.yaxis.set_major_formatter(majorformatter)
#                    ax1.yaxis.set_major_locator(locator)
                    ax1.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
                    ax1.set_ylabel(r'Pos. (m)')
                    ax1.grid('on')
                    ax1.legend(loc=1, fontsize=fontsize)
                    ax1.yaxis.set_label_coords(xpos_ylabel, 0.5)
                    setp(ax1.get_xticklabels(), visible=False)
                    ax1.locator_params(axis='y',nbins=6)

                    ax2.plot(tplot, vit[nmin:nmax], label=r'$\dot{q}_\mathrm{p}(t)$', linewidth=linewidth)
                    ax2.set_xlim([tplot[0], tplot[-1]])
                    ax2.yaxis.set_major_formatter(majorformatter)
#                    ax2.yaxis.set_major_locator(locator)
                    ax2.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
                    ax2.grid('on')
                    ax2.legend(loc=1, fontsize=fontsize)
                    ax2.set_ylabel(r'Vel. (m.s$^{-1}$)')
                    ax2.yaxis.set_label_coords(xpos_ylabel, 0.5)
                    setp(ax2.get_xticklabels(), visible=False)
                    ax2.locator_params(axis='y',nbins=6)

                    ax3.plot(tplot, vout[nmin:nmax], label=r'$\upsilon_0(t)$', linewidth=linewidth)
                    ax3.set_xlim([tplot[0], tplot[-1]])
                    ax3.yaxis.set_major_formatter(majorformatter)
                    ax3.xaxis.set_major_formatter(majorformatter)
#                    ax3.yaxis.set_major_locator(locator)
                    ax3.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
                    ax3.ticklabel_format(axis='x', style='sci', scilimits=(-2, 2))
                    ax3.set_ylabel(r'Out. (V)')
                    ax3.yaxis.set_label_coords(xpos_ylabel, 0.5)
                    ax3.grid('on')
                    ax3.legend(loc=1, fontsize=fontsize)
                    ax3.set_xlabel(r'Time (s)')
                    ax3.locator_params(axis='y',nbins=6)
                    
                    left  = axedef[0]  # the left side of the subplots of the figure
                    right = axedef[2]    # the right side of the subplots of the figure
                    bottom = axedef[1]   # the bottom of the subplots of the figure
                    top = axedef[3]      # the top of the subplots of the figure
                    wspace = axedef[4]   # the amount of width reserved for blank space between subplots
                    hspace = axedef[5]   # the amount of height reserved for white space between subplots
                    fig.subplots_adjust(left=left, right=right, bottom=bottom, top=top, wspace=wspace, hspace=hspace)   

                    savefig(folder+'/Sigs'+str(mm)+'.png')    

#%%                    
                if doplots:
#                    close('all')
#                    nPeriods = 10.
#                    
#                    dsig = [np.abs(ex-ey) for (ex, ey) in zip(pos[1:], pos[:-1])]
#                    n0 = list(np.abs(dsig)).index(np.max(np.abs(dsig)))-int(1/f0*Fe)
#                    nmin = n0 +int(5*Fe/f0)
#                    nmax = nmin + int(nPeriods/f0*Fe)
#                                
#                    tplot = t[nmin:nmax]
#                    unittime = r'time $t$ (s)'
#                    
#                    data1 = pos[nmin:nmax]
#                    label1 = r'$q_p(t)$'
#                    unity1 = r'(m)'
#                    lims1 = None
#                    
#                    data2 = vout[nmin:nmax] #vp[nmin:nmax]
#                    #label2 = r'$\frac{d q_h}{d t}(t)$'
#                    label2 = r'$v_0(t)$'
#                    unity2 = r'(V)'
#                    lims2 = None
#                    
#                    maintitle = 'Displacement $q_p$ and output signal $v_0$ ($f_h='+str(Fin)+'$N)'
#                    filelabel = folder + '/'+label_xp+'displacement_vout'
#                    axedef = [0.15 , 0.15, right, 0.85, wspace, 0.3]
#                    figsize = (10,7)
#                    
#                    datax = [tplot,tplot]
#                    datay = [data1,data2]
#                    label = [label1,label2]
#                    unitx = [unittime,unittime]
#                    unity = [unity1,unity2]
#                    limits = [lims1,lims2]
#                    MyPlot(datax, datay, label, unitx, unity, limits, fontsize=fontsize, axedef=axedef, \
#                                legendfontsize=legendfontsize, linewidth=linewidth, figsize=figsize, ncol=1, \
#                                filelabel=filelabel, maintitle=maintitle, loc=4)
#    #%%
#                    close('all')
#                    
#                    dsig = [np.abs(ex-ey) for (ex, ey) in zip(sig[1:], sig[:-1])]
#                    n0 = list(np.abs(dsig)).index(np.max(np.abs(dsig)))
#                    nminref = n0 +int(5*Fe/f0)
#                    nmaxref = nminref + int(nPeriods/f0*Fe)
#                    data1 = sig[nminref:nmaxref]
#                    
#                    dsig = [np.abs(ex-ey) for (ex, ey) in zip(vout[1:], vout[:-1])]
#                    n0 = list(np.abs(dsig)).index(np.max(np.abs(dsig)))
#                    nminsim = n0 +int(5*Fe/f0)
#                    nmaxsim = nminsim + int(nPeriods/f0*Fe)
#                    
#                    tplot = t[nminsim:nmaxsim]
#                    unittime = r'time $t$ (s)'
#                    
#                    label1 = r'ref.'
#                    unity1 = r'(1)'
#                    lims1 = None
#                    
#                    data2 = vout[nminsim:nmaxsim] #vp[nmin:nmax]
#                    #label2 = r'$\frac{d q_h}{d t}(t)$'
#                    label2 = r'sim.'
#                    unity2 = r'(1)'
#                    lims2 = None
#                    
#                    maintitle = 'Comparison with the reference ($f_h='+str(Fin)+'$N)'
#                    filelabel = folder+'/compârison1' + label_xp
#                    axedef = [0.15 , 0.15, right, 0.85, wspace, 0.3]
#                    figsize = (10,7)
#                    
#                    datax = [tplot,tplot]
#                    datay = [data1,data2]
#                    label = [label1,label2]
#                    unitx = [unittime,unittime]
#                    unity = [unity1,unity2]
#                    limits = [lims1,lims2]
#                    
#                    MyPlot(datax, datay, label, unitx, unity, limits, fontsize=fontsize, axedef=axedef, \
#                                legendfontsize=legendfontsize, linewidth=linewidth, figsize=figsize, ncol=1, \
#                                filelabel=filelabel, maintitle=maintitle, loc=1)
#    
#                    #%%
#                    close('all')
#                    figure()
#    
#                    data1 = sig[nminref+int(Fe):nmaxref+int(Fe)]
#                    tplot = t[nminsim+int(Fe):nmaxsim+int(Fe)]
#                    unittime = r'time $t$ (s)'
#                    
#                    label1 = r'ref.'
#                    unity1 = r'(1)'
#                    lims1 = None
#                    
#                    data2 = vout[nminsim+int(Fe):nmaxsim+int(Fe)] #vp[nmin:nmax]
#                    #label2 = r'$\frac{d q_h}{d t}(t)$'
#                    label2 = r'sim.'
#                    unity2 = r'(1)'
#                    lims2 = None
#                    maintitle = 'Comparison with the reference ($f_h='+str(Fin)+'$N)'
#                    filelabel = folder+'/compârison2' + label_xp
#                    axedef = [0.15 , 0.15, right, 0.85, wspace, 0.3]
#                    figsize = (10,7)
#                    
#                    datax = [tplot,tplot]
#                    datay = [data1,data2]
#                    label = [label1,label2]
#                    unitx = [unittime,unittime]
#                    unity = [unity1,unity2]
#                    limits = [lims1,lims2]
#                    MyPlot(datax, datay, label, unitx, unity, limits, fontsize=fontsize, axedef=axedef, \
#                                legendfontsize=legendfontsize, linewidth=linewidth, figsize=figsize, ncol=1, \
#                                filelabel=filelabel, maintitle=maintitle, loc=1)
#    
    #%%
                    close('all')
                    nperiodes = 3
                    axedef = [0.1 , 0.17, 0.95, 0.9, 0.3, 0.3]
                    figsize = (12,5)
    
                    GF = Globalfont()
                    GF.update({'size':20})
                    rc('font', **GF)
    
                    fig, axs = subplots(1, 2, sharex=False, figsize=figsize)
#                    suptitle('Measurement and simulation (force '+str(mm)+')', fontsize=20)
    
                    from scipy.io import wavfile
                    ref = wavfile.read('REF/REF'+str(mm)+'.wav')
                    sig = ref[1]
                    dsig = [np.abs(ex-ey) for (ex, ey) in zip(sig[1:], sig[:-1])]
                    n0 = list(np.abs(dsig)).index(np.max(np.abs(dsig)))
                    nminref = n0 +int(5*fs/f0)
                    nmaxref = nminref + int(5/f0*fs)
                    data1 = sig[nminref:nmaxref]
                    dsig = [np.abs(ex-ey) for (ex, ey) in zip(vout[1:], vout[:-1])]
                    n0 = list(np.abs(dsig)).index(np.max(np.abs(dsig)))
                    nminsim = n0 +int(5*fs/f0)
                    nmaxsim = nminsim + int(5/f0*fs)
                    data2 = vout[nminsim:nmaxsim]
                    
                    tplot = t[nminsim:nmaxsim]
                    
                    norme1 = np.max(np.abs(np.array(data1)))
                    norme2 = np.max(np.abs(np.array(data2)))
    
                    data1 = [float(e)/float(norme1) for e in data1]
                    data2 = [e/norme2 for e in data2]
    
                    temp = [np.sum([e1*e2 for (e1,e2) in zip(data2[n:], data1[:-n])]) for n in range(data1.__len__())]
                    n1 = temp.index(np.max(temp))
                    majorformatter = ScalarFormatter(useOffset=False)
                    
                    from matplotlib.ticker import MaxNLocator

                    axs[0].plot(tplot[:int(nperiodes*fs/f0)],data1[:int(nperiodes*fs/f0)],'-r', label=r'measure', linewidth=2)
                    axs[0].plot(tplot[:int(nperiodes*fs/f0)], data2[n1:n1+int(nperiodes*fs/f0)],':.b', label=r'simulation',linewidth=2)
                    axs[0].set_ylabel(r'Normalized Out ($V/V_{\mathrm{max}}$)')
                    axs[0].set_xlabel(r'Time $t$ (s)')
                    axs[0].grid()
                    axs[0].xaxis.set_major_formatter(majorformatter)
                    axs[0].yaxis.set_major_locator( MaxNLocator(nbins = 5) )
                    axs[0].ticklabel_format(axis='x', style='sci', scilimits=(-2, 2))
                    axs[0].xaxis.set_major_locator( MaxNLocator(nbins = 5) )
                    axs[0].set_xlim([tplot[0], tplot[int(nperiodes*fs/f0)]])
#                    box = axs[0].get_position()
#                    axs[0].set_position([box.x0, box.y0 + box.height * 0.1,
#                                     box.width, box.height * 0.9])
#                    # Put a legend below current axis
#                    axs[0].legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), ncol=3, title='Output voltages $\upsilon_0$ (force '+str(mm)+')', fontsize=GF['size'])    
    
                    data1 = sig[nminref+int(fs):nmaxref+int(fs)]
                    tplot = t[nminsim+int(fs):nmaxsim+int(fs)]
                    data2 = vout[nminsim+int(fs):nmaxsim+int(fs)] #vp[nmin:nmax]
                    tplot = t[nminsim+int(fs):nmaxsim+int(fs)]
                    tplot = t[nminsim:nmaxsim]
    
                    data1 = [float(e)/float(norme1) for e in data1]
                    data2 = [e/norme2 for e in data2]
    
                    temp = [np.sum([e1*e2 for (e1,e2) in zip(data2[n:], data1[:-n])]) for n in range(data1.__len__())]
                    n1 = temp.index(np.max(temp))
                    majorformatter = ScalarFormatter(useOffset=False)
    
                    axs[1].plot(tplot[:int(nperiodes*fs/f0)],data1[:int(nperiodes*fs/f0)],'-r', label=r'Measurement',linewidth=2)
                    axs[1].plot(tplot[:int(nperiodes*fs/f0)], data2[n1:n1+int(nperiodes*fs/f0)],':.b', label=r'Simulation',linewidth=2)
                    axs[1].set_xlabel('Time $t+1$ (s)')
                    axs[1].grid()
#                    axs[1].legend(loc=1, fontsize=20)
                    axs[1].yaxis.set_major_locator( MaxNLocator(nbins = 5) )
                    axs[1].xaxis.set_major_formatter(majorformatter)
                    axs[1].ticklabel_format(axis='x', style='sci', scilimits=(-2, 2))
                    axs[1].xaxis.set_major_locator( MaxNLocator(nbins = 5) )
                    axs[1].set_xlim([tplot[0], tplot[int(nperiodes*fs/f0)]])
#                    box = axs[1].get_position()
#                    axs[1].set_position([box.x0, box.y0 + box.height * 0.1,
#                                     box.width, box.height * 0.9])
#                    # Put a legend below current axis
#                    axs[1].legend(loc='upper center', bbox_to_anchor=(0.5, -0.05),
#                              fancybox=True, shadow=True, ncol=2, fontsize=GF['size'])    
#                    fig.legend(loc='upper center', ncol=3, title='Output voltages $\upsilon_0$ (force '+str(mm)+')', fontsize=GF['size'])
                    left  = axedef[0]  # the left side of the subplots of the figure
                    right = axedef[2]    # the right side of the subplots of the figure
                    bottom = axedef[1]   # the bottom of the subplots of the figure
                    top = axedef[3]      # the top of the subplots of the figure
                    wspace = axedef[4]   # the amount of width reserved for blank space between subplots
                    hspace = axedef[5]   # the amount of height reserved for white space between subplots
                    fig.subplots_adjust(left=left, right=right, bottom=bottom, top=top, wspace=wspace, hspace=hspace)   
    
                    savefig(folder+'/test'+str(mm)+'.png')
                    
               #%%

#                from matplotlib import cm
#                
#                close('all')
#                figure()
#                axedef = [0.07 , 0.12, 0.95, 0.9, 0., 0.2]
#                
#                figsize = (12,6)
#                
#                rc('font', **Globalfont())
#                majorformatter = ScalarFormatter(useOffset=False)
#                
#                from matplotlib.pyplot import colorbar
#                
#                fig, (ax1, ax2) = subplots(2,1, figsize=figsize)
#                nfft = int(2**(11))
#                noverlap = int(nfft/2)
#                sig_sim =  np.array(vout)
#                #list(np.array(allsig)+ np.random.randn(np.array(allsig).shape[0])*5e-4)
#                sig_ref = np.array(ref[1])
#                
#                sig_ref = sig_ref/(np.max(np.abs(sig_ref)))
#                sig_sim = sig_sim/(np.max(np.abs(sig_sim)))
#                
#                vmin = -50
#                
#                stft = ax1.specgram(sig_ref/(nfft/2), mode='psd', Fs=Fe, NFFT=nfft, noverlap=noverlap, cmap=cm.Blues)
#                
#                cmap = cm.PuBu_r
#                stft = ax1.specgram(sig_ref/(nfft/2), mode='psd', Fs=Fe, NFFT=nfft, noverlap=noverlap, vmin=vmin, vmax=0, cmap=cmap)
#                ax1.set_ylim([0,10e3])
#                ax1.set_xlim([0,40])
#                ax1.yaxis.set_major_formatter(majorformatter)
#                ax1.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
#                ax1.set_ylabel(r'ref. (Hz)')
#                setp(ax1.get_xticklabels(), visible=False)
#                ax1.set_title('Reference')
#                
#                #vmin = 20*np.log10(np.max(np.abs(sig_sim))) - 60. # hide anything below -40 dBc
#                stft = ax2.specgram(sig_sim/(nfft/2), mode='psd', Fs=Fe, NFFT=nfft, noverlap=noverlap, vmin=vmin, vmax=0, cmap=cmap)
#                ax2.set_xlim([0,40])
#                ax2.set_ylim([0,10e3])                
#                ax2.yaxis.set_major_formatter(majorformatter)
#                ax2.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
#                ax2.set_ylabel(r'sim. (Hz)')
#                ax2.set_xlabel(r'time (s)')
#                ax2.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
#                ax2.set_title('Simulation')
#                
#                tp = [e/Fe-1 for e in range(list(sig_ref).__len__())]
#                
#                left  = axedef[0]  # the left side of the subplots of the figure
#                right = axedef[2]    # the right side of the subplots of the figure
#                bottom = axedef[1]   # the bottom of the subplots of the figure
#                top = axedef[3]      # the top of the subplots of the figure
#                wspace = axedef[4]   # the amount of width reserved for blank space between subplots
#                hspace = axedef[5]   # the amount of height reserved for white space between subplots
#                fig.subplots_adjust(left=left, right=right, bottom=bottom, top=top, wspace=wspace, hspace=hspace)   
#                fig.subplots_adjust(right=0.87)
#                cbar_ax = fig.add_axes([0.9, bottom, 0.011, 0.78])
#                fig.colorbar(stft[3], cax=cbar_ax, label='dB')
#                
#                savefig(folder+'/spectrum'+label_xp+str(mm)+'.png')
#                

#                ## GENERATE MONO FILE ##
#                wv = wave.open(folder+'/'+label_xp+'.wav', 'w')
#                wv.setparams((1, 2, Fe, 0, 'NONE', 'not compressed'))
#                maxVol=2**15-1.0 #maximum amplitude
#                Normalisation = np.max(np.abs(vout))
#                wvData=""
#                for i in range(0, allsig.__len__()):
#                        wvData+=pack('h', int(maxVol*vout[i]/Normalisation))
#                wv.writeframes(wvData)
#                wv.close()

                #%%
## GENERATE MONO FILE ##
wv = wave.open(folder+'/allsigs.wav', 'w')
wv.setparams((1, 2, fs, 0, 'NONE', 'not compressed'))
maxVol=2**15-1.0 #maximum amplitude
Normalisation = np.max(np.abs(allsig))
wvData=""
for i in range(0, allsig.__len__()):
        wvData+=pack('h', maxVol*allsig[i]/Normalisation)
wv.writeframes(wvData)
wv.close()

#%%

from matplotlib.ticker import ScalarFormatter, MaxNLocator
from matplotlib.pyplot import setp, rc, plot, xlim, ylim, suptitle, savefig, ylabel, legend, xlabel,close, figure, subplots, subplot, grid
from struct import pack
import wave
from scipy.io import wavfile
from matplotlib import cm

close('all')
figure()
axedef = [0.09 , 0.12, 0.95, 0.9, 0., 0.2]

figsize = (12,6)

rc('font', **Globalfont())
majorformatter = ScalarFormatter(useOffset=False)

from matplotlib.pyplot import colorbar

fig, (ax1, ax2) = subplots(2,1, figsize=figsize)
nfft = int(2**(11))
delta = -50
cmap = cm.BuPu
noverlap = int(nfft/2)

fmin = 0
fmax = 5e3

# Reference
sig_ref = wavfile.read('REF/REF.wav')[1]             
sig_ref = sig_ref/float(np.max(np.abs(sig_ref)))
Pxx, fbins, tbins, im = ax1.specgram(sig_ref[int(fs):]/(nfft/2), mode='psd', Fs=fs, NFFT=nfft, noverlap=noverlap, cmap=cm.Blues)
Pxx_ref = Pxx/np.max(Pxx)
extent = [tbins.min(), tbins.max(), fbins.min(), fbins.max()]
im = ax1.imshow(10*np.log10(Pxx_ref), extent=extent, origin='lower', aspect='auto', cmap=cmap, vmin = delta, vmax = 0)
ax1.set_xlim([0,40])
ax1.set_ylim([fmin,fmax])
ax1.yaxis.set_major_formatter(majorformatter)
ax1.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
ax1.set_ylabel(r'Frequency (Hz)')
setp(ax1.get_xticklabels(), visible=False)
ax1.set_title('Reference', fontsize=25)


# Simulation
Fe, sig_sim = wavfile.read(folder+'/allsigs.wav')
sig_sim = sig_sim/float(np.max(np.abs(sig_sim)))
Pxx, freqs, bins, im = ax2.specgram(sig_sim[int(Fe):]/(nfft/2), mode='psd', Fs=Fe, NFFT=nfft, noverlap=noverlap, cmap=cmap)
Pxx_sim = Pxx/np.max(Pxx)
extent = [tbins.min(), tbins.max(), fbins.min(), fbins.max()]
im = ax2.imshow(10*np.log10(Pxx_sim), extent=extent, origin='lower', aspect='auto', cmap=cmap, vmin = delta, vmax = 0)
ax2.set_xlim([0,40])
ax2.set_ylim([fmin,fmax])                
ax2.yaxis.set_major_formatter(majorformatter)
ax2.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
ax2.set_ylabel(r'Frequency (Hz)')
ax2.set_xlabel(r'Time (s)')
ax2.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
ax2.set_title('Simulation', fontsize=25)

tp = [e/Fe-1 for e in range(list(sig_ref).__len__())]

x = np.matrix(sig_ref[int(Fe):]/float(np.max(sig_ref[int(Fe):]))).T
y = np.matrix(sig_sim[int(Fe):]/np.max(sig_sim[int(Fe):])).T
a = (y.T*y)[0,0]
b = (-2*x.T*y)[0,0]
c = (x.T*x)[0,0]
A = -b/a

left  = axedef[0]  # the left side of the subplots of the figure
right = axedef[2]    # the right side of the subplots of the figure
bottom = axedef[1]   # the bottom of the subplots of the figure
top = axedef[3]      # the top of the subplots of the figure
wspace = axedef[4]   # the amount of width reserved for blank space between subplots
hspace = axedef[5]   # the amount of height reserved for white space between subplots
fig.subplots_adjust(left=left, right=right, bottom=bottom, top=top, wspace=wspace, hspace=hspace)   
fig.subplots_adjust(right=0.87)
cbar_ax = fig.add_axes([0.9, bottom, 0.011, 0.78])
fig.colorbar(im, cax=cbar_ax, label='Magnitude (dB)')

savefig(folder+'/ALLspectrum'+'.png')


 #%%

#%%
from matplotlib.ticker import ScalarFormatter, MaxNLocator
from matplotlib.pyplot import setp, rc, plot, xlim, ylim, suptitle, savefig, ylabel, legend, xlabel,close, figure, subplots, subplot, grid
from struct import pack
import wave
from scipy.io import wavfile
from matplotlib import cm
close('all')
figure()
axedef = [0.1 , 0.09, 0.95, 0.95, 0., 0.2]

figsize = (12,10)
GF = Globalfont()
newFS = 20
GF.update({'size':newFS})
rc('font', **GF)
majorformatter = ScalarFormatter(useOffset=False)


from specgram_tools import my_specgram

for dynamic in [el*10 for el in range(5,21)]:
    
    fig, (ax1, ax2, ax3) = subplots(3,1, figsize=figsize)
    nfft = int(2**(12))
    noverlap = int(nfft/2)
    flims = [0,5e3]
    
    
    sig_name_simu = folder+'/allsigs.wav'
    sig_name_ref = 'REF/REF.wav'

    Fe, sig_sim = wavfile.read(folder+'/allsigs.wav')
    #list(np.array(allsig)+ np.random.randn(np.array(allsig).shape[0])*5e-4)
    sig_ref = wavfile.read('REF/REF.wav')[1]             
    
    xpos_ylabel = -0.08
    
    im, tbins, fbins = my_specgram(fig, ax1, 'Measure', sig_name_ref, dynamic=dynamic, flims=flims)
    ax1.set_ylabel(r'Frequency (Hz)')
    setp(ax1.get_xticklabels(), visible=False)
    ax1.yaxis.set_label_coords(xpos_ylabel, 0.5)
    ax1.set_title('Measure', fontsize=newFS)
    
    #vmin = 20*np.log10(np.max(np.abs(sig_sim))) - 60. # hide anything below -40 dBc
#    sig = sig_sim[int(Fe):]
#    Pxx, fbins, tbins, im = ax2.specgram(sig/(nfft/2), mode='psd', Fs=Fe, NFFT=nfft, noverlap=noverlap, cmap=cm.Blues)
#    Pxx = Pxx/np.max(Pxx)
#    extent = [tbins.min(), tbins.max(), fbins.min(), fbins.max()]
#    im = ax2.imshow(10*np.log10(Pxx), extent=extent, origin='lower', aspect='auto', cmap=cmap, vmin=vmin, vmax = 0)
    im, tbins, fbins = my_specgram(fig, ax2, 'Simulation', sig_name_simu, dynamic=dynamic, flims=flims)
    ax2.yaxis.set_major_formatter(majorformatter)
    ax2.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
    ax2.set_ylabel(r'Frequency (Hz)')
    setp(ax2.get_xticklabels(), visible=False)
    ax2.yaxis.set_label_coords(xpos_ylabel, 0.5)
    ax2.set_title('Simulation', fontsize=newFS)
    
    tp = [e/float(Fe)-1 for e in range(list(sig_ref).__len__())]
    
    ax3.plot(tp[int(Fe):],sig_ref[int(Fe):]/float(np.max(np.abs(sig_ref[int(Fe):]))), '-r', label='measure')
    ax3.plot(tp[int(Fe):],sig_sim[int(Fe):]/float(np.max(np.abs(sig_sim[int(Fe):]))), '-b', label='simulation')
    ax3.set_xlim([0,40])
    ax3.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
    ax3.set_ylabel(r'Normalized Out ($V/V_{\mathrm{max}}$)')
    ax3.yaxis.set_major_formatter(majorformatter)
    ax3.grid()
    ax3.set_xlabel(r'Time (s)')
    ax3.set_title('Output voltages $\upsilon_0$', fontsize=newFS)
    ax3.annotate('force 1', xy=(1, 0.2), xytext=(2.5, .5),
                arrowprops=dict(facecolor='black', shrink=0.01),
                )
    ax3.annotate('force 4', xy=(16, 0.2), xytext=(17.5, .5),
                arrowprops=dict(facecolor='black', shrink=0.01),
                )
    ax3.annotate('force 7', xy=(31, 0.2), xytext=(32.5, .5),
                arrowprops=dict(facecolor='black', shrink=0.01),
                )
    ax3.legend(loc = 3, fontsize=20)
    ax3.yaxis.set_label_coords(xpos_ylabel, 0.5)
    
    left  = axedef[0]  # the left side of the subplots of the figure
    right = axedef[2]    # the right side of the subplots of the figure
    bottom = axedef[1]   # the bottom of the subplots of the figure
    top = axedef[3]      # the top of the subplots of the figure
    wspace = axedef[4]   # the amount of width reserved for blank space between subplots
    hspace = axedef[5]   # the amount of height reserved for white space between subplots
    fig.subplots_adjust(left=left, right=right, bottom=bottom, top=top, wspace=wspace, hspace=hspace)   
    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.87, 0.397, 0.01, 0.555])
    fig.colorbar(im, cax=cbar_ax, label='Magnitude (dB)')
    
    savefig(folder+'/ALLspectrum'+str(dynamic)+'.pdf')
    

#%%
exit()

