# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 04:32:46 2016

@author: Falaize
"""

def ShowGraph(phs):
    import networkx as nx
    import matplotlib.pyplot as plt
    pos = nx.circular_layout(phs.Graph)
    plt.figure()
    nx.draw_networkx_nodes(phs.Graph, pos)
    nx.draw_networkx_edges(phs.Graph, pos)
    nx.draw_networkx_labels(phs.Graph, pos)
    edge_labels = {}
    for edge in phs.list_of_edges:
        edge_labels[(edge[0], edge[1])] = edge[2]['ref']
    nx.draw_networkx_labels(phs.Graph, pos, labels=edge_labels)
    plt.show()

def build_graph_from_netlist(phs, netlist):
    import os 
    from dictionary.libstd import allstd
    import dictionary.libstd as libstd
    netlist_file = open(netlist + ".net", "r")
    phs.netlist = list()
    with netlist_file as openfileobject:
        for line in openfileobject:
            # find first and last brackets for nodes definition
            nstart_nodes = line.find('[')
            nend_nodes = line.find(']')
            # Nodes list
            nodes_label = line[nstart_nodes+1:nend_nodes]
            # find first and last brackets for definition of arguments
            nstart_args = line.rfind('[')
            nend_args = line.rfind(']')
            # Arguments list
            arguments = line[nstart_args+1:nend_args]
            # Split component type and component label (first 2 elements of the line)
            splited_line = line[:nstart_nodes].split()
            component = splited_line[0]
            label = splited_line[1]
            # call the method for actual component
            if component in allstd:
                current_component = eval("libstd."+component+r"('"+label+\
            r"',(" +nodes_label+"),("+arguments+',))')
            # Compose the system with the actual component
            phs = phs + current_component
            # save current component in a list
            phs.netlist.append(current_component)
    # Close netlist file
    netlist_file.close()
    return phs

def buildStructurefromGraph(phs):
    # Compute incidence Matrix
    import networkx as nx
    import numpy as np
    Gamma_init = -(nx.linalg.incidence_matrix(phs.Graph, oriented=True)).todense()
    phs.Gamma = np.matrix(np.zeros(Gamma_init.shape))
    phs.Lambda = np.matrix(np.zeros(Gamma_init.shape))

    phs.list_of_edges = phs.Graph.edges(data=True)
    phs.list_of_edge_labels = [edge[2]['ref'] for edge in phs.list_of_edges]
    phs.nodes_labels = phs.Graph.nodes()
    phs.list_of_realizabilities = []
    edges_index = []

    # Sort edges according to storage, dissipative, port and trans_port types

    # Get storage edges
    for n in range(phs.nx()):
        edge_index = phs.list_of_edge_labels.index(str(phs.x[n]))
        edges_index += [edge_index]
        phs.Gamma[:, n] = Gamma_init[:, edge_index]
        edge_realizability = phs.list_of_edges[edge_index][2]['realizability']
        phs.list_of_realizabilities.append(edge_realizability)
        if (edge_realizability == 'flux_controlled') | (edge_realizability == '?'):
            phs.Lambda[:, n] = np.abs(Gamma_init[:, edge_index])

    # Get disipative edges
    for n in range(phs.nw()):
        edge_index = phs.list_of_edge_labels.index(str(phs.w[n]))
        edges_index += [edge_index]
        phs.Gamma[:, phs.nx() + n] = Gamma_init[:, edge_index]
        edge_realizability = phs.list_of_edges[edge_index][2]['realizability']
        phs.list_of_realizabilities.append(edge_realizability)
        if (edge_realizability == 'flux_controlled') | (edge_realizability == '?'):
            phs.Lambda[:, phs.nx() +n] = np.abs(Gamma_init[:, edge_index])

    # Get port edges
    for n in range(phs.ny()):
        edge_index = phs.list_of_edge_labels.index(str(phs.y[n]))
        edges_index += [edge_index]
        phs.Gamma[:, phs.nx() +phs.nw()+ n] = Gamma_init[:, edge_index]
        edge_realizability = phs.list_of_edges[edge_index][2]['realizability']
        phs.list_of_realizabilities.append(edge_realizability)
        if (edge_realizability == 'flux_controlled') | (edge_realizability == '?'):
            phs.Lambda[:, phs.nx()+phs.nw()+n] = np.abs(Gamma_init[:, edge_index])

    # Get trans_port edges
    for n in range(phs.ntrans()):
        edge_index = phs.list_of_edge_labels.index(str(phs.trans_y[n]))
        edges_index += [edge_index]
        phs.Gamma[:, phs.nx()+phs.nw()+phs.ny()+n] = Gamma_init[:, edge_index]
        edge_realizability = phs.list_of_edges[edge_index][2]['realizability']
        phs.list_of_realizabilities.append(edge_realizability)
        if (edge_realizability == 'flux_controlled') | (edge_realizability == '?'):
            phs.Lambda[:, phs.nx() +phs.nw()+phs.ny()+n] = np.abs(Gamma_init[:, edge_index])

    # Put 0 node at the top of the node list
    index_datum_node = phs.nodes_labels.index(0) if any([0 == nod for nod in phs.nodes_labels]) else []
    ordered_node_index = [index_datum_node] + range(index_datum_node) + range(index_datum_node+1, phs.nodes_labels.__len__())

    # sort
    phs.Gamma = phs.Gamma[ordered_node_index, :]
    phs.Lambda = phs.Lambda[ordered_node_index, :]
    phs.nodes_labels = [phs.nodes_labels[n] for n in ordered_node_index]

    # Sort edges
    phs.list_of_edges = [phs.list_of_edges[el] for el in edges_index]
    phs.list_of_edge_labels = [edge[2]['ref'] for edge in phs.list_of_edges]
    phs.list_of_types = [edge[2]['type'] for edge in phs.list_of_edges]
    phs.list_of_link_refs = [edge[2]['link_ref'] for edge in phs.list_of_edges]

    rowindexGamma = lambda c: [e[0, 0] for e in np.nonzero(phs.Gamma[:, c])[0].T]
#        rowindexGamma = lambda c: [e for e in np.nonzero(np.array(phs.Gamma[:,c]))[0].T]
    colindexGamma = lambda r: [e[0,0] for e in np.nonzero(phs.Gamma[r, :])[1].T]
#        colindexGamma = lambda r: [e for e in np.nonzero(phs.Gamma[r,:])[1].T]
    CompareMatrix = lambda M1, M2: not (M1-M2).any()
    
    nb = phs.list_of_edge_labels.__len__()
    nn = phs.nodes_labels.__len__()

    #force realizability for 0 node
    phs.Lambda[0,:] = 0

    uncertain_edges_indices = range(nb)
    uncertain_nodes_indices = range(1,nn)
    Lambda_iter = np.zeros(phs.Lambda.shape)
    Error = False

    # Realizability analysis on the uncertain_edges_indices
    while (uncertain_edges_indices.__len__() > 0) & (not Error):
        
        print('\nMain While Loop')  
        print("Uncertain edges: " + str([phs.list_of_edge_labels[ind] for ind in uncertain_edges_indices]))              

        # Loop while Lambda is changed
        while (not CompareMatrix(Lambda_iter, phs.Lambda)) & (not Error) & (uncertain_nodes_indices.__len__()+uncertain_edges_indices.__len__() > 0):
            
            # Save Lambda for comparison
            Lambda_iter = np.matrix(phs.Lambda, copy=True)

            print('\nSecond While Loop')                
            print("Uncertain edges: " + str([phs.list_of_edge_labels[ind] for ind in uncertain_edges_indices]))
            print('Realizability: ' + str(phs.list_of_realizabilities))
            print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
            print('uncertain_nodes_indices: ' + str(uncertain_nodes_indices))

            # Iterate on the uncertain edges 
            for e in uncertain_edges_indices:

                # Break if there is no uncertain edges
                if uncertain_edges_indices.__len__() == 0:
                    break

                elif any([e==el for el in uncertain_edges_indices]):

                    index_ctrl_edge_in_uncertain_edges_indices = uncertain_edges_indices.index(e)

                    print("\nCurent edge: " + str(e) + ' ' +str(phs.list_of_edge_labels[e]))

                    edge_type = phs.list_of_types[e]
                    print("Edge type: '" + edge_type)

                    realizability = phs.list_of_realizabilities[e]
                    print("Edge realizability: " + str(realizability))
                    
                    print(e)

                    Lambda_values = [el[0,0] for el in phs.Lambda[rowindexGamma(e),e] ]
                    print("Lambda values: " + str(Lambda_values))

                    # Effort Controlled
                    if realizability =='effort_controlled':
                        phs.Lambda[:, e] = 0
                        # remove the edge from edge list
                        uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        
                        print('Definite edge index: '+str(e))
                        print('Definite edge: '+phs.list_of_edge_labels[e])
                        print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                            
                    # Flux Controlled
                    elif realizability =='flux_controlled':
                        if sum(Lambda_values)==0:
                            print("Error: Realizability of "+phs.list_of_edge_labels[e]+" does not coincide with definition")
                            Error = True
                            break
                        elif sum(Lambda_values)==1:
                            # set other nodes to 0
                            index_ctrl_node = [el[0,0] for el in phs.Lambda[:,e]].index(1)
                            # remove the edge from edge list
                            uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        
                            print('Definite edge index: '+str(e))
                            print('Definite edge: '+phs.list_of_edge_labels[e])
                            print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                            # remove the node from nodes list
                            if any([el==index_ctrl_node for el in uncertain_nodes_indices]):
                                print('Definite node index: '+str(index_ctrl_node))
                                print('Definite node: '+phs.nodes_labels[index_ctrl_node] )
                                index_ctrl_node_in_uncertain_nodes_indices = uncertain_nodes_indices.index(index_ctrl_node)
                                uncertain_nodes_indices = uncertain_nodes_indices[:index_ctrl_node_in_uncertain_nodes_indices] + uncertain_nodes_indices[index_ctrl_node_in_uncertain_nodes_indices+1:]                        
                            print('uncertain_nodes_indices: ' + str(uncertain_nodes_indices))
                            phs.Lambda[index_ctrl_node, :] = 0
                            phs.Lambda[index_ctrl_node, e] = 1
                            Lambda_values = [el[0,0] for el in phs.Lambda[rowindexGamma(e),e] ]
                            print("Lambda values: " + str(Lambda_values))
                            
                    # Undefined Controlled
                    elif realizability =='?':
                        # Test for effort Controlled
                        if sum(Lambda_values)==0:
                            phs.list_of_realizabilities[e] = 'effort_controlled'
                            realizability = phs.list_of_realizabilities[e]
                            print("Edge realizability: " + str(realizability))
                            # remove the edge from edge list
                            uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        
                            print("Edge realizability: " + str(realizability))
                            print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                            # Link Transformers
                            if edge_type == 'trans_port':
                                transformer_index = [any([str(el)==str(phs.list_of_edge_labels[e]) for el in ell['y']]) for ell in phs.transformers].index(True)
                                transformer = phs.transformers[transformer_index]
                                linked_edge_index = phs.list_of_edge_labels.index(phs.list_of_link_refs[e])
                                phs.transformers[transformer_index]['alpha'] = transformer['alpha']**-1
                                if transformer['type'] == 'gyrator':                                    
                                    if phs.list_of_realizabilities[linked_edge_index] == '?' :
                                        phs.list_of_realizabilities[linked_edge_index] = 'effort_controlled'
                                        # remove the edge from edge list
                                        index_linked_edge__in_uncertain_edges_indices = uncertain_edges_indices.index(linked_edge_index)
                                        uncertain_edges_indices = uncertain_edges_indices[:index_linked_edge__in_uncertain_edges_indices] + uncertain_edges_indices[index_linked_edge__in_uncertain_edges_indices+1:]                        
                                        phs.Lambda[:,linked_edge_index] = 0
                                        print("Edge realizability: " + str(realizability))
                                        print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                                    elif phs.list_of_realizabilities[linked_edge_index] == 'flux_controlled' :
                                        print("Error: Realizability of transformer (" + phs.list_of_edge_labels[e] + ', ' + phs.list_of_link_refs[e] + ") does not coincide with definition")
                                        Error = True
                                        break
                                elif transformer['type'] == 'transformer':                                    
                                    if phs.list_of_realizabilities[linked_edge_index] == '?' :
                                        phs.list_of_realizabilities[linked_edge_index] = 'flux_controlled'
                                        print("Edge realizability: " + str(realizability))
                                        print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                                    elif phs.list_of_realizabilities[linked_edge_index] == 'effort_controlled' :
                                        print("Error: Realizability of transformer (" + phs.list_of_edge_labels[e] + ', ' + phs.list_of_link_refs[e] + ") does not coincide with definition")
                                        Error = True
                                        break

                        # Test for flux Controlled
                        elif sum(Lambda_values)==1:
                            if sum(phs.Lambda[phs.Lambda[:,e].T.tolist()[0].index(1),:].tolist()[0]) == 1:
                                phs.list_of_realizabilities[e] = 'flux_controlled'
                                # set other nodes to 0
                                index_ctrl_node = [el[0,0] for el in phs.Lambda[:,e]].index(1)
                                # remove the edge from edge list
                                uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        
                                # remove the node from nodes list
                                print(str(uncertain_nodes_indices))

                                if any([el==index_ctrl_node for el in uncertain_nodes_indices]):
                                    print('Definite node index: '+str(index_ctrl_node))
                                    print('Definite node: '+phs.nodes_labels[index_ctrl_node] )
                                    index_ctrl_node_in_uncertain_nodes_indices = uncertain_nodes_indices.index(index_ctrl_node)
                                    uncertain_nodes_indices = uncertain_nodes_indices[:index_ctrl_node_in_uncertain_nodes_indices] + uncertain_nodes_indices[index_ctrl_node_in_uncertain_nodes_indices+1:]                        
                                phs.Lambda[index_ctrl_node, uncertain_edges_indices] = 0
                                phs.Lambda[index_ctrl_node, e] = 1
                                print("Edge realizability: " + str(realizability))
                                print('uncertain_nodes_indices: ' + str(uncertain_nodes_indices))
                                realizability = phs.list_of_realizabilities[e]
                                print("Edge realizability: " + str(realizability))
                                Lambda_values = [el[0,0] for el in phs.Lambda[rowindexGamma(e),e] ]
                                print("Lambda values: " + str(Lambda_values))
                                # Link Transformers
                                if edge_type == 'trans_port':
                                    transformer_index = [any([str(el)==str(phs.list_of_edge_labels[e]) for el in ell['y']]) for ell in phs.transformers].index(True)
                                    transformer = phs.transformers[transformer_index]
                                    linked_edge_index = phs.list_of_edge_labels.index(phs.list_of_link_refs[e])
                                    if transformer['type'] == 'gyrator':                                    
                                        if phs.list_of_realizabilities[linked_edge_index] == '?' :
                                            phs.list_of_realizabilities[linked_edge_index] = 'flux_controlled'
                                        elif phs.list_of_realizabilities[linked_edge_index] == 'effort_controlled' :
                                            print("Error: Realizability of transformer (" + phs.list_of_edge_labels[e] + ', ' + phs.list_of_link_refs[e] + ") does not coincide with definition")
                                            Error = True
                                            break
                                    if transformer['type'] == 'transformer':
                                        if phs.list_of_realizabilities[linked_edge_index] == '?' :
                                            phs.list_of_realizabilities[linked_edge_index] = 'effort_controlled'
                                            # remove the edge from edge list
                                            index_ctrl_edge_in_uncertain_edges_indices = uncertain_edges_indices.index(linked_edge_index)
                                            uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        
                                            phs.Lambda[:,linked_edge_index] = 0
                                        elif phs.list_of_realizabilities[linked_edge_index] == 'flux_controlled' :
                                            print("Error: Realizability of transformer (" + phs.list_of_edge_labels[e] + ', ' + phs.list_of_link_refs[e] + ") does not coincide with definition")
                                            Error = True
                                            break
                print('\nuncertain_nodes_indices: '+str(uncertain_nodes_indices))
                # Iteration sur les noeuds
                for n in uncertain_nodes_indices:
                    print("\nCurent node: " + str(n) + ' ' + str(phs.nodes_labels[n]))
                    Lambda_values = [el[0,0] for el in phs.Lambda[n,colindexGamma(n)].T ]
                    print('colindexGamma('+str(n)+')='+str(colindexGamma(n)))
                    print("Lambda values: " + str(Lambda_values))
                    # Test for uncontrolled node
                    if sum(Lambda_values) == 0:
                        print(Lambda_values)
                        print("Error: Realizability conflict on node " + str(phs.nodes_labels[n]) + ".")
                        Error = True
                        break
                    # Test for definite node
                    elif sum(Lambda_values) == 1:
                        indice_ctrl_edge = [el[0,0] for el in phs.Lambda[n,:].T].index(1)
                        if (phs.list_of_realizabilities[indice_ctrl_edge] == '?') or (phs.list_of_realizabilities[indice_ctrl_edge] == 'flux_controlled'):

                            index_ctrl_node_in_uncertain_nodes_indices = uncertain_nodes_indices.index(n)
                            uncertain_nodes_indices = uncertain_nodes_indices[:index_ctrl_node_in_uncertain_nodes_indices] + uncertain_nodes_indices[index_ctrl_node_in_uncertain_nodes_indices+1:]                        

                            print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                            
                            index_ctrl_edge_in_uncertain_edges_indices = uncertain_edges_indices.index(indice_ctrl_edge)
                            uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        

                            phs.list_of_realizabilities[indice_ctrl_edge] = 'flux_controlled'
                            phs.Lambda[:,indice_ctrl_edge] = 0
                            phs.Lambda[n, indice_ctrl_edge] = 1

                            print('Definite node index: '+str(n))
                            print('Definite node: '+phs.nodes_labels[n] )
                            print('Definite edge index: '+str(indice_ctrl_edge))
                            print('Definite edge: '+phs.list_of_edge_labels[indice_ctrl_edge] )

                            print('uncertain_edges_indices: ' + str(uncertain_edges_indices))
                            
                            # Link Transformers
                            if phs.list_of_types[indice_ctrl_edge] == 'trans_port':
                                transformer_index = [ any([phs.list_of_edge_labels[indice_ctrl_edge]==str(el) for el in trans['y']]) for trans in phs.transformers].index(True)
                                transformer = phs.transformers[transformer_index]
                                linked_edge_index = phs.list_of_edge_labels.index(phs.list_of_link_refs[indice_ctrl_edge])
                                if transformer['type'] == 'gyrator':                                    
                                    if phs.list_of_realizabilities[linked_edge_index] == '?' :
                                        phs.list_of_realizabilities[linked_edge_index] = 'flux_controlled'
                                    elif phs.list_of_realizabilities[linked_edge_index] == 'effort_controlled' :
                                        print("Error: Realizability of transformer (" + phs.list_of_edge_labels[indice_ctrl_edge] + ', ' + phs.list_of_link_refs[indice_ctrl_edge] + ") does not coincide with definition")
                                        Error = True
                                        break
                                if transformer['type'] == 'transformer':                                    
                                    if phs.list_of_realizabilities[linked_edge_index] == '?' :
                                        phs.list_of_realizabilities[linked_edge_index] = 'effort_controlled'
                                        # remove the edge from edge list
                                        index_ctrl_edge_in_uncertain_edges_indices = uncertain_edges_indices.index(linked_edge_index)
                                        uncertain_edges_indices = uncertain_edges_indices[:index_ctrl_edge_in_uncertain_edges_indices] + uncertain_edges_indices[index_ctrl_edge_in_uncertain_edges_indices+1:]                        
                                        phs.Lambda[:,linked_edge_index] = 0
                                    elif phs.list_of_realizabilities[linked_edge_index] == 'flux_controlled' :
                                        print("Error: Realizability of transformer (" + phs.list_of_edge_labels[indice_ctrl_edge] + ', ' + phs.list_of_link_refs[indice_ctrl_edge] + ") does not coincide with definition")
                                        Error = True
                                        break
                        elif (phs.list_of_realizabilities[indice_ctrl_edge] == 'effort_controlled'):
                            print("Error: Realizability conflict on node " + str(phs.nodes_labels[n]) + ".")
                            Error = True
                            break

    print('Realizability: remaining edges = ' + str([phs.list_of_edge_labels[el] for el in uncertain_edges_indices]))

    phs.Gamma = phs.Gamma[1:,:]
    phs.Lambda = phs.Lambda[1:,:]
    nb_nodes = phs.nodes_labels.__len__()-1
    nb_edges = phs.list_of_edge_labels.__len__()
    is_flux_controlled = phs.Lambda.sum(axis=0)

    import scipy as sc
    M_I = sc.diag([is_flux_controlled[0,n] for n in range(nb_edges)])
    M_V = np.eye(M_I.shape[1])-M_I
    Mp1 = np.concatenate((np.zeros((nb_nodes,nb_edges)),M_V,M_I))
    Mp2 = np.concatenate((np.eye(nb_nodes),np.zeros((nb_edges,nb_nodes)),np.zeros((nb_edges,nb_nodes))))
    Mp3 = np.concatenate((np.zeros((nb_nodes,nb_edges)),M_I,M_V))
    Permut = np.matrix(np.concatenate((Mp2, Mp1, Mp3), axis=1))
            
    M1 = np.concatenate((phs.Gamma.T,np.zeros((nb_nodes,nb_nodes))))
    M2 = np.concatenate((-np.eye(nb_edges),np.zeros((nb_nodes,nb_edges))))
    M3 = np.concatenate((np.zeros((nb_edges,nb_edges)),phs.Gamma))
    GG = np.concatenate((M1,M2,M3),axis=1)
    GG = GG*Permut
    
    def op1(M, i ,j):
        temp = [M[i,n] for n in np.arange(M.shape[1])] 
        M[i,:] = M[j,:]
        M[j,:] = temp
        return M
    def op2(M,i,a):
        M[i,:] = [a*M[i,n] for n in np.arange(M.shape[1])] 
        return M
        
    def op3(M,i,j,a):
        M[i,:] = [M[i,n]+a*M[j,n] for n in np.arange(M.shape[1])] 
        return M
        
    for n in range(GG.shape[0]):
        temp = np.nonzero(GG[n:,n]!=0)[0]
        l = n + temp[0,0] if temp.shape[1]>0 else n
        GG=op1(GG, n ,l)
        GG=op2(GG,n,GG[n,n]**-1)
        for m in np.arange(GG.shape[0]):
            if m != n :
                if GG[m,n] !=0:
                    GG=op3(GG,m,n,-GG[m,n]**-1)
    import sympy as sp
    J = -sp.Matrix(GG[nb_nodes:,nb_nodes+nb_edges:])
    
    if phs.ntrans()>0:
        phs.Gx_trans = J[:phs.nx(), phs.nx() + phs.nw() + phs.ny() : ]
        phs.Gw_trans  = J[phs.nx():phs.nx()+phs.nw(),phs.nx() + phs.nw() + phs.ny() :]
        phs.Gy_trans = J[phs.nx()+phs.nw():phs.nx()+phs.nw()+ phs.ny(),phs.nx() + phs.nw() + phs.ny() : ]        
        phs.Jtrans_trans = J[phs.nx()+phs.nw()+ phs.ny():,phs.nx() + phs.nw() + phs.ny():]
        switch_list = [trans['alpha'] * sp.Matrix([[0,1],[-1,0]]) for trans in phs.transformers]
        Mswitch = sp.diag(*switch_list)
        G_trans = sp.Matrix(J[:phs.nx()+phs.nw()+ phs.ny(),phs.nx() + phs.nw() + phs.ny():])
        phs.Jtrans_trans = G_trans * Mswitch * G_trans.T
    else:
        phs.Jtrans_trans = sp.zeros(phs.nx()+phs.nw()+ phs.ny(),phs.nx()+phs.nw()+ phs.ny())

    J = sp.Matrix(J[:phs.nx()+phs.nw()+ phs.ny(), :phs.nx()+phs.nw()+ phs.ny()]) + phs.Jtrans_trans
        
    phs.Jx = J[:phs.nx(),:phs.nx()]
    phs.K= -J[:phs.nx(),phs.nx():phs.nx()+phs.nw()]    
    phs.Gx = J[:phs.nx(),phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny()]
    phs.Jw = J[phs.nx():phs.nx()+phs.nw(),phs.nx():phs.nx()+phs.nw()]
    phs.Gw = J[phs.nx():phs.nx()+phs.nw(),phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny()]
    phs.Jy = -J[phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny(),phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny()]        
    phs.J = J
    if bool(Error) |  bool(np.matrix(phs.J+phs.J.T).sum()):
        import sys
        sys.exit("!!!!    Error in realizability analysis    !!!!")
    else:
        print "\n\nGraph analysis succeeds."
    return phs
                        