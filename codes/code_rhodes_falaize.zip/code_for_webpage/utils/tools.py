# -*- coding: utf-8 -*-
"""
Created on Sat Mar  5 13:53:43 2016

@author: Falaize
"""

class ProgressBar:
    '''
    Progress bar
    '''
    def __init__ (self, valmax, maxbar, title):
        if valmax == 0:  valmax = 1
        if maxbar > 200: maxbar = 200
        self.valmax = valmax
        self.maxbar = maxbar
        self.title  = title
    
    def update(self, val):
        import sys
        # process
        perc  = round((float(val) / float(self.valmax)) * 100)
        scale = 100.0 / float(self.maxbar)
        bar   = int(perc / scale)
  
        # render 
        out = '\r %20s [%s%s] %3d %%' % (self.title, '=' * bar, ' ' * (self.maxbar - bar), perc)
        sys.stdout.write(out)
        sys.stdout.flush()


def splitlist(lis, len_out):
    """
    Split the 'lis' in a list1 of list2 with max(len(list(2)))='len_out'
    """
    lis.reverse()
    lis_out = list()
    while lis:
        temp = list()
        for _ in range(len_out):
            try:
                temp.append(lis.pop())
            except IndexError:
                pass
        lis_out.append(temp)
    return lis_out

    
def decimate(it, nd=10):
    """
    Return first then each 'nd' elements from iterable 'it'.

    Parameters
    -----------

    it : iterable
        Input data.

    nd : int
        Decimation factor

    Returns
    -------

    l : list
        One in 'nd' values from 'it'.

    """
    assert (isinstance(nd, int) and nd > 0), "'nd' is not an integer: %r" % nd
    l = list()
    n=0
    for el in it:
        if not n%nd: l.append(el)
        n += 1
    return l
