# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 00:24:35 2016

@author: Falaize
"""

def print_latex(sp_object):
    from sympy.printing import latex
    return latex(sp_object, fold_short_frac=True, mat_str = "array")

def obj2tex(obj, label, toMatrix=True):
    """
    Return nicely latex formated string for "label = obj"
    Parameters
    -----------
    obj : sympy object
    label : latex compliant string

    Return
    ------
    string
    """    
    
    if toMatrix:
        import sympy as sp
        obj = sp.Matrix(obj)        

    str_out = "\n"
    str_out += r"$$ " + label + r" = " + print_latex(obj) + r" . $$"
    return str_out
    
def preamble(phs):
    str_preamble = ""
    str_preamble += r"\documentclass[11pt, oneside]{article}   	% use 'amsart' instead of 'article' for AMSLaTeX format" + "\n"
    str_preamble += r"\usepackage{geometry}                		% See geometry.pdf to learn the layout options. There are lots." + "\n"
    str_preamble += r"\geometry{letterpaper}                   		% ... or a4paper or a5paper or ... " + "\n"
    str_preamble += r"%\geometry{landscape}                		% Activate for for rotated page geometry" + "\n"
    str_preamble += r"%\usepackage[parfill]{parskip}    		% Activate to begin paragraphs with an empty line rather than an indent" + "\n"
    str_preamble += r"\usepackage{graphicx}				% Use pdf, png, jpg, or epsÂ§ with pdflatex; use eps in DVI mode" + "\n"
    str_preamble += r"								% TeX will automatically convert eps --> pdf in pdflatex		" + "\n"
    str_preamble += r"\usepackage{amssymb}" + "\n"
    str_preamble += r"\title{Structure of pHs \texttt{" + phs.label + r"}}" + "\n"
    str_preamble += r"\author{A. Falaize}" + "\n"
    str_preamble += r"%\date{}							% Activate to display a given date or no date" + "\n" + "\n"
    str_preamble += r"\begin{document}" + "\n" + "\n"
    str_preamble += r"\maketitle" + "\n" + "\n"
    return str_preamble

def dimensions(phs):
    str_dimensions = ""
    str_dimensions += r"\section{System dimensions}"+"\n"
    for dim in [r'x', r'w', r'y', r'p']:
        obj = eval(r'phs.n'+dim+r'()')
        label = r"n_\mathbf{"+dim+r"}"
        str_dimensions += obj2tex(obj, label, toMatrix=False) 
    return str_dimensions

def variables(phs):
    str_variables = "\n" + "\n"
    str_variables += r"\section{System variables}"+"\n"
    if phs.nx()>0:
        str_variables += obj2tex(phs.x, r'\mathbf{x}')
    if phs.nw()>0:
        str_variables += obj2tex(phs.w, r'\mathbf{w}')
    if phs.ny()>0:
        str_variables += obj2tex(phs.u, r'\mathbf{u}')
        str_variables += obj2tex(phs.y, r'\mathbf{y}')
    str_variables += "\n" + "\n"
    str_variables += r"\section{Constitutive relations}"+"\n"
    if phs.nx()>0:
        str_variables += obj2tex(phs.H, r'\mathtt{H}(\mathbf{x})', toMatrix=False)
        str_variables += obj2tex(phs.gradH, r'\nabla \mathtt{H}(\mathbf{x})')
    if phs.nw()>0:
        str_variables += obj2tex(phs.z, r'\mathbf{z}(\mathbf{w})')
    str_variables += "\n" + "\n"
    str_variables += r"\section{System parameters}"+"\n"        
    if phs.np()>0:
        str_variables += obj2tex(phs.params, r'\mathbf{p}')
    return str_variables
        
def structure(phs):
    str_structure = "\n"+"\n"
    str_structure += r"\section{System structure}"+"\n"
    str_structure += obj2tex(phs.Jx, r"\mathbf{J_x}")
    str_structure += obj2tex(phs.K, r"\mathbf{K}")
    str_structure += obj2tex(phs.Gx, r"\mathbf{G_x}")
    str_structure += obj2tex(phs.Jw, r"\mathbf{J_w}")
    str_structure += obj2tex(phs.Gw, r"\mathbf{G_w}")
    str_structure += obj2tex(phs.Jy, r"\mathbf{J_y}")
    str_structure += obj2tex(phs.J, r"\mathbf{J}")
    return str_structure

def phs2tex(phs):
    str_tex = ""
    str_tex += preamble(phs)
    str_tex += dimensions(phs)
    str_tex += variables(phs)
    str_tex += structure(phs)
    str_tex += "\n"+"\n"
    str_tex += r"\end{document}"
    return str_tex
