# -*- coding: utf-8 -*-
"""
Created on Thu Mar  3 23:45:08 2016

@author: Falaize
"""

def frequencyresponse(sigin, sigout, fs, nfft=None, filtering=None, limits=None):
    """
    Return frequencies and modulus of transfer function T(iw) = sigout(iw)/sigin(iw).
    
    Parameters
    ----------
    
    sigin, sigout : array_like
        Time series of measurement values for input and output
        
    fs : float
        Sampling frequency
    
    nfft : int, optional
        Length of the FFT used, if a zero padded FFT is desired. If None, the FFT length is nperseg. Defaults to None.
    
    filtering : float, optional
        If provided, apply a lowpass filter on sigin and sigout before computing fft (the default is None).
        Then filtering is the cutoff frequency as a fraction of the sampling rate (in (0, 0.5)).

    limits : (fmin, fmax), optional
        If provided, truncates the output between fmin and fmax (the default is None).

    Return
    ------
    
    f : list
        frequency point in Hertz.

    TF : list
        Modulus of transfer function.

    """

    if not filtering is None:
        sigin = lowpass(sigin, fc=filtering)
        sigout = lowpass(sigout, fc=filtering)    
    import scipy.signal as sig
    f, Pxx_den1 = sig.welch(sigin, fs, nperseg=nfft, scaling='spectrum')
    f, Pxx_den2 = sig.welch(sigout, fs, nperseg=nfft, scaling='spectrum')
    TF = Pxx_den2/Pxx_den1    
    if limits is None:
        fmin, fmax = 20., 20e3
    else:
        fmin, fmax = limits
    from numpy import nonzero
    nfmax = f.__len__() if fmax>=f[-1] else nonzero(f>fmax)[0][0]
    nfmin = nonzero(f>fmin)[0][0]    
    f = f[nfmin:nfmax]
    TF = [el**0.5 for el in TF[nfmin:nfmax]]
    return f, TF

def SignalSin(n, fs, f0, A0=1., f1=None, A1=1.):
    """
    Build a generator that yields a sine wave.

    Parameters
    ----------
    n : int
        Number of samples generated.
    fs : int
        Sample rate in Hz.
    f0 : float
        Sin frequency.
    A : float, optional
        Sine amplitude (the default is 1.0). 
    f1 : float or None, optional
        Secondary sine frequency if float (the default is None).
    A1 : float, optional
        Secondary amplitude (the default is 1.0).

    Yields
    ------
    s : float
        Sequence of sine wave values.
    """
    from numpy import sin, pi
    for i in range(n):
        t = float(i)/fs
        val = A0*sin(2*pi*f0*t)
        if isinstance(f1, (float,int)):
            val += A1*sin(2*pi*f1*t)
        yield val
                
def SignalRandomUniform(n, A=1.):
    """
    Build a generator that yields a noise distributed according uniform probability densisty.

    Parameters
    ----------
    n : int
        Number of samples generated.
    A : float, optional
        Noise amplitude (the default is 1.0). 

    Yields
    ------
    s : float
        Sequence of noise values.
    """

    from numpy.random import uniform

    for i in range(n):
        yield uniform(-A,A)

def SignalConstant(n, A=1.):
    """
    Build a generator that yields a constant value.

    Parameters
    ----------
    n : int
        Number of samples generated.
    A : float, optional
        Constant (the default is 1.0). 

    Yields
    ------
    s : float
        Sequence of constant value.
    """
    for i in range(n):
        yield A

def SignalSweep(n, fs, f0, f1, A=1.):
    """
    Build a generator that yields a sweep sine between f0 and f1.

    Parameters
    ----------
    n : int
        Number of samples generated.
    fs : int
        Sample rate in Hz.
    f0 : float
        Initial frequency in Hz.
    f1 : float
        Final frequency in Hz such that f1>f0
    A : float, optional
        Amplitude (the default is 1.0). 

    Yields
    ------
    s : float
        Sequence of sweep values.
    """    
    from numpy import linspace
    from scipy.signal import chirp
    T = float(n-1)/float(fs)
    for t in linspace(0,T,n):
        yield A*chirp(t, f0=f0, f1=f1, t1=T)

def SignalGenerator(which='sin', n=100,  ncycles=1, ndeb=0, nend=0, fs=int(1e3),\
A=1., A1=0., f0=10., f1=100., cycle_ratio=1., attack_ratio=0., decay_ratio=0., ramp_on=False, noisy=0.):
    """
    Return a generator that yields variety of signals.

    Parameters
    ----------
    which : str, optional
        Signal type (the default is 'sin'):
            * 'sin' yields sine wave,
            * 'noise' yields a random value from a uniform p.d.f,
            * 'sweep' yields a sine wave with increasing frequency,
            * 'step' yields a step function.
        
    n : int, optional
        Number of samples for a single cycle (the default is 100).

    ncycles : int, optional
        Number of cycles generated (the default is 1).

    ndeb : int, optional
        Number of 0.0 generated before the cycles (the default is 0). 

    nend : int, optional
        Number of 0.0 generated after the cycles (the default is 0). 

    fs : int, optional
        Sample rate in Hz (the default is 1000).

    A : float, optional
        Peak to peak amplitude (the default is 1.0). 

    A1 : float, optional
        Amplitude of second sin wave in 'sin' mode only (the default is 1.0).

    f0 : float, optional
        Sin frequency (the default is 10.0Hz).

    f1 : float or None, optional
        Secondary frequency:
            * add a second sin wave in 'sin' mode,
            * set final frequency in 'sweep' mode.

    cycle_ratio : float, optional
        Cycle ratio between 0.0 and 1.0 (the default is 1.0) in reference to PWM.

    attack_ratio : float, optional
        Attack envelope ratio w.r.t. n*cycle_ratio (the default is 0.). 

    decay_ratio : float, optional
        Decay envelope ratio w.r.t. n*cycle_ratio (the default is 0.).

    ramp_on : bool, optional
        Set the linear increasing of output during all cycles (the default is False).
        
    noisy : float, optional
        Amplitude of an overall background noise from uniform p.d.f (the default is 0.0).

    Yields
    ------
    s : float
        signal value
    """    
    non  = int(n*cycle_ratio)
    noff = n - non

    na, nd = int(attack_ratio*non), int(decay_ratio*non)    

    clamp_signal = lambda x, xmin, xmax: min((xmax,max((x, xmin))))

    ramp = lambda i: i/float(ncycles*n-1) if ramp_on else 1.

    def env(i):
        enva = clamp_signal((non-i)/float(nd), 0, 1) if nd>0 else 1
        envd = clamp_signal(i/float(na), 0, 1) if na>0 else 1
        return enva * envd

    def background_noise():
        if isinstance(noisy, (int, float)):
            return SignalRandomUniform(1,noisy).next()
        else:
            return 0.
            
    for i in range(ndeb):
        yield background_noise()   

    for c in range(ncycles):
        if which == 'sin':
            Sig = SignalSin(non, fs, f0, A)
        elif which == 'noise':
            Sig = SignalRandomUniform(non, A)
        elif which == 'step':
            Sig = SignalConstant(non, A)
        elif which == "sweep":
            Sig = SignalSweep(non, fs, f0, f1, A)
        else:
            print '%s unknown.' % which
            raise NameError

        i = 0
        for v in Sig:
            yield ramp(i+c*n)*env(i)*v + background_noise()
            i += 1

        for i in range(noff):
            yield background_noise()

    for i in range(nend):
        yield background_noise()

def lowpass(s, fc, tbw=1e-2):
    """
    Lowpass filter of 1D object s.
    
    Parameters
    ----------

    s : Iterable or Generator
        Input signal
    fc : float
        Cutoff frequency as a fraction of the sampling rate (in (0, 0.5)).
    tbw : float, optional
        Transition band width, as a fraction of the cutoff frequency (in (0, 1), the default is 0.01).
        
    Return
    ------
    s_out : ndarray
        Low-pass version of input signal s.
    """

    from numpy import arange, cos, sinc, ceil, convolve, pi

    b = tbw*fc
    fc = fc-b
    N = int(ceil((4 / b)))
    if not N % 2: N += 1  # Make sure that N is odd.
    n = arange(N)
    # Compute sinc filter.
    h = sinc(2 * fc * (n - (N - 1) / 2.))
    # Compute Blackman window.
    w = 0.42 - 0.5 * cos(2 * pi * n / (N - 1)) + \
        0.08 * cos(4 * pi * n / (N - 1))
    # Multiply sinc filter with window.
    h = h * w
    # Normalize to get unity gain.
    h = h / sum(h)
    return convolve(s, h, 'same')

def export_wav(sig, fs, label, normalize=True, timefades=1e-3):
    from struct import pack
    import wave
    import types
    assert isinstance(sig, (list, types.GeneratorType)), 'Signal should be a list or a generator. Got %s' % type(sig)
    if isinstance(sig, types.GeneratorType):
        sig = [s for s in sig]
        
    nsig = len(sig)
    nfades = int(timefades*fs)
    if nsig >= 2*nfades:
        fadein = [n/(nfades) for n in range(nfades)]
        fadeout = [(nfades-1-n)/(nfades) for n in range(nfades)]
        fades = fadein + [1.]*(nsig-2*nfades) + fadeout
        sig = [elsig*elfade for (elsig, elfade) in zip(sig, fades)]
        
    ## GENERATE MONO FILE ##
    wv = wave.open(label+'.wav', 'w')
    wv.setparams((1, 2, fs, 0, 'NONE', 'not compressed'))
    maxVol=2**15-1.0 #maximum amplitude
    if normalize:
        scale = max([abs(el) for el in sig])
    wvData=""
    for i in range(0, sig.__len__()):
        wvData+=pack('h', int(maxVol*sig[i]/scale))
    wv.writeframes(wvData)
    wv.close()
    
if __name__ is '__main__':
    fs = 100
    f0 = 1.
    Dur = 5.
    nt = int(Dur*fs)
    f1 = 10
    s = [el for el in SignalGenerator(which='sweep', n=nt, noisy=0.01, fs=fs, f0=f0, f1=f1, A=1)]
    export_wav(s, fs, 'sweep')
    from matplotlib.pyplot import specgram, cm
    specgram(s, NFFT=2**10, cmap=cm.bone_r)
    from plots import singleplot
    t = [el/float(fs) for el in range(nt)]
    singleplot(t, (s, ))    
