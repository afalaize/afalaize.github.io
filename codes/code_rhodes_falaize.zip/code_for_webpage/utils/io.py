# -*- coding: utf-8 -*-
"""
Created on Sun Mar  6 15:53:51 2016

@author: Falaize
"""

def write_data(phs, seq, var):
    list2str = lambda l: str(str(l).strip('[]')).replace(',', '') + '\n'
    import os
    _file = open(phs.folders['data']+os.sep +var +'.txt', 'w')
    for u in seq:
        _file.write(list2str(u))
    _file.close()
    return
    
def write_all(phs, seq_u, seq_p=None, x0=None, nt=None):

    print("Write simulation inputs...")
    import time
    time.sleep(1e-6)

    if x0 is None:
        x0 = [0,]*phs.nx()  
    else: 
        assert isinstance(x0[0], (float, int)), 'x0 not understood, got %s' % x0

    if seq_p is None:
        def generatorseq_p():
            for i in range(phs.nt):
                yield [],
        seq_p = generatorseq_p()

    write_data(phs, seq_u, 'u')
    write_data(phs, seq_p, 'p')
    write_data(phs, [x0,], 'x0')
    

def data_generator(filename, ind=None, decim=1, postprocess=None, imin=0, imax=None):
    if imax is None: 
        imax = float('Inf')
    with open(filename, 'r') as f:
        i=0
        for line in f:
            if i >= imin and i < imax:
                if not bool(i%decim):
                    if ind is None:
                        out = [float(x) for x in line.split()]
                        yield out if postprocess is None else map(postprocess, out)
                    else:
                        assert isinstance(ind, int),\
                        'Index should be an integer. Got %s' % type(ind)
                        out = float(line.split()[ind])
                        yield out if postprocess is None else postprocess(out)
            i += 1

def load_data(phs, var, ind=None, decim=1, postprocess=None, imin=0, imax=None):
    import os
    title = var if ind is None else var+str(ind)
    print 'load '+title
    import time
    time.sleep(1e-6)
    filename = phs.folders['data']+os.sep+var+'.txt'
    data = data_generator(filename, ind=ind, decim=decim, postprocess=postprocess, imin=imin, imax=imax)    
    return [el for el in data]

def load_io(phs, decim=1, imin=0, imax=None):
    phs.seq_u = load_data(phs, 'u', decim=decim, imin=imin, imax=imax)
    phs.seq_y = load_data(phs, 'y', decim=decim, imin=imin, imax=imax)
    return len(phs.seq_u)

def load_storage(phs, decim=1, imin=0, imax=None):
    phs.seq_x = load_data(phs, 'x', decim=decim, imin=imin, imax=imax)        
    dx2dtx = lambda dx: dx*phs.fs
    phs.seq_dtx = load_data(phs, 'dx', decim=decim, imin=imin, imax=imax, postprocess=dx2dtx)
    phs.seq_dxH = load_data(phs, 'dxH', decim=decim, imin=imin, imax=imax)
    return len(phs.seq_x)

def load_dissipation(phs, decim=1, imin=0, imax=None):
    phs.seq_w = load_data(phs, 'w', decim=decim, imin=imin, imax=imax)
    phs.seq_z = load_data(phs, 'z', decim=decim, imin=imin, imax=imax)
    return len(phs.seq_w)

def load_all(phs, decim=1, imin=0, imax=None):
    list_powers = list()
    if phs.nx() > 0:
        nt = load_storage(phs, decim=decim, imin=imin, imax=imax)
        list_powers.append(zip(phs.seq_dtx, phs.seq_dxH))
    if phs.nw() > 0:
        nt = load_dissipation(phs, decim=decim, imin=imin, imax=imax)
        list_powers.append(zip(phs.seq_w, phs.seq_z))
    if phs.ny() > 0:
        nt = load_io(phs, decim=decim, imin=imin, imax=imax)
        list_powers.append(zip(phs.seq_u, phs.seq_y))
    t0 = imin*phs.fs
    fsdecim = float(phs.fs)/float(decim)
    phs.seq_t = [t0 + el*fsdecim**-1 for el in range(nt)]

    print 'compute power balance'
    import time
    time.sleep(1e-6)
    from utils.parallelize import parallel_map
    phs.seq_dtE, phs.seq_pd, phs.seq_ps = parallel_map(scalar_product, list_powers)

def scalar_product(tup):
    """
    Used to parallelize the computation of power balance elements
    Yields [sum([e1*e2 for (e1, e2) in zip(l1, l2)]) for (l1, l2) in tup]
    """
    return [sum([e1*e2 for (e1, e2) in zip(l1, l2)]) for (l1, l2) in tup]


