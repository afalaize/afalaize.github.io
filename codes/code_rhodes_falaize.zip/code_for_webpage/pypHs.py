# -*- coding: utf-8 -*-
"""
Copyright or © or Copr. Project-Team S3 (Sound Signals and Systems) and Analysis/Synthesis team,
Laboratory of Sciences and Technologies of Music and Sound (UMR 9912),
IRCAM-CNRS-UPMC, 1 place Igor Stravinsky, F-75004 Paris
contributor(s) : Antoine Falaize, Thomas Hélie, Thu Jul 9 23:11:37 2015
corresponding contributor: antoine.falaize@ircam.fr

This software (pypHs) is a computer program whose purpose is to generate C++
code for the simulation of multiphysics system described in graph formalism.
It is composed of a library (pypHs.py) and a dictionnary (Dictionnary.py)

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights, and the successive licensors  have only  limited liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

"""

import sympy as sp
import time

from numpy import finfo
eps = finfo(float).resolution

string_xcode_path = """
Per-configuration build product path

$(PROJECT_DIR)/build/$(CONFIGURATION)
"""

class pHobj:
    """ Object oriented sympy (symbolic) representation of a
        port-Hamiltonian (pH) System.

    Parameters
    -----------
    
    label : str
        System label. If None, "dummy_phs" is used (the default is None).

    path : str
        Path used for export. If None, current directory is used (the default is None).

    """
    
    def __init__(self, label=None, path=None):

        # Define path for exports (plots, waves, tex, c++, etc...)
        import os
        if path is None:
            self.path = os.getcwd() 
        else:
            newpath = path
            if not os.path.exists(newpath): os.makedirs(newpath)
            self.path = path

        # Init dic of specific paths for exports of plots or waves or tex or c++ etc...
        self.folders = dict()

        # Label used as netslist name or filename for exports
        if label is None:
            self.label = 'dummy_phs'
        else:
            self.label = label

        # Init lists of symbols
        self.H = sp.sympify(0.)
        self.x = []
        self.w = []
        self.z = []
        self.u = []
        self.y = []
        self.params = []
        self.diagQ = []
        self.diagR = []
        self.diagG = []
        self.gradH = []

        # Init links for transformers and gyrators
        self.transformers = []
        self.trans_u = []
        self.trans_y = []

        # Init structure
        self.Jx = sp.zeros(0, 0)
        self.K = sp.zeros(0, 0)
        self.Gx = sp.zeros(0, 0)
        self.Jw = sp.zeros(0, 0)
        self.Gw = sp.zeros(0, 0)
        self.Jy = sp.zeros(0, 0)
        self.J = sp.zeros(0, 0)

        # dic of value for each parameter (key is the string associated to parameter symbol).
        self.subs = {}

        # Init graph
        self.netlist = []
        import networkx as nx
        self.Graph = nx.MultiDiGraph()

        # Misc
        self.ConstantInputs = []
        self.ConstantParameters = []
        self.ch_of_var = []
        self.unities = {'x':[], 'w':[], 'u':[]}

        # Runtime numerical functions
        self.Fl = []
        self.Fnl = []
        self.dxH = []
        self.PDJ = sp.sympify(0)

        
##############################################################################
##############################################################################

    def nx(self):
        return self.x.__len__()
    def nw(self):
        return self.w.__len__()
    def ny(self):
        return self.y.__len__()
    def np(self):
        return self.params.__len__()
    def ntot(self):
        return self.nx()+self.nw()+self.ny()
    def ntrans(self):
        return self.trans_y.__len__()

    def all_vars(self):
        return self.x + self.w + self.y

    def nxl(self):
        return self.diagQ.__len__()
    def nxnl(self):
        return self.nx() - self.nxl()

    def nwl(self):
        return self.diagR.__len__()
    def nwnl(self):
        return self.nw() - self.nwl()

    def xl(self):
        return self.x[:self.nxl()]
    def xnl(self):
        return self.x[self.nxl():]
    def dxl(self):
        return self.dx[:self.nxl()]
    def dxnl(self):
        return self.dx[self.nxl():]

    def wl(self):
        return self.w[:self.nwl()]
    def wnl(self):
        return self.w[self.nwl():]

    def zl(self):
        return self.z[:self.nwl()]
    def znl(self):
        return self.z[self.nwl():]

    def Q(self):
        return sp.diag(*self.diagQ)
    def R(self):
        return sp.diag(*self.diagR)

    def units_x(self):
        return self.unities['x']
    def units_dtx(self):
        from sympy.physics import units
        return [e/units.s for e in self.unities['x']]
    def units_dxH(self):
        from sympy.physics import units
        return [units.power*units.s/e for e in self.unities['x']]

    def units_w(self):
        return self.unities['w']
    def units_z(self):
        from sympy.physics import units
        return [units.power/e for e in self.unities['w']]

    def units_u(self):
        return self.unities['u']
    def units_y(self):
        from sympy.physics import units
        return [units.power/e for e in self.unities['u']]

    def Gains(self):
        return sp.diag(*self.diagG)

##############################################################################

    def stateChange(self, f):
        x_tilde = sp.symbols(['c'+str(x) for x in self.x])
        functions_list = [el_f-el_x for (el_f, el_x) in zip(f, x_tilde)]
        g = sp.solve(functions_list, self.x, dict=True, exclude=self.params)
        if isinstance(g, list):
            if g.__len__() > 1:
                print "Inverse mapping is not unique. Choose one of:"
                n = 0
                for el_g in g:
                    n += 1
                    print "\n"
                    print str(n)+":"
                    print el_g
                n = int(raw_input("Choice?\n"))
                g = g[n-1]
            else:
                g = g[0]
        G = dict(g)
        g = []
        for xx in zip(self.x, x_tilde):
            if any([xx[0] == k for k in G.keys()]):
                g += [G[xx[0]]]
            else:
                g += [xx[1]]
        M = sp.eye(self.ntot())
        for l in range(self.nx()):
            for c in range(self.nx()):
                M[l, c] = f[l].diff(self.x[c]).doit()
        for sub in zip(self.x, g):
            M = M.subs(sub[0], sub[1])
        self.x_old_from_new = g
        self.J = M*self.J*M.T
        for n in range(self.nx()):
            self.applySubs([(self.x[n], g[n])])
        self.x = x_tilde
        for n in range(self.nxl()):
            self.diagQ[n] = self.H.diff(self.x[n], 2)

    def linearVariableChange(self, index, gain):
        if index < self.nx():
            n = index
            f = [x for x in self.x]
            f[n] = f[n]/gain
            self.stateChange(f)
            self.applySubs()

        elif (index >= self.nx()) &  (index < self.nx()+self.nw()):
            n = index-self.nx()
            old_symb = self.w[n]
            new_symb = sp.symbols('c'+str(old_symb))
            old_as_func_of_new = gain*new_symb
            self.z[n] = gain*self.z[n].subs(old_symb, old_as_func_of_new)
            self.w[n] = new_symb
            if n < self.nwl():
                self.diagR[n] = self.z[n].diff(self.w[n]).doit()
            M = sp.eye(self.ntot())
            M[index, index] = gain**-1
            self.applySubs([(old_symb, old_as_func_of_new)])
            self.J = M*self.J*M.T

        elif (index >= self.nx()+self.nw()) & (index < self.ntot()):
            n = index-self.nx()-self.nw()
            old_symb = self.u[n]
            M = sp.eye(self.ntot())
            M[index, index] = gain**-1
            self.J = M*self.J*M.T
            self.diagG[n] = self.diagG[n]*gain
            self.applySubs()

    def Canonize(self, nonlinearize=False):

        # for each line of J
        list_ind = range(self.nx()+self.nw())
        list_ind.reverse()
        for l in list_ind:
            # analyse element c to find nonzeros
            indices_nonzeros = []
            for c in range(self.ntot()):
                element_of_J = self.J[l, c]
                if element_of_J != sp.sympify(0):
                    indices_nonzeros.append(c)
            # for each nonzero element
            for c in indices_nonzeros:
                # if J[l,c] is not canonic
                if sp.Abs(self.J[l, c]) != sp.sympify(1):
                    gain = self.J[l, c]
                    # get indices of connected edges
                    indices_connections = indices_nonzeros
                    indices_connections.remove(c)
                    # For each connected element
                    self.linearVariableChange(l, gain)
                    for i in indices_connections:
                        # replace with gain = 1/J[l,c]
                        if sp.Abs(self.J[l, i]) != sp.sympify(1):
                            self.linearVariableChange(i, gain**-1)
                    # replace element l

        if nonlinearize:
            list_ind = range(self.nxl())
            list_ind.reverse()
            while list_ind:
                n = list_ind.pop()
                list_symbols = list(sp.sympify(self.diagQ[n]).free_symbols)
                if any([any(el == p for p in self.params) for el in list_symbols]):
                    self.moveStateLinToNLin(n)
                    list_ind = [el-1 for el in list_ind]
            list_ind = range(self.nwl())
            list_ind.reverse()
            while list_ind:
                n = list_ind.pop()
                list_symbols = list(sp.sympify(self.diagR[n]).free_symbols)
                test_par = any([any(el == p for p in self.params) for el in list_symbols])
                list_symbols = list(sp.sympify(self.diagR[n]).free_symbols)
                test_state = any([any(el == x for x in self.x) for el in list_symbols])
                if any([test_state, test_par]):
                    self.moveDissLinToNLin(n)
                    list_ind = [el-1 for el in list_ind]

##############################################################################

    def AddStructure(self, Jx=None, K=None, Gx=None, Jw=None, Gw=None, Jy=None):

        if not Jx is None:
            self.Jx = sp.Matrix(Jx)
        elif sum(self.Jx)==0:
            self.Jx = sp.zeros(self.nx(), self.nx())
        if not K is None:
            self.K = sp.Matrix(K)
        elif sum(self.K)==0:
            self.K = sp.zeros(self.nx(), self.nw())
        if not Gx is None:
            self.Gx = sp.Matrix(Gx)
        elif sum(self.Gx)==0:
            self.Gx = sp.zeros(self.nx(), self.ny())
        if not Jw is None:
            self.Jw = sp.Matrix(Jw)
        elif sum(self.Jw)==0:
            self.Jw = sp.zeros(self.nw(), self.nw())
        if not Gw is None:
            self.Gw = sp.Matrix(Gw)
        elif sum(self.Gw)==0:
            self.Gw = sp.zeros(self.nw(), self.ny())
        if not Jy is None:
            self.Jy = sp.Matrix(Jy)
        elif sum(self.Jy)==0:
            self.Jy = sp.zeros(self.ny(), self.ny())

        hstack1 = sp.Matrix.hstack(self.Jx, -self.K, self.Gx)
        hstack2 = sp.Matrix.hstack(self.K.T, self.Jw, self.Gw)
        hstack3 = sp.Matrix.hstack(-self.Gx.T, -self.Gw.T, self.Jy)
        self.J = sp.Matrix.vstack(hstack1, hstack2, hstack3)

    def moveJLine(self, indi, indf):
        if indi < indf:
            deb = sp.Matrix.vstack(self.J[:indi, :], self.J[indi+1:indf+1, :])
            end = self.J[indf+1:, :]
            eli = self.J[indi, :]
            self.J = sp.Matrix.vstack(deb, eli, end)
        elif indi > indf:
            deb = self.J[:indf, :]
            end = sp.Matrix.vstack(self.J[indf:indi, :], self.J[indi+1:, :])
            eli = self.J[indi, :]
            self.J = sp.Matrix.vstack(deb, eli, end)

    def moveJCol(self, indi, indf):
        if indi < indf:
            deb = sp.Matrix.hstack(self.J[:, :indi], self.J[:, indi+1:indf+1])
            end = self.J[:, indf+1:]
            eli = self.J[:, indi]
            self.J = sp.Matrix.hstack(deb, eli, end)
        elif indi > indf:
            deb = self.J[:, :indf]
            end = sp.Matrix.hstack(self.J[:, indf:indi], self.J[:, indi+1:])
            eli = self.J[:, indi]
            self.J = sp.Matrix.hstack(deb, eli, end)

    def moveState(self, indi, indf):
        if indi < indf:
            deb = self.x[:indi] + self.x[indi+1:indf+1]
            end = self.x[indf+1:]
            eli = [self.x[indi]]
            self.x = deb + eli + end
            self.moveJCol(indi, indf)
            self.moveJLine(indi, indf)
            if indi < self.nxl():
                debQ = self.diagQ[:indi] + self.diagQ[indi+1:indf+1]
                endQ = self.diagQ[indf+1:]
                eliQ = [self.diagQ[indi]]
                self.diagQ = debQ + eliQ + endQ

        elif indi > indf:
            deb = self.x[:indf]
            end = self.x[indf:indi]+ self.x[indi+1:]
            eli = [self.x[indi]]
            self.x = deb + eli + end
            self.moveJCol(indi, indf)
            self.moveJLine(indi, indf)
            if indi < self.nxl():
                debQ = self.diagQ[:indf]
                endQ = self.diagQ[indf:indi]+ self.diagQ[indi+1:]
                eliQ = [self.diagQ[indi]]
                self.diagQ = debQ + eliQ + endQ

    def moveStateLinToNLin(self, indi):
        self.moveState(indi, self.nxl()-1)
        self.diagQ = self.diagQ[:-1]

    def moveDiss(self, indi, indf):
        if indi < indf:
            deb = self.w[:indi] + self.w[indi+1:indf+1]
            end = self.w[indf+1:]
            eli = [self.w[indi]]
            self.w = deb + eli + end
            deb = self.z[:indi] + self.z[indi+1:indf+1]
            end = self.z[indf+1:]
            eli = [self.z[indi]]
            self.z = deb + eli + end
            self.moveJCol(indi+self.nx(), indf+self.nx())
            self.moveJLine(indi+self.nx(), indf+self.nx())
            if indi < self.nwl():
                debR = self.diagR[:indi] + self.diagR[indi+1:indf+1]
                endR = self.diagR[indf+1:]
                eliR = [self.diagR[indi]]
                self.diagR = debR + eliR + endR

        elif indi > indf:
            deb = self.w[:indf]
            end = self.w[indf:indi]+ self.x[indi+1:]
            eli = [self.w[indi]]
            self.w = deb + eli + end
            deb = self.z[:indf]
            end = self.z[indf:indi]+ self.z[indi+1:]
            eli = [self.z[indi]]
            self.z = deb + eli + end
            self.moveJCol(indi+self.nx(), indf+self.nx())
            self.moveJLine(indi+self.nx(), indf+self.nx())
            if indi < self.nwl():
                debR = self.diagR[:indf]
                endR = self.diagR[indf:indi]+ self.diagR[indi+1:]
                eliR = [self.diagR[indi]]
                self.diagR = debR + eliR + endR

    def moveDissLinToNLin(self, indi):
        self.moveDiss(indi, self.nwl()-1)
        self.diagR = self.diagR[:-1]

    def movePort(self, indi, indf):
        if indi < indf:
            deb = self.u[:indi] + self.u[indi+1:indf+1]
            end = self.u[indf+1:]
            eli = [self.u[indi]]
            self.u = deb + eli + end
            deb = self.y[:indi] + self.y[indi+1:indf+1]
            end = self.y[indf+1:]
            eli = [self.y[indi]]
            self.y = deb + eli + end
            self.moveJCol(indi+self.nx()+self.nw(), indf+self.nx()+self.nw())
            self.moveJLine(indi+self.nx()+self.nw(), indf+self.nx()+self.nw())

#######################################################################

    def AddLinearStorageComponents(self, ListStringsXComp, ListValsQComp, ListUnits=[]):
        self.unities['x'] += ListUnits
        xComp = sp.symbols(ListStringsXComp)
        self.x = self.x[:self.nxl()] + xComp + self.x[self.nxl():]
        self.diagQ = self.diagQ + ListValsQComp
        self.H = self.H + (sp.Matrix(xComp).T*sp.diag(*ListValsQComp)*sp.Matrix(xComp))[0, 0]/2
        self.AddStructure()

    def AddNonLinearStorageComponents(self, ListSymbolsXComp, ExprHComp, ListUnits=[]):
        self.unities['x'] += ListUnits
        self.x = self.x + ListSymbolsXComp
        self.H = self.H + ExprHComp
        self.AddStructure()

    def AddLinearDissipativeComponents(self, ListStringsWComp, ListValsRComp, ListUnits=[]):
        self.unities['w'] += ListUnits
        wComp = sp.symbols(ListStringsWComp)
        self.w = self.w[:self.nwl()] + wComp + self.w[self.nwl():]
        list_zR = list(sp.diag(*ListValsRComp)*sp.Matrix(wComp))
        self.z = self.z[:self.nwl()] + list_zR + self.z[self.nwl():]
        self.diagR = self.diagR+ListValsRComp
        self.AddStructure()

    def AddNonLinearDissipativeComponents(self, ListSymbolsWComp, ListExprZComp, ListUnits=[]):
        self.unities['w'] += ListUnits
        self.w = self.w + ListSymbolsWComp
        self.z = self.z + ListExprZComp
        self.AddStructure()

    def AddPorts(self, ListSymbolsU, ListSymbolsY, ListUnits=[]):
        self.unities['u'] += ListUnits
        self.u = self.u + ListSymbolsU
        self.y = self.y + ListSymbolsY
        self.diagG += [1]*ListSymbolsY.__len__()
        self.AddStructure()

#######################################################################

    def AddTransformers(self, label, transform_type, parameter):
        """
        AddTransformers(label:string, transform_type, parameter:str)
        Transform type is "gyrator" or "transformator"
        """
        u1, u2 = sp.symbols(['u_'+label+'_'+str(e+1) for e in range(2)])
        y1, y2 = sp.symbols(['y_'+label+'_'+str(e+1) for e in range(2)])
        alpha = sp.symbols(parameter) if type(parameter) == str else parameter
        transformer = {'u':(u1, u2), 'y':(y1, y2), 'alpha':alpha, 'type':transform_type}
        self.AddParameters([alpha])
        self.trans_u += [u1, u2]
        self.trans_y += [y1, y2]
        self.transformers += [transformer]

#######################################################################

    def AddParameters(self, ListSymbolsParams):
        self.params += ListSymbolsParams

    def AddConstantInpu(self, symbol, value):
        self.ConstantInputs += (symbol, value)

#######################################################################

    def Build(self, fs=sp.symbols('fs'), NumTol=eps, FixedPars=None,\
    ExportCpp=False, replace=True, simplify=True, parallelize=False,\
    presolve=True):


        self.presolve = presolve

        if isinstance(fs, (float, int)):
            assert fs>0, 'Sample rate should be a positive integer, got: %s' % fs
            self.fs = int(fs)
        elif isinstance(fs, (str, sp.Symbol)):
            self.fs = sp.symbols('fs')
            self.params = [self.fs] + self.params

        if replace:
            self.applySubs()

        print "Discrete Gradient"
        time.sleep(.1)
        self.dx = [sp.symbols('d'+str(xx)) for xx in self.x]
        #######################################################################

        self.dxHl = list(self.Q()*(sp.sympify(2)*sp.Matrix(self.xl()) +\
        sp.Matrix(self.dxl()))/sp.sympify(2))
        self.dxHnl = []
        for n in range(self.nxnl()):
            dxh1 = sp.simplify((self.H.subs(self.xnl()[n],\
            self.xnl()[n]+self.dxnl()[n])-self.H)/self.dxnl()[n])
            dxh2 = sp.simplify(self.H.diff(self.xnl()[n])).doit()
            dxh = sp.Piecewise((dxh1, self.dxnl()[n] < -NumTol),\
            (dxh2, self.dxnl()[n] < NumTol), (dxh1, True))
            self.dxHnl.append(dxh)

        self.dxH = self.dxHl + self.dxHnl

        self.gradH = list(self.Q()*sp.Matrix(self.xl())) +\
        [sp.simplify(self.H.diff(self.xnl()[n])).doit() for n in range(self.nxnl())]
        #######################################################################


        # Split Linear and Nonlinear part
        print "\nSplit the effort/flux representation in differential/algebraic representation"
        time.sleep(0.1)
        self.J1 = self.Jx[:self.nxl(), :self.nxl()]
        self.M1 = self.Jx[:self.nxl(), self.nxl():]
        self.J2 = self.Jx[self.nxl():, self.nxl():]

        self.K1 = self.K[:self.nxl(), :self.nwl()]
        self.K2 = self.K[:self.nxl(), self.nwl():]
        self.K3 = self.K[self.nxl():, :self.nwl()]
        self.K4 = self.K[self.nxl():, self.nwl():]

        self.G1 = self.Gx[:self.nxl(), :]
        self.G2 = self.Gx[self.nxl():, :]

        self.J3 = self.Jw[:self.nwl(), :self.nwl()]
        self.M2 = self.Jw[:self.nwl(), self.nwl():]
        self.J4 = self.Jw[self.nwl():, self.nwl():]

        self.G3 = self.Gw[:self.nwl(), :]
        self.G4 = self.Gw[self.nwl():, :]

        #######################################################################

        self.JJ = (self.J - self.J.T)/sp.sympify(2.)
        self.RJ = (self.J + self.J.T)/sp.sympify(2.)

        #######################################################################

        from utils.parallelize import parallel_map
        parallel_factorize = lambda exprs: parallel_map(sp.factor, exprs)

        print "Output Function"
        time.sleep(.1)
        if self.ny() > 0:
            Vyx = self.Gx.T*sp.Matrix(self.dxH) if self.nx() > 0 else sp.zeros(1, self.ny())
            Vyw = self.Gw.T*sp.Matrix(self.z) if self.nw() > 0 else sp.zeros(1, self.ny())
            Vyu = self.Jy*self.Gains()*sp.Matrix(self.u) if self.ny() > 0 else sp.zeros(1, self.ny())
            Fy = list(self.Gains()*(Vyx + Vyw + Vyu))
            self.Fy = sp.Matrix(parallel_factorize(Fy)) if parallelize else sp.Matrix(Fy)
        else:
            self.Fy = sp.Matrix(list(list()))

        if sum(self.RJ) != sp.sympify(0):
            print "Power dissipated in structure"
            time.sleep(.1)
            self.PDJ = -(sp.Matrix(self.dxH + self.z + \
            list(self.Gains()*sp.Matrix(self.u))).T*self.RJ*sp.Matrix(self.dxH\
            + self.z + list(self.Gains()*sp.Matrix(self.u))))[0, 0]

        JacImpFunc = sp.zeros(self.nxnl()+self.nwnl(), self.nxnl()+self.nwnl())
        nlvar = self.dxnl() + self.wnl()
        self.nlfunc = self.dxHnl + self.znl()
        for n in range(self.nxnl()+self.nwnl()):
            for m in range(self.nxnl()+self.nwnl()):
                JacImpFunc[n, m] = (self.nlfunc[n].diff(nlvar[m])).doit()
        self.JacImpFunc = JacImpFunc

        self.isNL = (self.nxnl() + self.nwnl() > 0)

        if self.presolve:

            print "Explicit dissipative inverse"
            time.sleep(0.1)
            self.iDw = sp.eye(self.nwl())- self.J3*self.R()
            self.Dw = sp.Matrix.inv(self.iDw, method='LU')
    #        self.Dw = SymbolicGaussJordanInverse(self.iDw, SimplifyIn=True, SimplifyOut=simplify)
            #######################################################################
            print "Resistive interconnection"
            time.sleep(.1)
            self.A1 = self.Dw*self.K1.T
            self.B1 = self.Dw*self.K3.T
            self.C1 = self.Dw*self.M2
            self.D1 = self.Dw*self.G3
            #######################################################################
            self.tildeA2 = self.J1-self.K1*self.R()*self.A1
            self.tildeB2 = self.M1-self.K1*self.R()*self.B1
            self.tildeC2 = -(self.K2+self.K1*self.R()*self.C1)
            self.tildeD2 = self.G1-self.K1*self.R()*self.D1
            #######################################################################
            print "Explicit storage inverse"
            time.sleep(.1)
            self.iDx = sp.eye(self.nxl())*self.fs - self.tildeA2*self.Q()/2.
            self.Dx = self.iDx.inv()
            print "Dynamical interconnection"
            time.sleep(.1)
            self.A2 = self.Dx*self.tildeA2*self.Q()
            self.B2 = self.Dx*self.tildeB2
            self.C2 = self.Dx*self.tildeC2
            self.D2 = self.Dx*self.tildeD2
            #######################################################################
            self.A3 = self.Q()*(sp.eye(self.nxl())+(sp.sympify(1)/sp.sympify(2))*self.A2)
            self.B3 = (sp.sympify(1)/sp.sympify(2))*self.Q()*self.B2
            self.C3 = (sp.sympify(1)/sp.sympify(2))*self.Q()*self.C2
            self.D3 = (sp.sympify(1)/sp.sympify(2))*self.Q()*self.D2
            #######################################################################
            self.tildeA4 = -(self.M1.T+ self.K3*self.R()*self.A1)
            self.tildeB4 = (self.J2 - self.K3*self.R()*self.B1)
            self.tildeC4 = -(self.K4 + self.K3*self.R()*self.C1)
            self.tildeD4 = (self.G2 - self.K3*self.R()*self.D1)
            #######################################################################
            self.A4 = self.tildeA4*self.A3
            self.B4 = self.tildeB4+self.tildeA4*self.B3
            self.C4 = self.tildeC4+self.tildeA4*self.C3
            self.D4 = self.tildeD4+self.tildeA4*self.D3
            #######################################################################
            self.tildeA5 = (self.K2.T- self.M2.T*self.R()*self.A1)
            self.tildeB5 = (self.K4.T - self.M2.T*self.R()*self.B1)
            self.tildeC5 = (self.J4 - self.M2.T*self.R()*self.C1)
            self.tildeD5 = (self.G4 - self.M2.T*self.R()*self.D1)
            #######################################################################
            self.A5 = self.tildeA5*self.A3
            self.B5 = (self.tildeB5+self.tildeA5*self.B3)
            self.C5 = (self.tildeC5+self.tildeA5*self.C3)
            self.D5 = (self.tildeD5+self.tildeA5*self.D3)
            #######################################################################
            self.A6 = self.A1*self.A3
            self.B6 = (self.B1+self.A1*self.B3)
            self.C6 = (self.C1+self.A1*self.C3)
            self.D6 = (self.D1+self.A1*self.D3)
            #######################################################################

            print "Explicite Function"
            time.sleep(.1)
            if self.nxnl() > 0:
                MdxHnl = sp.Matrix.vstack(self.B2, self.B6)*sp.Matrix(list(self.dxHnl))
            else:
                MdxHnl = sp.zeros(self.nxl()+self.nwl(), 1)
            Mznl = sp.Matrix.vstack(self.C2, self.C6)*sp.Matrix(list(self.znl()))\
            if self.nwnl() > 0 else sp.zeros(self.nxl()+self.nwl(), 1)
            Mxl = sp.Matrix.vstack(self.A2, self.A6)*sp.Matrix(self.xl())\
            if self.nxl() > 0 else sp.zeros(self.nxl()+self.nwl(), 1)
            Mu = sp.Matrix.vstack(self.D2, self.D6)*self.Gains()*sp.Matrix(self.u)\
            if self.ny() > 0 else sp.zeros(self.nxl()+self.nwl(), 1)
            self.Fl = parallel_factorize(list(Mxl + MdxHnl + Mznl + Mu))\
            if parallelize else list(Mxl + MdxHnl + Mznl + Mu)

            #######################################################################
            if self.isNL:
                print "Root Function"
                time.sleep(.1)
                self.isNL = True
                self.A = sp.Matrix.vstack(self.A4.as_mutable(),\
                                          self.A5.as_mutable())
                hstack1 = sp.Matrix.hstack(self.B4.as_mutable(), self.C4.as_mutable())
                hstack2 = sp.Matrix.hstack(self.B5.as_mutable(), self.C5.as_mutable())
                self.B = sp.Matrix.vstack(hstack1, hstack2)
                self.C = sp.Matrix.vstack(self.D4.as_mutable(), self.D5.as_mutable())
                Mxl = self.A*sp.Matrix(self.xl()) \
                if self.nxl() > 0 else sp.zeros(self.nxnl()+self.nwnl(), 1)
                Mu = self.C*self.Gains()*sp.Matrix(self.u)\
                if self.ny() > 0 else sp.zeros(self.nxnl()+self.nwnl(), 1)
                varNL = sp.Matrix([dxnlm*self.fs for dxnlm in self.dxnl()]+self.wnl())
                FNL = self.B*sp.Matrix(list(self.dxHnl) + self.znl())
                IF = list(varNL - FNL - Mxl - Mu)
                self.ImpFunc = sp.Matrix(parallel_factorize(IF)) if parallelize else sp.Matrix(IF)
                #######################################################################
                print "Jacobian of Implicite Function"
                time.sleep(.1)
                JacFnl = sp.zeros(self.nxnl()+self.nwnl(), self.nxnl()+self.nwnl())
                nlvar = self.dxnl() + self.wnl()
                for n in range(self.nxnl()+self.nwnl()):
                    for m in range(self.nxnl()+self.nwnl()):
                        JacFnl[n, m] = sp.simplify(self.ImpFunc[n, 0].diff(nlvar[m]))
                self.JacFnl = sp.Matrix(JacFnl)
                print "Jacobian inverse"
                time.sleep(.1)
#                self.iJacFnl = SymbolicGaussJordanInverse(sp.Matrix(JacFnl),\
#                SimplifyIn=False, SimplifyOut=True)
                self.iJacFnl = sp.Matrix.inverse_ADJ(self.JacFnl)
                print "\nImplicite Function"
                time.sleep(.1)
                Fnl = list((-self.iJacFnl*sp.Matrix(self.ImpFunc)))
                self.Fnl = sp.Matrix(parallel_factorize(Fnl)) if parallelize else sp.Matrix(Fnl)
                print "Residual Function"
                time.sleep(.1)
                self.Fnl_residual = (sp.Matrix(self.ImpFunc).T*sp.Matrix(self.ImpFunc))[0, 0]
            else:
                self.Fnl = []
                self.Fnl_residual = []
                self.isNL = False
        if ExportCpp:
            print "Export C++ code"
            time.sleep(.1)
            self.writeCppCode()

    def Lambdify(self):
        print "Lambdify"
        time.sleep(.1)
        self.H_n = sp.lambdify(self.x + self.params, self.H, dummify=False, modules="sympy")
        self.z_n = sp.lambdify(self.x + self.w + self.params, self.z,\
        dummify=False, modules="sympy")
        self.y_n = sp.lambdify(self.x + self.dx + self.w + self.u + self.params,\
        list(self.Fy), dummify=False, modules="sympy")
        self.Fl_n = sp.lambdify(self.x + self.dxnl() + self.wnl() + self.u + self.params,\
        list(self.Fl), dummify=False, modules="sympy")
        self.dxH_n = sp.lambdify(self.x + self.dx + self.params, list(self.dxH),\
        dummify=False, modules="sympy")
        self.PDJ_n = sp.lambdify(self.x + self.dx + self.w + self.u + self.params,\
        self.PDJ, dummify=False, modules="sympy")
        if self.isNL:
            iJacFnl_n = []
            for n in range(self.nxnl()+self.nwnl()):
                line = []
                for m in range(self.nxnl()+self.nwnl()):
                    line.append(sp.lambdify((self.dxnl() + self.wnl() + \
                    self.xl() + self.xnl() + self.u + self.params),\
                    self.iJacFnl[n, m], dummify=False, modules="sympy"))
                iJacFnl_n.append(line)
            self.iJacFnl_n = iJacFnl_n
            self.Fnl_n = sp.lambdify(self.dxnl() + self.wnl() + self.x + self.u + self.params,\
            list(self.Fnl), dummify=False, modules="sympy")
            self.Fnl_residual_n = sp.lambdify(self.dxnl() + self.wnl() + self.x\
            +self.u + self.params, self.Fnl_residual, dummify=False, modules="sympy")

#######################################################################

    def simulation(self, fs, seq_u=None, seq_p=None, x0=None, language='py', \
                   constants=None, nt=None, build=True, numtol_dxh=eps, \
                   nbit_NR=100, numtol_NR=1e-12, exec_script=None, \
                   load_options={'decim':1, 'imin':0, 'imax':None}):

        self.fs = fs 
        if seq_u is None:
            assert not nt is None, 'Unknown number of iterations.'
            seq_u = [[]]*nt
            self.nt = nt            
        elif nt is None:
            nt = len(seq_u)
            self.nt = nt
        if build:
            self.Build(fs=fs)

        # languages = 'py' or 'cpp'
        if language == 'c++':
            self.writeCppCode()
            from utils.io import write_all
            write_all(self, seq_u=seq_u, seq_p=seq_p, x0=x0, nt=nt)
            if exec_script is None:
                import os
                print("\no============================================================o\n"); 
                print("Please, execute:\n"+self.folders['cpp']+os.path.sep+"/main.cpp"); 
                print("\no============================================================o\nWaiting....")
                raw_input() 
            elif type(exec_script)is str:
                import subprocess
                print("Build and Run: " + self.label)
                p = subprocess.Popen(exec_script, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                for line in iter(p.stdout.readline, ''): print line,

            from utils.io import load_all
            load_all(self, **load_options)

        if language == 'py':

            Te = fs**(-1)
            self.seq_t = [float(el)/self.fs for el in range(self.nt)]                    

            self.Lambdify()
            #######################################################################
    
            x = [0,]*self.nx() if x0 == None else x0
            dx = [0,]*self.nx()
            w = [0,]*self.nw()
    
            if (seq_p is None) and (constants is not None):
                seq_p=constants*nt
            elif (seq_p is None) and (constants is None):
                seq_p = [[fs],]*nt if self.params.__len__() > 0 else [[],]*nt
    
            self.seq_x = []
            self.seq_x.append(x)
    
            self.seq_dtx = []
            self.seq_dxH = []
    
            self.seq_w = []
            self.seq_z = []
    
            self.seq_y = []
            self.seq_u = seq_u
    
            self.seq_p = seq_p
    
            self.seq_dtE = []
            self.seq_pd = []
            self.SeqH = []
            self.seq_ps = []
    
            nxl = self.nxl()
            nxnl = self.nxnl()
            nwl = self.nwl()

            import progressbar as pb
            widgets = ['Simulation of '+ self.label, pb.Percentage(), ' ', pb.ETA()]
            pbar = pb.ProgressBar(widgets=widgets, maxval=nt).start()    
    
            for k in range(nt):
    
                u = seq_u[k]
                pars = seq_p[k]
    
                dxl = dx[:nxl]
                dxnl = dx[nxl:]
    
                wnl = w[nwl:]
    
                ###################################################################
                
                if self.isNL:
                    VarNL = dxnl + wnl
                    it = 0
                    step = 1
                    res = 1
                    while ((it<nbit_NR) & (res>numtol_NR) & (step>eps**2)):
    #                    VarNL_init = VarNL
                        VarNL = [e1+e2 for (e1,e2) in zip(VarNL, self.Fnl_n(*(VarNL + x + u + pars)))] 
                        it+=1
                        res = self.Fnl_residual_n(*(VarNL + x + u + pars))
    #                    step = np.sqrt(sum([e1-e2 for (e1, e2) in zip(VarNL, VarNL_init)]))
                    dxnl, wnl = VarNL[:nxnl], VarNL[nxnl:]
    
                ###################################################################
                Varl = self.Fl_n(*(x + dxnl + wnl + u + pars))
                dxl, wl = Varl[:nxl], Varl[nxl:]
                ###################################################################
                dx, w = dxl + dxnl, wl + wnl
                ###################################################################
                z = self.z_n(*(x + w + pars))
                dxH = self.dxH_n( *(x + dx + pars) )
                ###################################################################
                y = self.y_n(*(x + dx + w + u + pars))
                ###################################################################
                x = [sum(pair) for pair in zip(x, dx)]
                ###################################################################
                PdInStructure = self.PDJ_n(*(x + dx + w + u + pars))
                ###################################################################            
                self.seq_x.append(x)
                self.seq_dtx.append([e/float(Te) for e in dx])
                self.seq_dxH.append(dxH)
                self.seq_w.append(w)
                self.seq_z.append(z)        
                self.seq_y.append(y)
                self.SeqH.append(self.H_n(*x+pars))
                self.seq_pd.append(sum([e1*e2 for (e1, e2) in zip(z, w)]) +PdInStructure)
                self.seq_ps.append(sum([e1*e2 for (e1, e2) in zip(y, u)]))
                self.seq_dtE.append(sum([e1*e2/float(Te) for (e1, e2) in zip(dxH, dx)]))
                #######################################################################
                self.nt = k
                pbar.update(k+1)
            #######################################################################
            self.seq_x = self.seq_x[:-1]
        
    def writeCppCode(self):
        from utils.phs2cpp import phs2mainfile, phs2cppfile, phs2headerfile
        for fold in ['data', 'cpp']:
            self.folders[fold] = safe_mkdir(self.path, fold)
        phs2cppfile(self)
        phs2headerfile(self)
        phs2mainfile(self)
        
#######################################################################

    def applySubs(self, subs={}):

        self.subs.update(subs)
        self.x = [sp.sympify(el).subs(self.subs) for el in self.x]            
        self.w = [sp.sympify(el).subs(self.subs) for el in self.w]            
        self.z = [sp.sympify(el).subs(self.subs) for el in self.z]            
        self.u = [sp.sympify(el).subs(self.subs) for el in self.u]            
        self.y = [sp.sympify(el).subs(self.subs) for el in self.y]            
        self.diagQ = [sp.sympify(el).subs(self.subs) for el in self.diagQ]            
        self.diagR = [sp.sympify(el).subs(self.subs) for el in self.diagR]            
        self.H = sp.sympify(self.H).subs(self.subs)
        self.J = self.J.subs(self.subs)

        J = self.J
        self.Jx = J[:self.nx(),:self.nx()]
        self.K = -J[:self.nx(),self.nx():self.nx()+self.nw()]    
        self.Gx = J[:self.nx(),self.nx()+self.nw():self.nx()+self.nw()+self.ny()]
        self.Jw = J[self.nx():self.nx()+self.nw(),self.nx():self.nx()+self.nw()]
        self.Gw = J[self.nx():self.nx()+self.nw(),self.nx()+self.nw():self.nx()+self.nw()+self.ny()]
        self.Jy = -J[self.nx()+self.nw():self.nx()+self.nw()+self.ny(),self.nx()+self.nw():self.nx()+self.nw()+self.ny()]        

        self.PDJ = self.PDJ.subs(self.subs)

        self.Fl = [el.subs(self.subs) if type(el)==sp.Expr else el for el in  self.Fl]
        self.Fnl = [el.subs(self.subs) if type(el)==sp.Expr else el for el in  self.Fnl]

        self.dxH = [el.subs(self.subs) if type(el)==sp.Expr else el for el in  self.Fl]
        self.gradH = [el.subs(self.subs) if type(el)==sp.Expr else el for el in  self.Fnl]

        self.params = [el.subs(self.subs) if type(el)==sp.Expr else el for el in self.params]

        for k in self.subs.keys():
            symb = sp.symbols(str(k))
            if symb in self.params:
                self.params.pop(self.params.index(symb))


    def TransferFunction(self, tupin, tupout, nfft=None, filtering=None, limits=None):
        """
        Return frequencies and modulus of transfer function with 
        
            * input s_in = phs.seq_'tupin[0]'['tupin[1]']
            * output s_out = phs.seq_'tupout[0]'['tupout[1]']
        
        Parameters
        ----------
        
        tupin, tupout : (var_label, var_index)
            If tuples, pointer to the phs.seq_'var_label'['var_index'].
            If listes, consider as direct time signas.
            
        fs : float
            Sampling frequency
        
        nfft : int, optional
            Length of the FFT used, if a zero padded FFT is desired. If None, the FFT length is nperseg. Defaults to None.
        
        filtering : float, optional
            If provided, apply a lowpass filter on sigin and sigout before computing fft (the default is None).
            Then filtering is the cutoff frequency as a fraction of the sampling rate (in (0, 0.5)).
    
        limits : (fmin, fmax), optional
            If provided, truncates the output between fmin and fmax (the default is None).
    
        Return
        ------
        
        f : list
            frequency point in Hertz.
    
        TF : list
            Modulus of transfer function.
    
        """
        fs = self.fs
        from numpy import ceil, log2
        nfft = 2**ceil(log2(fs)) if nfft is None else nfft
        sigin = get_sequence(self, tupin)
        sigout = get_sequence(self, tupout)
        from utils.signal import frequencyresponse
        return frequencyresponse(sigin, sigout, fs, nfft=nfft, \
                                filtering=filtering, limits=limits)

    def plot_graph(self):
        from utils.graphs import ShowGraph
        ShowGraph(self)

    def netlist2graph(self, netlistlabel):
        from utils.graphs import build_graph_from_netlist
        return build_graph_from_netlist(self, netlistlabel)

    def graph2phs(self):
        from utils.graphs import buildStructurefromGraph
        return buildStructurefromGraph(self)

    def print_latex(self):
        """
        Print a latex description of the system in 'phs.folder/phs.label.tex' 
        """
        fold = 'tex'
        self.folders[fold] = safe_mkdir(self.path, fold)

        from utils.latex import phs2tex
        str_latex = phs2tex(self)
        file_name = self.label + r".tex"
        import os
        latex_file = open(self.folders['tex']+os.path.sep+file_name, 'w')
        latex_file.write(str_latex)
        latex_file.close()
        
    def plot_powerBal(self, nmin=0, nmax=None, plot_properties={}, multi=False):
        tplot = self.seq_t[nmin: nmax]
        dtEplot = self.seq_dtE[nmin: nmax]
        Pdplot = self.seq_pd[nmin: nmax]
        Psplot = self.seq_ps[nmin: nmax]

        datax = tplot

        if multi:
            datay = list()
            datay.append(dtEplot)
            datay.append(Pdplot)
            datay.append(Psplot)
            datay.append(map(lambda dte, pd, ps: float(dte)+float(pd)-float(ps), dtEplot, Pdplot, Psplot))
            from utils.plots import multiplot
            from utils.plots import plotprops
            pp = plotprops(which='multi')
            import os
            fold = 'plots'
            self.folders[fold] = safe_mkdir(self.path, fold)    
            pp.update({'unitx':'time $t$ (s)',
                             'unity' : [r'Power (W)']*4, 
                             'labels':[r'$\frac{\mathtt{d} \mathrm{E}}{\mathtt{d} t}$',\
                             r'$\mathrm{P_D}$',
                             r'$\mathrm{P_S}$',
                             r'$\frac{\mathtt{d} \mathrm{E}}{\mathtt{d} t}+\mathrm{P_D}-\mathrm{P_S}$'],
                             'filelabel' : self.folders['plots']+os.path.sep+'power_balance', 
                             'maintitle' : r'Power balance', 
                             'loc' : 0})
            pp.update(plot_properties)
            multiplot(datax, datay, **pp)
        else:
            datay = list()
            datay.append(self.seq_dtE[nmin: nmax])
            Psd = map(lambda x,y: float(x)-float(y), self.seq_ps[nmin: nmax], self.seq_pd[nmin: nmax])
            datay.append(Psd)
            from utils.plots import singleplot
            from utils.plots import plotprops
            pp = plotprops(which='single')
            import os
            fold = 'plots'
            self.folders[fold] = safe_mkdir(self.path, fold)
    
            pp.update({'unitx':'time $t$ (s)',
                             'unity' : r'Power (W)', 
                             'labels':[r'$\frac{\mathtt{d} \mathrm{E}}{\mathtt{d} t}$',\
                             r'$\mathrm{P_S}-\mathrm{P_D}$'],
                             'filelabel' : self.folders['plots']+os.path.sep+'power_balance', 
                             'maintitle' : r'Power balance', 
                             'loc' : 0})
            pp.update(plot_properties)
            singleplot(datax, datay, **pp)
#######################################################################
#######################################################################

    def plot_variables(self, var_list, nmin=0, nmax=None, plot_properties={}):
        """
        Plot each phs.seq_'var'['ind'] in var_list = [(var1, ind1), (...)]
        """
        datax = self.seq_t[nmin:nmax]
        datay = list()
        labels = list()

        import os
        fold = 'plots'
        self.folders[fold] = safe_mkdir(self.path, fold)
        filelabel = self.folders['plots']+os.path.sep
        for tup in var_list:
            sig = get_sequence(self, tup)
            datay.append(sig[nmin:nmax])
            labels.append(nice_label(tup[0], tup[1]))
            filelabel += '_'+tup[0]+str(tup[1])
        from utils.plots import plotprops
        pp = plotprops(which='multi')
        pp.update({'unitx':'time $t$ (s)',
                         'unity':labels,
                         'labels':None, 
                         'filelabel':None, 
                         'maintitle':None, 
                         'filelabel' : filelabel, 
                         'limits': 'extend',
                         'log':None})
        pp.update(plot_properties)
        from utils.plots import  multiplot
        multiplot(datax, datay, **pp)

    def __add__(self, phs2):
        return concatenatePHS(self, phs2, label=self.label, path=self.path)
        
def concatenatePHS(phs1, phs2, label=None, path=None):

    label = phs1.label + r'_' + phs2.label if label is None else label
    import os
    path = os.getcwd() if path is None else path

    phs = pHobj(label, path=path)

    if phs1.nxl()+phs2.nxl() >0:
        # get linear storage parts    
        list_xl = list()
        list_q = list()
        for (xl, q) in zip(phs1.xl()+phs2.xl(), phs1.diagQ+phs2.diagQ):
            list_xl.append(str(xl))
            list_q.append(q)
        phs.AddLinearStorageComponents(list_xl, list_q)

    if phs1.nwl()+phs2.nwl() >0:
        # get linear dissipative parts    
        list_wl = list()
        list_r = list()
        for (wl, r) in zip(phs1.wl()+phs2.wl(), phs1.diagR+phs2.diagR):
            list_wl.append(str(wl))
            list_r.append(r)
        phs.AddLinearDissipativeComponents(list_wl, list_r)

    if phs1.nwnl()+phs2.nwnl() >0:
        # get nonlinear dissipative parts    
        list_wnl = list()
        list_znl = list()
        for (wnl, znl) in zip(phs1.wnl()+phs2.wnl(), phs1.znl()+phs2.znl()):
            list_wnl.append(wnl)
            list_znl.append(znl)
        phs.AddNonLinearDissipativeComponents(list_wnl, list_znl)

    if phs1.nxnl()+phs2.nxnl() >0:
        # get nonlinear storage parts    
        H = phs1.H + phs2.H
        Hl = (sp.Matrix(phs1.xl()+phs2.xl()).T*sp.diag(*list_q)*sp.Matrix(phs1.xl()+phs2.xl())/2.)[0,0]
        Hnl = H - Hl
        list_xnl = phs1.xnl() + phs2.xnl()
        phs.AddNonLinearStorageComponents(list_xnl, Hnl)

    if phs1.ny()+phs2.ny() >0:
        # get ports
        list_u = list()
        list_y = list()
        for (u, y) in zip(phs1.u+phs2.u, phs1.y+phs2.y):
            list_u.append(u)
            list_y.append(y)
        phs.AddPorts(list_u, list_y)
    
    phs.diagG = phs1.diagG + phs2.diagG
    phs.params = phs1.params + phs2.params
    phs.trans_u = phs1.trans_u + phs2.trans_u
    phs.trans_y = phs1.trans_y + phs2.trans_y
    phs.transformers = phs1.transformers + phs2.transformers
    phs.subs.update(phs1.subs)
    phs.subs.update(phs2.subs)

    # Get structure
    h1 = sp.Matrix.hstack(phs1.Jx, sp.zeros(phs1.nx(),phs2.nx()))
    h2 = sp.Matrix.hstack(sp.zeros(phs2.nx(),phs1.nx()), phs2.Jx )
    Jx = sp.Matrix.vstack(h1, h2)

    h1 = sp.Matrix.hstack(phs1.K, sp.zeros(phs1.nx(),phs2.nw()))
    h2 = sp.Matrix.hstack(sp.zeros(phs2.nx(),phs1.nw()), phs2.K)
    K = sp.Matrix.vstack(h1, h2)

    h11 = phs1.Gx
    h12 = sp.zeros(phs1.nx(), phs2.ny())
    h21 = sp.zeros(phs2.nx(), phs1.ny())
    h22 = phs2.Gx
    h1 = sp.Matrix.hstack(h11, h12)
    h2 = sp.Matrix.hstack(h21, h22)    

    Gx = sp.Matrix.vstack(h1, h2)

    h1 = sp.Matrix.hstack(phs1.Jw, sp.zeros(phs1.nw(),phs2.nw()))
    h2 = sp.Matrix.hstack(sp.zeros(phs2.nw(),phs1.nw()), phs2.Jw )
    Jw = sp.Matrix.vstack(h1, h2)

    h1 = sp.Matrix.hstack(phs1.Gw, sp.zeros(phs1.nw(),phs2.ny()))
    h2 = sp.Matrix.hstack(sp.zeros(phs2.nw(),phs1.ny()), phs2.Gw)
    Gw = sp.Matrix.vstack(h1, h2)

    h1 = sp.Matrix.hstack(phs1.Jy, sp.zeros(phs1.ny(),phs2.ny()))
    h2 = sp.Matrix.hstack(sp.zeros(phs2.ny(),phs1.ny()), phs2.Jy )
    Jy = sp.Matrix.vstack(h1, h2)

    phs.AddStructure(Jx=Jx, K=K, Gx=Gx, Jw=Jw, Gw=Gw, Jy=Jy)

    phs.Graph.add_edges_from(phs1.Graph.edges(data=True))
    phs.Graph.add_edges_from(phs2.Graph.edges(data=True))
    phs.list_of_edges = phs.Graph.edges(data=True)

    return phs

def selfConnect(phs, inds, u1y2=True):
    for i in inds:
        phs.movePort(i, phs.ny()-1)
    Gconnect = phs.J[:-2, -2:]
    if u1y2:
        switch = sp.Matrix([[0, 1], [-1, 0]])
    else:
        switch = sp.Matrix([[0, -1], [1, 0]])

    phs.J = phs.J[:-2, :-2]+Gconnect*switch*Gconnect.T

    expr_u = switch*Gconnect.T*sp.Matrix(phs.gradH + phs.z + phs.u[:-2])
    for sub in zip(phs.u[-2:], list(expr_u)):
        phs.applySubs({str(sub[0]):sub[1]})

    phs.u = phs.u[:-2]
    phs.y = phs.y[:-2]
    phs.diagG = phs.diagG[:-2]

    phs.Jx = phs.J[:phs.nx(),:phs.nx()]
    phs.K= -phs.J[:phs.nx(),phs.nx():phs.nx()+phs.nw()]    
    phs.Gx = phs.J[:phs.nx(),phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny()]
    phs.Jw = phs.J[phs.nx():phs.nx()+phs.nw(),phs.nx():phs.nx()+phs.nw()]
    phs.Gw = phs.J[phs.nx():phs.nx()+phs.nw(),phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny()]
    phs.Jy = -phs.J[phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny(),phs.nx()+phs.nw():phs.nx()+phs.nw()+phs.ny()]        
    
    for dx in phs.dx:
        phs.applySubs({str(dx):0})

    return phs
    
def get_sequence(phs, tup):
    if isinstance(tup, list):
        sig = tup
    else:
        if isinstance(tup, tuple):            
            var, ind = tup
        else:
            assert isinstance(tup, str), 'Signal label not understood: expected string, got %s' % type(tup)
            var, ind = tup, 0
        sig = eval("[e["+str(ind)+"] for e in phs.seq_"+var+"]")
    return sig

def nice_label(var, ind):
    if var=='dxH':
        return r'$\frac{\partial\mathtt{H}}{\partial x_'+str(ind)+r'}$'
    elif var=='dtx':
        return r'$\frac{\mathrm{d}\,x_'+str(ind)+'}{\mathrm{d}\,t}$'
    else:
        return r'$'+var+'_'+str(ind)+r'$'
        
def safe_mkdir(main_folder, new_folder):    
    import os
    newpath = main_folder + os.path.sep +new_folder
    if not os.path.exists(newpath): 
        os.makedirs(newpath)
    return newpath
    