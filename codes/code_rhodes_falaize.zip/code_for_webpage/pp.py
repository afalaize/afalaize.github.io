# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 22:26:24 2016

@author: Falaize
"""

pp_multiplot = {
'axedef': (0.17, 0.15, 0.95, 0.9, 0.2, 0.3),
 'figsize': (7, 6),
 'fontsize': 25,
 'legendfontsize': None,
 'limits': 'extend',
 'linestyles': ['-b', '--r', ':c'],
 'linewidth': 2,
 'loc': 1,
 'log': None,
 'minor': False,
 'nbinsx': 5,
 'nbinsy': 5,
 'xpos_ylabel': -0.1}
 
pp_singleplot = {'axedef': (0.15, 0.15, 0.75, 0.75),
 'figsize': (7.0, 6.0),
 'linestyles': ['-b', '--r', ':c', '-.g'],
 'linewidth': 2,
 'loc': 1,
 'markeredgewidth': 1,
 'markersize': 8,
 'minor': True,
 'nbinsx': 6,
 'nbinsy': 5}