# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 00:57:23 2015

@author: Falaize
"""
import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
import scipy as sc
from scipy.optimize import minimize as OptiMinimize

eps = np.finfo(float).eps

##############################################################################

def StateSaturatingEnergy(x,c,par,xsat):
    return c*(x**2/2-(8*par*xsat)*( sp.log((sp.cos(((sp.pi*x)/(2*xsat))))) + 0.5*((sp.pi*x)/(2*xsat))**2 )/(sp.pi*(4-sp.pi)) )
#    return c*(x**2/2-(8*p*xsat)*( sp.log(sp.Abs(sp.cos((sp.pi*x)/(2*xsat)))) + 0.5*((sp.pi*x)/(2*xsat))**2 )/(sp.pi*(4-sp.pi)) )

##############################################################################

def ComputeFractionalDerivativeWeights(p, alpha, NbPoles = 50, PolesMinMax = (-5,5),  NbFreqPoints = 2000, FreqMinMax = (10, 30e3), DoPlot = False ):
    beta = 1-alpha
    ##############################################################################
    # Func to approximate
    Tbeta = lambda s: s**(-beta)
    
    ##############################################################################
    # Unpack min and max exponents to define the poles 
    emin , emax = PolesMinMax
    Xi  = np.logspace(emin, emax, NbPoles) # xi_0 -> xi_{N+1}
    
    ##############################################################################
    #Frequency grid
    fmin, fmax = FreqMinMax
    wmin, wmax = 2*np.pi*fmin, 2*np.pi*fmax 
    w = np.exp( np.log(wmin) + np.linspace(0,1,NbFreqPoints+1)*np.log(wmax/wmin) )
    w12 = np.sqrt(w[1:]*w[:-1])
    
    ##############################################################################
    # Return the basis vector of elementary damping with poles Xi
    Basis = lambda s, Xi: (s+Xi)**-1
     
    ##############################################################################
    # Prepare Optim
    M = np.zeros((NbFreqPoints,NbPoles), dtype = np.complex64)
    
    for k in np.arange(NbFreqPoints):
        M[k,:] = Basis(1j*w12[k],Xi)
    
    T = Tbeta(1j*w12)
    
    # Perceptual weights
    WBuildingVector = (np.log(w[1:])-np.log(w[:-1]))/(np.abs(T)**2)
    W = np.diagflat(WBuildingVector)
    
    FuncToMinimize = lambda mu: (np.dot(np.conjugate((np.dot(M,mu) - T).T),np.dot(W,(np.dot(M,mu) - T)))).real
    
    # Constraints
    bnds = [(0,None) for n in np.arange(NbPoles)]
    cstrs = [{'type': 'ineq', 'fun': lambda mu:  mu[n]} for n in np.arange(NbPoles)]
    
    # Optim
    MuOpt = OptiMinimize(FuncToMinimize, np.ones(NbPoles), bounds = bnds)
    
    if DoPlot:
        TOpt = np.array(M*np.matrix(MuOpt.x).T)
        wmin, wmax = 2*np.pi*20, 2*np.pi*20e3
        plt.figure()
        plt.subplot(2,1,1)
        faxis = w12[(wmin<w12)&(w12<wmax)]/(2*np.pi)
        v1 = np.abs(T[(wmin<w12)&(w12<wmax)])
        v2 = np.abs(TOpt[(wmin<w12)&(w12<wmax)])
        v3 = map(lambda x,y: np.abs(x)/np.abs(y),TOpt[(wmin<w12)&(w12<wmax)], T[(wmin<w12)&(w12<wmax)])
        plt.loglog(faxis,v1,label = 'True') 
        plt.loglog(faxis,v2, label = 'Approx')
        plt.ylabel('Transfert (dB)')
        plt.legend(loc = 0)
        plt.grid()        
        plt.subplot(2,1,2)
        plt.loglog(faxis, v3, label = 'Error')
        plt.xlabel('Log-frequencies (log Hz)')
        plt.ylabel('Error (dB)')
        plt.legend(loc = 0)
        plt.grid()        
    diagQ = []
    diagR = []
    Mu = MuOpt.x
    
    for n in np.arange(NbPoles):
        if Mu[n]>0:
            diagR.append(p*Mu[n])
            diagQ.append(p*Mu[n]*Xi[n])
    
    return diagR, diagQ

##############################################################################

class ProgressBar:
    '''
    Progress bar
    '''
    def __init__ (self, valmax, maxbar, title):
        if valmax == 0:  valmax = 1
        if maxbar > 200: maxbar = 200
        self.valmax = valmax
        self.maxbar = maxbar
        self.title  = title
    
    def update(self, val):
        import sys
        # process
        perc  = round((float(val) / float(self.valmax)) * 100)
        scale = 100.0 / float(self.maxbar)
        bar   = int(perc / scale)
  
        # render 
        out = '\r %20s [%s%s] %3d %%' % (self.title, '=' * bar, ' ' * (self.maxbar - bar), perc)
        sys.stdout.write(out)
        sys.stdout.flush()
        

##############################################################################

def SymbolicGaussJordanInverse(OriginalMatrix, dummify=True, SimplifyIn=True, SimplifyOut=True):
    
    print('Simplify In\n')    
    if SimplifyIn:
        OriginalMatrix = parallel_factorize_Mat(OriginalMatrix)
    ##############################################################################
    nl,nc = OriginalMatrix.shape
    if dummify:
        workMat = sp.zeros(nl,nc)    
        bar = ProgressBar(nl**2,10,'Dummify')
        bar.update(0)
        for n in np.arange(nl):
            for m in np.arange(nc):
                symb = 0 if OriginalMatrix[n,m]==0 else sp.symbols('GJI'+str(n)+str(m))
                workMat[n,m] = symb
                bar.update(n*nl+m)
    else:
        workMat = OriginalMatrix
    SymbMatrix = sp.Matrix.hstack(workMat,sp.eye(nl))  
    ##############################################################################
    bar = ProgressBar(nl**2,10,'Inverse')
    bar.update(0)
    ##############################################################################
    for n in np.arange(nl):
        nn = n
        while SymbMatrix[nn:n] == 0:
            nn += 1
        SymbMatrix[n,:], SymbMatrix[nn,:] = SymbMatrix[nn,:], SymbMatrix[n,:]
        Mnn = SymbMatrix[n,n]
        SymbMatrix[n,:] = SymbMatrix[n,:]/Mnn
        a = range(nl)
        a.remove(n)
        for mm in a:
            Mtemp = SymbMatrix[mm,:] - SymbMatrix[mm,n]*SymbMatrix[n,:] if SymbMatrix[mm,n] != 0 else SymbMatrix[mm,:]
            SymbMatrix[mm,:] = parallel_factorize_Mat(Mtemp) if SimplifyOut else Mtemp
            bar.update(n*nl+mm+1)

    iworkMat = SymbMatrix[:,nl:]

    ##############################################################################
#        iworkMat = parallel_factorize_Mat(iworkMat)
    ##############################################################################
    if dummify:
        bar = ProgressBar(nl**2,10,'Un-Dummify')
        bar.update(0)
        for n in np.arange(nl):
            for m in np.arange(nc):
                original = OriginalMatrix[n,m]
                iworkMat = iworkMat.subs(sp.symbols('GJI'+str(n)+str(m)),original)
                bar.update(n*nl+m)
    ##############################################################################
    return iworkMat


    ##############################################################################
    ##############################################################################
    ##############################################################################
    
def SignalGenerator(Type, n, A, f=0, fs=0):
    import scipy.signal as sig
    if Type=='sin':
        return [A*e for e in np.sin(2*np.pi*f*np.linspace(0,float(n)/fs,n))]
    elif Type == 'noise':
        randomVector = np.random.randn(n)
        return [e for e in A*(randomVector/(np.abs(randomVector).max()))]

def MyFFT(s, Fe, nWindow, ola=0.5, DoPlot=True):
    hop = int(ola*nWindow)
    nx = s.__len__()
    N = int((nx-nWindow)/hop)
    listTFs = []
    TFs = [0,]*nWindow
    window = [el for el in sc.hanning(nWindow)]    
    for n in range(N):
        sn = [a*b for (a,b) in zip(s[n*hop:n*hop+nWindow], window)]
        TFn = sc.fft(sn)
        listTFs.append([el for el in TFn])
        TFs = [a+b for (a,b) in zip(TFs, TFn)]
    
    TFs = [20*np.log10(np.abs(el/N)) for el in TFs]
    f = [el for el in np.linspace(0,(nWindow-1)*Fe/nWindow,nWindow)]
    if DoPlot:
        plt.figure()
        plt.plot(f,TFs)
    return f, TFs
        
def MyTransfertfunction(s1,s2,Fe,nfft = 1024,ola = 0.2):
    vf, TF1 = MyFFT(s1,Fe,nfft,ola = ola)
    vf, TF2 = MyFFT(s2,Fe,nfft,ola = ola)
    TF = [a-b for (a, b) in zip(TF1, TF2)]
    nmax = int(nfft/2.)-1
    vf = vf[1:nmax]
    TF = TF[1:nmax]
    plt.figure()
    plt.loglog(vf, TF)
    plt.grid()
    return TF
    


###############################################################################
from matplotlib.ticker import ScalarFormatter, MaxNLocator
from matplotlib.pyplot import figure, plot, xlabel, ylabel, title, suptitle, \
grid, savefig, show, close, xlim, ylim, legend, subplot, subplots, rc, axes, \
subplots_adjust, setp, rcParams
import os
os.environ['PATH'] = os.environ['PATH'] + ':/usr/texbin'
rc('text', usetex=True)



def MyPlot(datax, datay, label, unitx, unity, limits, fontsize=18, \
            legendfontsize=20, linewidth=2, figsize=( 10., 10.), ncol=1, \
            filelabel='figure', maintitle=None, save=True, axedef=[.1,.1,.9,.9], include_seaborn=False, loc=0):
    if include_seaborn:
        import seaborn as sns

    Globalfont = {'family' : 'normal',
                  'weight' : 'normal',
                  'size' : fontsize}
    rc('font', **Globalfont)

    majorformatter = ScalarFormatter(useOffset=False)

    nplots = int(datay.__len__())
    nlign = int(np.ceil(nplots/float(ncol)))
    
    close('all')
    fig, axs = subplots(nlign, ncol, sharex=True, figsize=figsize)

    for n in np.arange(nplots):
#        rcParams['lines.linewidth'] = linewidth
#        rcParams['font.family'] = 'serif'
#        rcParams['font.size'] = fontsize
        x = datax[n]
        y = datay[n]
        l = label[n]
        axs[n].plot(x, y, label=l)
        axs[n].set_xlim([np.min(x),np.max(x)])
        axs[n].xaxis.set_major_formatter(majorformatter)
        axs[n].ticklabel_format(axis='x', style='sci', scilimits=(-2, 2))
        axs[n].yaxis.set_major_formatter(majorformatter)
        axs[n].ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
        axs[n].yaxis.set_major_locator( MaxNLocator(nbins = 4) )
        
        if limits[n] != None :
            axs[n].set_ylim(limits[n])
        else :
            rangey = np.max(y)-np.min(y)
            axs[n].set_ylim([np.min(y)-rangey/20. ,np.max(y)+rangey/20.])
        axs[n].legend(loc=loc,fontsize=legendfontsize)
        axs[n].set_ylabel(unity[n])
        axs[n].grid('on')
        if n==nplots-1:
            axs[n].set_xlabel(unitx[n],fontsize=fontsize)
        else:
            setp(axs[n].get_xticklabels(), visible=False)
    if maintitle != None:
        suptitle(maintitle)
#    fig.tight_layout() # solve overlaping plots
    left  = axedef[0]  # the left side of the subplots of the figure
    right = axedef[2]    # the right side of the subplots of the figure
    bottom = axedef[1]   # the bottom of the subplots of the figure
    top = axedef[3]      # the top of the subplots of the figure
    wspace = axedef[4]   # the amount of width reserved for blank space between subplots
    hspace = axedef[5]   # the amount of height reserved for white space between subplots
    fig.subplots_adjust(left=left, right=right, bottom=bottom, top=top, wspace=wspace, hspace=hspace)   
    if save:    
        savefig(filelabel + '.png')


    
    
def MyPlot2(datax, datay, label, unitx, unity, limits, fontsize=18, \
            legendfontsize=20, linewidth=2, figsize=( 10., 10.), axedef=[.15,.15,.8,.8], \
            filelabel='figure', maintitle=None, save=True, linestyles=['-b',':m','--r','-.g'], loc=0, log=False):
    
    Globalfont = {'family' : 'normal',
                  'weight' : 'normal',
                  'size' : fontsize}
    rc('font', **Globalfont)

    majorformatter = ScalarFormatter(useOffset=False)
    
    close('all')
    fig = figure(1,figsize=figsize)
    nplots = datay.__len__()
    
    ax = axes(axedef[:4])
    for n in np.arange(nplots):
        #ax.set_position(axes_position) 
        ax.xaxis.set_major_formatter(majorformatter)
        ax.ticklabel_format(axis='x', style='sci', scilimits=(-2, 2))
        ax.yaxis.set_major_formatter(majorformatter)
        ax.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))
        ax.yaxis.set_major_locator( MaxNLocator(nbins = 4) )
        x = datax[n]
        y = datay[n]
        l = label[n]
        if log == False:
            ax.plot(x,y,linestyles[n],linewidth=linewidth, label=l)
        elif log == 'x':
            ax.semilogx(x,y,linestyles[n],linewidth=linewidth, label=l)
        elif log == 'y':
            ax.semilogy(x,y,linestyles[n],linewidth=linewidth, label=l)
        elif log == 'xy':
            ax.loglog(x,y,linestyles[n],linewidth=linewidth, label=l)
            
        
        
    ax.set_xlim([np.min(datax[0]),np.max(datax[0])])
    legend(loc=loc,fontsize=legendfontsize)
    grid('on')
    grid(which='minor')
    xlabel(unitx)
    ylabel(unity)
    title(maintitle)
    if save:    
        savefig(filelabel + '.png')
        
## Import multiprocessing
from multiprocessing import Queue, Process
## Put a process in a Queue of processes
def put_factorization_in_queue(q,expr,tup):
    q.put([sp.factor(expr),tup])
## List process, put in queue and start

def parallel_factorize_Mat(Expr_Mat):
    m, n = Expr_Mat.shape
    q = Queue()
    out = sp.zeros(m,n)
    for i in range(m):
        proc = list()
        for j in range(n):
            proc.append(Process(target=put_factorization_in_queue, args=(q,Expr_Mat[i,j],(i,j))))
        for p in proc:
            p.start()                
        for p in proc:
            p.join()
        for nn in range(proc.__len__()):
            el = q.get()
            out[el[1][0],el[1][1]] = el[0]
    return out

def parallel_factorize_List(Expr_list):
    n_list = Expr_list.__len__()
    q = Queue()
    proc = list()
    for i in range(n_list):
        proc.append(Process(target=put_factorization_in_queue, args=(q,Expr_list[i],i)))
    for p in proc:
        p.start()                
    for p in proc:
        p.join()
    out = [0,]*n_list
    for i in range(n_list):
        el = q.get()
        out[el[1]] = el[0]
    return out

