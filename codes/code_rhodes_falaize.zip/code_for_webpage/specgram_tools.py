# -*- coding: utf-8 -*-
"""
Created on Wed Sep 14 15:20:40 2016

@author: Falaize
"""


def plot_specgrams():
    from matplotlib import cm
    from matplotlib.pyplot import setp, rc, plot, xlim, ylim, suptitle, \
    savefig, ylabel, legend, xlabel, close, \
    figure, subplots, subplot, grid, axes

    close('all')
    fig, (ax1, ax2) = subplots(nrows=2, figsize=(8, 5))

    import os
    folder = '/Users/Falaize/Documents/RECHERCHE/LaTex/JSV_Rhodes/CODE_corrected_round_2'
    filename_ref = folder + os.sep + 'REF/REF.wav'
    filename_sim = folder + os.sep + 'all440/allsigs.wav'
    my_specgram(fig, ax1, 'ref', filename_ref)
    my_specgram(fig, ax2, 'simu', filename_sim)


def my_specgram(fig, ax, title, filename, dynamic=100, tlims=None, flims=None):
    if dynamic is not None:
        dynamic = -dynamic
    from scipy.io import wavfile
    import numpy as np
    from matplotlib import cm
    from matplotlib.ticker import ScalarFormatter

    fs, sig = wavfile.read(filename)
    # Calcul du spectrogramme
    t_start = 1
    NFFT = 2**12
    noverlap = int(3*NFFT/4.)
    mode = 'psd'
    values, fbins, tbins, im = ax.specgram(sig[int(fs*t_start):],
                                           mode=mode,
                                           Fs=fs,
                                           NFFT=NFFT,
                                           noverlap=noverlap,
                                           scale='linear')

    values = values/np.max(values)
    extent = [tbins.min(), tbins.max(), fbins.min(), fbins.max()]

    colormap = cm.jet
    im = ax.imshow(10*np.log10(values), extent=extent, origin='lower',
                   aspect='auto', vmin=dynamic, vmax=0, cmap=colormap)
    if flims is None:
        flims = [fbins[0], fbins[-1]]
    if tlims is None:
        tlims = [tbins[0], tbins[-1]]
    ax.set_ylim(flims)
    ax.set_xlim(tlims)

    majorformatter = ScalarFormatter(useOffset=False)
    ax.yaxis.set_major_formatter(majorformatter)
    ax.ticklabel_format(axis='y', style='sci', scilimits=(-2, 2))

    return im, tbins, fbins

if __name__ == "__main__":
    plot_specgrams()
