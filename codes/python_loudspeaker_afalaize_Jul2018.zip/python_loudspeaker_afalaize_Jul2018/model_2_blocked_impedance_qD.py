#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np
import sympy as sy

import os

from pyphs.misc.plots.multiplots import multiplot
from pyphs import Core
from effective_wire_lenght import lc
from effective_wire_turns import np as Np

from pyphs.misc.plots.singleplots import singleplot
from pyphs.misc.signals.analysis import transferFunction
from pyphs.numerics import lambdify

from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import rcParams

from parameters import model2 as m2pars

plots_config = original_plots_config.copy()
plt.close('all')

subs = dict([(phs.Core.symbols(p), m2pars[p]) for p in m2pars])

fmin, fmax = 2e0, 20*1e3

config_signal = {'which': 'sweep',
                 'fs': 96e3,
                 'tsig': 15.,
                 'A': 1e-1,
                 'f0': 0.8*fmin,
                 'f1': 1.1*fmax
                 }

# %%
plt.close('all')
Rc = Core.symbols('Rc')
omegaC = Core.symbols('omegaC')

Nc, qplus, qminus = Core.symbols(['Nc', 'qplus', 'qminus'])
qD = Core.symbols('qD')
NP = Np(qD, Nc, qplus, qminus)

Rec = Core.symbols('Rec')
omegaEC = Core.symbols('omegaEC')

s = sy.symbols('s')

Tr = np.abs(Rc * (1+(s/omegaC)*(1+((NP**2)/(Rc*Rec))*((omegaC)/(s+omegaEC)))))

FTr = lambdify([qD, s], Tr, subs=subs, simplify=True, theano=False)


def plot_targets(freqs, qds, linestyles=None, ax=plt):
    for i, qd in enumerate(qds):
        ax.semilogx(freqs, FTr(qd, 2*1j*np.pi*freqs), linestyles[i], label=r'$q_{\mathrm{D}}='+'{}$'.format(qd))
    ax.legend(loc=0)

plot_targets(2*np.logspace(1, 4), [-0.02, 0, 0.02], linestyles=('-', '--', ':')*4)

#%%

def buil_model_2(case):

    if case == 0:
        QD = -0.02
    elif case == 1:
        QD = 0
    elif case == 2:
        QD = 0.02
    # ----------------------------------------------------------------------- #
    # init core object
    core = phs.Core(label='model_2_case{}'.format(case))

    Plin = core.symbols('Plin')
    Psat = core.symbols('Psat')
    phiSat = core.symbols('phiSat')

    # ----------------------------------------------------------------------- #
    # storage
    x = core.symbols(['xLeak', 'pM', 'qD', 'phiPG'])

    Lleak = core.symbols('Lleak')
    Hleak = x[0]**2/(2*Lleak)

    Mcda = core.symbols('Mcda')
    Hm = x[1]**2/(2*Mcda)

    Ksa = core.symbols('Ksa')
    Hk = Ksa*x[2]**2/2

    from sympy import pi, ln, cos
    phiPG = x[3]
    temp_phi = pi*phiPG/(2*phiSat)
    Hsat = Plin*(phiPG**2/2. -
                 (8*Psat*phiSat/(pi*(4-pi)))*(ln(cos(temp_phi)) + temp_phi**2/2))

    H = Hleak + Hm + Hk + Hsat

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipations
    w = core.symbols(['iC', 'dtqd', 'dtphiPG'])

    Rc = core.symbols('Rc')
    Rsa = core.symbols('Rsa')
    Rec = core.symbols('Rec')

    z = [Rc*w[0], Rsa*w[1], w[2]/Rec]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Port
    u = core.symbols(['vI', 'psiMagnet'])
    y = core.symbols(['iC', 'dtphiP'])

    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # B lc

    Ql, Pl, lc0 = core.symbols(['Ql', 'Pl', 'lc0'])

    Nc, qplus, qminus = core.symbols(['Nc', 'qplus', 'qminus'])
    NP = Np(x[2], Nc, qplus, qminus)

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[ 0,   0,  0,  0],
                  [ 0,   0,  0,  0],
                  [ 0,   0,  0,  0],
                  [ 0,   0,  0,  0]])

    core.set_Jxw([[-1,  0, -NP],
                  [ 0,  0,   0],
                  [ 0,  0,   0],
                  [ 0,  0,   1]])

    core.set_Jxy([[1, 0],
                  [0, 0],
                  [0, 0],
                  [0, 0]])

    core.set_Jwy([[0, 0],
                  [0, 0],
                  [0, -1]])

    # ----------------------------------------------------------------------- #
    # Parameters

    # Update subs values
    subs[Psat] = 0.1
    subs[x[2]] = QD

    # Update core parameters
    core.subs.update(subs)

    return core


def process_simu(simu, subs):
    simu.init_parameters(subs)
    simu.process()
    return simu


def init_simu(core):
    """
    """

    phiSS = core.symbols('phiSS')
    psiM = core.symbols('psiM')
    qD = core.symbols('qD')

    # ----------------------------------------------------------------------- #
    # Signal

    sig = phs.signalgenerator(**config_signal)
    nt = len(sig)

    def u():
        return np.vstack((sig,
                          subs[psiM]*np.ones_like(sig))).T

    # ----------------------------------------------------------------------- #
    # Simulation

    config = {'fs': config_signal['fs'],  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 10,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': True,
              'lang': 'c++'
              }

    simu = core.to_simulation(config=config,
                              inits={'x': [0, 0,
                                           core.subs[qD],
                                           core.subs[phiSS]]})

    simu.init(u=u(), nt=nt)

    # ----------------------------------------------------------------------- #
    # Return transfer function

    return simu

# ----------------------------------------------------------------------- #
core = buil_model_2(0)
simu = init_simu(core)

# %%
xlabel = r'Frequency $f$ (Hz)'
ylabel = r'Impedance ($\Omega$)'

qd_values = list()
ic = list()
vi = list()

for case in range(3):
    core = buil_model_2(case)
    simu = process_simu(simu, core.subs)
    ic.append(simu.data['dxH', :, 0])
    vi.append(simu.data['u', :, 0])
    qd_values.append(simu.method.subs[Core.symbols('qD')])

# %% ----------------------------------------------------------------------- #
nframes = 1e1
nt = len(ic[0])
nfft = 2**12
noverlap = min(nfft/2., int(float(nt-nfft)/nframes) + 1)

datay = list()
print(simu.data.config['fs'], nfft, noverlap)

for i, case in enumerate(range(3)):
    datax, datay_case = transferFunction(ic[i], vi[i],
                                         fs=simu.data.config['fs'],
                                         nfft=nfft, limits=(fmin, fmax),
                                         noverlap=noverlap)

    datay.append(datay_case)

labels = [r'$q_{\mathrm{D}}='+'{}$'.format(qd_value) for qd_value in qd_values]


d = original_plots_config.copy()
figpath = d.pop('path')
linestyles = d.pop('linestyles')

mpl.rcParams.update(d)

plots_config.update({'linestyles': ('-', '--', '-.', ':'),
                     'log': 'x',
                     'format': 'png',
                     })

path = os.path.join(figpath, 'model2_blocked_freq_qd')
plots_config['path'] = path

fig, ax = singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel, labels=labels,
                     **plots_config)

#plot_targets(datax, qd_values, linestyles=('--',)*4, ax=ax)
