#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np
import sympy as sy

import os

from pyphs import Core
from effective_wire_turns import np as Np

from pyphs.misc.plots.singleplots import singleplot
from pyphs.misc.signals.analysis import transferFunction
from pyphs.numerics import lambdify

from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl

from parameters import update_model2
from parameters import model2 as m2pars

plots_config = original_plots_config.copy()
plt.close('all')

fmin, fmax = 2e1, 2*1e4

fs = 96e3

config_signal = {'which': 'sweep',
                 'fs': fs,
                 'tsig': 1.,
                 'A': 1e-1,
                 'f0': fmin,
                 'f1': 1.1*fmax
                 }


# %%

def buil_model_2(case):

    # ----------------------------------------------------------------------- #
    # init core object
    core = phs.Core(label='model_2_case{}'.format(case))

    Plin = core.symbols('Plin')
    Psat = core.symbols('Psat')
    phiSat = core.symbols('phiSat')

    # ----------------------------------------------------------------------- #
    # storage
    x = core.symbols(['xLeak', 'pM', 'qD', 'phiPG'])

    Lleak = core.symbols('Lleak')
    Hleak = x[0]**2/(2*Lleak)

    Mcda = core.symbols('Mcda')
    Hm = x[1]**2/(2*Mcda)

    Ksa = core.symbols('Ksa')
    Hk = Ksa*x[2]**2/2

    from sympy import pi, ln, cos
    phiPG = x[3]
    temp_phi = pi*phiPG/(2*phiSat)
    Hsat = Plin*(phiPG**2/2. -
                 (8*Psat*phiSat/(pi*(4-pi)))*(ln(cos(temp_phi)) +
                                              temp_phi**2/2))

    H = Hleak + Hm + Hk + Hsat

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipations
    w = core.symbols(['iC', 'dtqd', 'dtphiPG'])

    Rc = core.symbols('Rc')
    Rsa = core.symbols('Rsa')
    Rec = core.symbols('Rec')

    z = [Rc*w[0], Rsa*w[1], w[2]/Rec]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Port
    u = core.symbols(['vI', 'psiMagnet'])
    y = core.symbols(['iC', 'dtphiP'])

    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # Parameters

    if case == 0:
        TAUEC = 1e-1
    elif case == 1:
        TAUEC = 1e-2
    elif case == 2:
        TAUEC = 1e-3

    m2pars['tauEC'] = TAUEC
    m2pars[str(Psat)] = 0.1
    m2pars[str(x[2])] = 0.
    update_model2()

    # Update subs values
    subs = dict([(phs.Core.symbols(p), m2pars[p]) for p in m2pars])

    # Update core parameters
    core.subs = subs

    # ----------------------------------------------------------------------- #
    # B lc

    Ql, Pl, lc0 = core.symbols(['Ql', 'Pl', 'lc0'])

    Nc, qplus, qminus = core.symbols(['Nc', 'qplus', 'qminus'])
    NP = Np(x[2], Nc, qplus, qminus)

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[ 0,   0,  0,  0],
                  [ 0,   0,  0,  0],
                  [ 0,   0,  0,  0],
                  [ 0,   0,  0,  0]])

    core.set_Jxw([[-1,  0, -NP],
                  [ 0,  0,   0],
                  [ 0,  0,   0],
                  [ 0,  0,   1]])

    core.set_Jxy([[1, 0],
                  [0, 0],
                  [0, 0],
                  [0, 0]])

    core.set_Jwy([[0, 0],
                  [0, 0],
                  [0, -1]])

    return core


def process_simu(simu):
    simu.process()
    return simu


def build_simu(core, erase=True):
    """
    """

    phiSS = core.symbols('phiSS')
    qD = core.symbols('qD')

    # ----------------------------------------------------------------------- #
    # Simulation

    config = {'fs': fs,  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 10,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': False,
              'lang': 'c++'
              }

    simu = core.to_simulation(config=config,
                              inits={'x': [0, 0,
                                           core.subs[qD],
                                           core.subs[phiSS]]},
                              erase=erase)

    # ----------------------------------------------------------------------- #
    # Return transfer function

    return simu

# %%
# ----------------------------------------------------------------------- #
# Signal

sig = phs.signalgenerator(**config_signal)
u = np.vstack((sig, m2pars['psiM']*np.ones_like(sig))).T
# ----------------------------------------------------------------------- #
# %%
xlabel = r'Frequency $f$ (Hz)'
ylabel = r'Impedance ($\Omega$)'

ic = list()
vi = list()
cases = [0, 1, 2]

nframes = 1e5
nt = len(u)
nfft = 2**10
noverlap = min(nfft/2., int(float(nt-nfft)/nframes) + 1)

datay = list()
par_values = list()

for case in cases:

    # ----------------------------------------------------------------------- #
    #
    core = buil_model_2(case)

    # ----------------------------------------------------------------------- #
    #
    simu = build_simu(core, erase=True)
    simu.init(u=u)

    # ----------------------------------------------------------------------- #
    #
    simu = process_simu(simu)

    # ----------------------------------------------------------------------- #
    #
    v = simu.data['z', :, 2].copy()
    i = (simu.data['w', :, 2].copy() +
         simu.data['dxH', :, 3].copy() +
         simu.data['u', :, 1].copy())

    # simu.data['u', :, 0].copy()
    ic.append(i)
    vi.append(v)

    datax, datay_case = transferFunction(i, v,
                                         fs=fs,
                                         nfft=nfft, limits=(fmin, fmax),
                                         noverlap=noverlap)

    datay.append(datay_case)
    # ----------------------------------------------------------------------- #
    #
    par_values.append(simu.method.subs[Core.symbols('tauEC')])

# %% ----------------------------------------------------------------------- #
labels = [r'$\tau_{\mathrm{EC}}='+'{}$'.format(par_value)
          for par_value in par_values]


d = original_plots_config.copy()
figpath = d.pop('path')
linestyles = d.pop('linestyles')

mpl.rcParams.update(d)

plots_config.update({'linestyles': ('-')*4,  # '--', '-.', ':'),
                     'log': 'x',
                     'format': 'png',
                     })

path = os.path.join(figpath, 'model2_blocked_freq_tauec')
plots_config['path'] = path

fig, ax = singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel, labels=labels,
                     **plots_config)

# plot_targets(datax, qd_values, linestyles=('--',)*4, ax=ax)

Rc = Core.symbols('Rc')
omegaC = Core.symbols('omegaC')

Nc, qplus, qminus = Core.symbols(['Nc', 'qplus', 'qminus'])
qD = Core.symbols('qD')
NP = Np(qD, Nc, qplus, qminus)

Css = Core.symbols('Css')
Rec = Core.symbols('Rec')
omegaEC = Core.symbols('omegaEC')

s = sy.symbols('s')

Tr = np.abs(((NP**2)/(Rec))*((1)/(s+omegaEC)))


def plot_targets(freqs, par_values, linestyles=None, ax=plt):
    for i, par_value in enumerate(par_values):
        subsTr = core.subs.copy()
        subsTr.pop(omegaEC)
        subsTr[Rec] = (omegaEC*subsTr[Css])**-1
        FTr = lambdify([omegaEC, s], Tr.subs(subsTr), simplify=True,
                       theano=False)
        ax.loglog(freqs, FTr((2*np.pi)/par_value, 2*1j*np.pi*freqs),
                    linestyles[i],
                    label=r'$\tau_{\mathrm{EC}}='+'{}$'.format(par_value))
    ax.legend(loc=0)

# plot_targets(datax,  par_values, linestyles=('--',)*40)  # '--', '-.', ':'),)
