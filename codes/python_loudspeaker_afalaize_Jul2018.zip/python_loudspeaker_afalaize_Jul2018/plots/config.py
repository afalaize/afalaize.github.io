#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:43:24 2017

@author: afalaize
"""
import os
from matplotlib import rc_params
rcParams = rc_params()
rcParams['lines.linewidth'] = 2

plots_config = {'path': os.path.join('..',
                                     'AAuA_Loudspeaker_part1_V2',
                                     'figures'),
                'figure.figsize': [4, 4],
                'font.size': 10,
                'legend.fontsize': 'medium',
                'lines.linewidth': 1.5,
                'legend.loc': 'best',
                'axes.grid': True,
                'axes.grid.axis': 'both',
                'axes.grid.which': 'minor',
                'figure.subplot.bottom': 0.11,
                'figure.subplot.hspace': 0.2,
                'figure.subplot.left': 0.125,
                'figure.subplot.right': 0.9,
                'figure.subplot.top': 0.88,
                'figure.subplot.wspace': 0.2,
                }

plots_config_halfsingle = plots_config.copy()
plots_config_halfsingle.update({'figure.figsize': [4, 2],
                            'linestyles': ('-', '--', ':'),
                            'figure.subplot.bottom': 0.24,
                            'figure.subplot.hspace': 0.2,
                            'figure.subplot.left': 0.16,
                            'figure.subplot.right': 0.98,
                            'figure.subplot.top': 0.92,
                            'figure.subplot.wspace': 0.2,
                            'lines.linewidth': 1.5})

plots_config_single = plots_config.copy()
plots_config_single.update({'figure.figsize': [4, 4],
                            'linestyles': ('-', '--', ':'),
                            'figure.subplot.bottom': 0.15,
                            'figure.subplot.hspace': 0.2,
                            'figure.subplot.left': 0.19,
                            'figure.subplot.right': 0.98,
                            'figure.subplot.top': 0.93,
                            'figure.subplot.wspace': 0.2,
                            'lines.linewidth': 1.5})

plots_config_double = plots_config.copy()
plots_config_double.update({'figure.figsize': [2, 2],
                            'linestyles': ('-', '--', ':'),
                            'figure.subplot.bottom': 0.24,
                            'figure.subplot.hspace': 0.2,
                            'figure.subplot.left': 0.27,
                            'figure.subplot.right': 0.98,
                            'figure.subplot.top': 0.93,
                            'figure.subplot.wspace': 0.2,
                            'lines.linewidth': 1.5})

plots_config_model0 = plots_config.copy()
plots_config_model0.update({'figure.figsize': [4, 6],
                            'linestyles': [('-', '--', ':'), ]*6,
                            'figure.subplot.bottom': 0.08,
                            'figure.subplot.hspace': 0.35,
                            'figure.subplot.left': 0.19,
                            'figure.subplot.right': 0.98,
                            'figure.subplot.top': 0.96,
                            'figure.subplot.wspace': 0.2,
                            'lines.linewidth': 1.5,
                            'loc': 2})
