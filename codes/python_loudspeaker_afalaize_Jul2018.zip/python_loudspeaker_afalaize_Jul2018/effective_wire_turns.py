#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 10:52:38 2017

@author: afalaize
"""
# ---------------------------------------------------------------------------- #
import os

import sympy as sy
import numpy

from pyphs.misc.plots.singleplots import singleplot

from plots.config import plots_config_halfsingle as original_plots_config
import matplotlib as mpl
import matplotlib.pyplot as plt

from parameters import pars_model2

# ---------------------------------------------------------------------------- #

plots_config = original_plots_config.copy()

plt.close('all')

# ---------------------------------------------------------------------------- #

def np(qd, Nc, qplus, qminus):
    return Nc*(1 + sy.exp((4*qd - 2*(qplus + qminus))/(qplus - qminus)))**-1

# ---------------------------------------------------------------------------- #

if __name__ == '__main__':

    d = original_plots_config.copy()
    figpath = d.pop('path')
    linestyles = d.pop('linestyles')
    mpl.rcParams.update(d)

    # ------------------------------------------------------------------------ #
    q = sy.symbols('q')

    #sy.plot(lc(q, LC0, PL, QL), (q, -0.02, 0.02))

    # ------------------------------------------------------------------------ #
    # x axis

    datax = numpy.linspace(-1e-2, 1e-2, 200)
    xlabel = r'Position $q_{\mathrm{D}}$ (m)             '
    plots_config['xlabel'] = xlabel

    # ------------------------------------------------------------------------ #
    # qminuss

    qminuss = (-1e-3, -5e-3, -1e-2)

    datay = [[np(q, pars_model2['Nc'], pars_model2['qplus'], qm).subs(q, x).evalf() for x in datax]
             for qm in qminuss]

    ylabel = r'$n_{\mathrm{P}}(q_{\mathrm{D}})$ (d.u.)'
    plots_config['ylabel'] = ylabel

    labels = [r'$q_{-}='+r'{0}$'.format(ql) for ql in qminuss]
    plots_config['labels'] = labels

    path = os.path.join(original_plots_config['path'], 'np')

    plots_config['path'] = path
    plots_config['grid'] = original_plots_config['axes.grid']

    singleplot(datax, datay, **plots_config)

