#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 10:52:38 2017

@author: afalaize
"""
# ---------------------------------------------------------------------------- #
import os

import sympy as sy
import numpy as np

from pyphs.misc.plots.singleplots import singleplot

from plots.config import plots_config_double as original_plots_config
import matplotlib as mpl
import matplotlib.pyplot as plt

from parameters import model0 as m0pars

# ---------------------------------------------------------------------------- #

plots_config = original_plots_config.copy()

plt.close('all')

# ---------------------------------------------------------------------------- #

def lc(qd, lc0, Pl, Ql):
    return lc0*(1+sy.exp(-Pl))/(1+sy.exp(Pl*((qd/Ql)**2-1)))

# ---------------------------------------------------------------------------- #

if __name__ == '__main__':

    d = original_plots_config.copy()
    figpath = d.pop('path')
    linestyles = d.pop('linestyles')
    mpl.rcParams.update(d)

    # ------------------------------------------------------------------------ #
    q = sy.symbols('q')

    #sy.plot(lc(q, LC0, PL, QL), (q, -0.02, 0.02))

    # ------------------------------------------------------------------------ #
    # x axis

    datax = np.linspace(-1e-2, 1e-2, 200)
    xlabel = r'Position $q_{\mathrm{D}}$ (m)             '
    plots_config['xlabel'] = xlabel

    # ------------------------------------------------------------------------ #
    # overhang

    Qls = (8e-3, 4e-3, 1e-3)

    datay = [[lc(q, m0pars['lc0'], m0pars['Pl'], ql).subs(q, x).evalf() for x in datax]
             for ql in Qls]

    ylabel = r'$\ell_{\mathrm{C}}(q_{\mathrm{D}})$ (m)'
    plots_config['ylabel'] = ylabel

    labels = [r'$Q_\ell={0}$'.format(ql) for ql in Qls]
    plots_config['labels'] = labels

    path = os.path.join(original_plots_config['path'], 'overhang')

    plots_config['path'] = path

    singleplot(datax, datay, **plots_config)

    # ------------------------------------------------------------------------ #
    # shape

    Pls = (10, 1, 0)

    datay = [[lc(q, m0pars['lc0'], pl, m0pars['Ql']).subs(q, x).evalf() for x in datax]
             for pl in Pls]
    ylabel = r'$\ell_{\mathrm{C}}(q_{\mathrm{D}})$ (m)'
    plots_config['ylabel'] = ylabel

    labels = [r'$P_\ell={0}$'.format(pl) for pl in Pls]
    plots_config['labels'] = labels

    path = os.path.join(original_plots_config['path'], 'shape')
    plots_config['path'] = path

    singleplot(datax, datay, **plots_config)
