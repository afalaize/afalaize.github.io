#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np
import sympy as sy

import os

from pyphs.misc.plots.multiplots import multiplot

from effective_wire_lenght import lc
from effective_wire_turns import np as Np

from plots.config import plots_config_model0 as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl

from parameters import model2 as m2pars

plots_config = original_plots_config.copy()
plt.close('all')

subs = dict([(phs.Core.symbols(p), m2pars[p]) for p in m2pars])


def simulation_model_2(*pars):

    # ----------------------------------------------------------------------- #
    # init core object
    core = phs.Core(label='model_2')

    Plin = core.symbols('Plin')
    Psat = core.symbols('Psat')
    phiSat = core.symbols('phiSat')

    subs[Psat] = pars[0]

    # ----------------------------------------------------------------------- #
    # storage
    x = core.symbols(['xLeak', 'pM', 'qD', 'phiPG'])

    Lleak = core.symbols('Lleak')
    Hleak = x[0]**2/(2*Lleak)

    Mcda = core.symbols('Mcda')
    Hm = x[1]**2/(2*Mcda)

    Ksa = core.symbols('Ksa')
    Hk = Ksa*x[2]**2/2

    from sympy import pi, ln, cos
    phiPG = x[3]
    temp_q = pi*phiPG/(2*phiSat)
    Hsat = Plin*(phiPG**2/2. -
                 (8*Psat*phiSat/(pi*(4-pi)))*(ln(cos(temp_q)) + temp_q**2/2))

    H = Hleak + Hm + Hk + Hsat

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipations
    w = core.symbols(['iC', 'dtqd', 'dtphiPG'])

    Rc = core.symbols('Rc')
    Rsa = core.symbols('Rsa')
    Rec = core.symbols('Rec')

    z = [Rc*w[0], Rsa*w[1], w[2]/Rec]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Port
    u = core.symbols(['vI', 'psiMagnet'])
    y = core.symbols(['iC', 'dtphiP'])

    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # B lc

    Sg = core.symbols('Sg')
    B = phiPG/Sg

    Ql, Pl, lc0 = core.symbols(['Ql', 'Pl', 'lc0'])
    BL = B*lc(x[2], lc0, Pl, Ql)

    Nc, qplus, qminus = core.symbols(['Nc', 'qplus', 'qminus'])
    NP = Np(x[2], Nc, qplus, qminus)

    phiSS = core.symbols('phiSS')
    psiM = core.symbols('psiM')

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[ 0, -BL, -1,  0],
                  [BL,   0,  0,  0],
                  [ 1,   0,  0,  0],
                  [ 0,   0,  0,  0]])

    core.set_Jxw([[-1,  0, -NP],
                  [ 0, -1,   0],
                  [ 0,  0,   0],
                  [ 0,  0,   1]])

    core.set_Jxy([[1, 0],
                  [0, 0],
                  [0, 0],
                  [0, 0]])

    core.set_Jwy([[0, 0],
                  [0, 0],
                  [0, -1]])

    # ----------------------------------------------------------------------- #
    # Parameters

    # Update Psat value
    #subs[core.symbols('Psat')] = Psat_value

    # Update core parameters
    core.subs.update(subs)

    # ----------------------------------------------------------------------- #
    # Signal

    config_signal = {'fs': 96e3,
                     'tsig': 1e-1,
                     'tdeb': 0,
                     'tend': 0,
                     'f0': 100.,
                     'A': 50.,
                     'attack_ratio': 1.
                     }

    sig = list(phs.signalgenerator(which='sin', **config_signal)())
    nt = len(sig)

    def u():
        for u_elt in sig:
            yield np.array([u_elt, subs[psiM]])

    config = {'fs': config_signal['fs'],  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 10,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': True,
              'lang': 'c++'
              }

    simu = core.to_simulation(config=config, inits={'x': [0, 0, 0, subs[phiSS]]})

    simu.init(u=u(), nt=nt)

    simu.process()

    datax = list(simu.data.t())

    vI = simu.data['u', :, 0]
    xLeak = simu.data['x', :, 0]
    pM = simu.data['x', :, 1]
    qD = simu.data['x', :, 2]
    phiPG = simu.data['x', :, 3]

    if isinstance(BL.subs(subs), (float, int, sy.Float, sy.Integer)):
        BL_value = BL.subs(subs)

        def BL_lambda(x):
            return BL_value*np.ones(x.shape)

    else:
        BL_lambda = phs.numerics.lambdify(x, BL, subs=subs,
                                          simplify=True, theano=False)

    Bl = np.array(list(map(lambda x: BL_lambda(*x), simu.data.x())))
    Ps = simu.data.ps()
    Pd = simu.data.pd()
    Psd = np.array(list(map(sum, zip(Ps, Pd))))
    dtE = simu.data.dtE(vslice=0, postprocess=lambda el: -el)

    datay = [vI, xLeak, pM, qD, phiPG, Bl, (dtE, Psd)]

    return datax, datay


if __name__ == '__main__':

    values = [0.1, 0.]
    all_datay = list()

    for p in values:
        datax, datay_p = simulation_model_2(p)
        all_datay.append(datay_p)

    datay = all_datay[0]

    datay[1:-1] = list(zip(*[el[1:-1] for el in all_datay]))
    labels = [None, ]+[[r'$P_\mathrm{sat}^\mathrm{s}'+r'={}$'.format(e) for e in values]]*5 + [(r'$-\frac{\delta \mathrm{E}}{\delta t}$',
                                                                      r'$\mathrm{P_S}+\mathrm{P_D}$')]
    plots_config['labels'] = labels

    ylabels = [r'$v_{\mathrm{I}}$ (V)',
               r'$x_{\mathrm{leak}}$ (Web)',
               r'$p_{\mathrm{M}}$ (kg.m/s)',
               r'$q_{\mathrm{D}}$ (m)',
               r'$\phi_{\mathrm{PG}}$ (Web)',
               r'$B\,\ell_{\mathrm{C}}$ (T.m)',
               'Power (W)']

    plots_config['xlabel'] = r'Time $t$ (s)'
    plots_config['ylabels'] = ylabels

    d = original_plots_config.copy()
    figpath = d.pop('path')
    loc = d.pop('loc')
    linestyles = d.pop('linestyles')
    linestyles.append(linestyles[-1])
    plots_config['linestyles'] = linestyles
    mpl.rcParams.update(d)

    path = os.path.join(figpath, 'simu_model1')
    plots_config['path'] = path
    plots_config['grid'] = original_plots_config['axes.grid']

    fig, axs = multiplot(datax, datay, **plots_config)
