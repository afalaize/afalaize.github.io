#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np
from pyphs.misc.plots.singleplots import singleplot
from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import os

from parameters import model1 as m1pars
from parameters import update_model1
import matplotlib as mpl

plots_config = original_plots_config.copy()
plt.close('all')


def simulation(tau1_value=1, PK_value=0.5):

    # ----------------------------------------------------------------------- #
    # Core

    core = phs.Core(label='model_1_submeca')

    # ----------------------------------------------------------------------- #
    # Storage

    x = core.symbols(['pM', 'q0', 'q1'])

    Mcda = core.symbols('Mcda')
    Hm = x[0]**2/(2*Mcda)

    K0 = core.symbols('K0')
    H0 = K0*x[1]**2/2

    K1 = core.symbols('K1')
    H1 = K1*x[2]**2/2

    H = Hm + H0 + H1

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipation

    w = core.symbols(['dtqd', 'fR1'])

    Rsa = core.symbols('Rsa')
    R1 = core.symbols('R1')

    z = [Rsa*w[0], w[1]/R1]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Ports

    y, u = core.symbols(['vD', 'fL'])
    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # observer for qD

    qD_symb = core.symbols('qD')
    qD_expr = x[1] + x[2]

    core.add_observer({qD_symb: qD_expr})

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[0, -1, 0],
                  [1, 0, 0],
                  [0,  0,  0]])

    core.set_Jxw([[1, 0],
                  [0, 1],
                  [0, -1]])

    core.set_Jxy([[1],
                  [0],
                  [0]])

    # ----------------------------------------------------------------------- #
    # Parameters

    # Update values
    m1pars['t1'] = tau1_value
    m1pars['Pk'] = PK_value

    update_model1()

    # Update core parameters
    subs = dict([(phs.Core.symbols(p), m1pars[p]) for p in m1pars])
    core.subs.update(subs)

    config_signal = {'which': 'const',
                     'fs': 48e3,
                     'tsig': 2.,
                     'tdeb': 0.5,
                     'tend': 2.5,
                     'A': 5.,
                     }

    sig = phs.signalgenerator(**config_signal)
    nt = len(sig)

    u = sig[:, np.newaxis]
    config = {'fs': config_signal['fs'],  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 10,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': False,
              'lang': 'c++'
              }

    simu = core.to_simulation(config=config)

    simu.init(u=u, nt=nt)

    simu.process()

    tslice = slice(0, nt, int(nt/500.))

    datax = [e-0.5 for e in simu.data.t(tslice=tslice)]

    qD = simu.data['o', tslice, 0]

    return datax, qD


xlabel = r'Time $t$ (s)'
ylabel = r'Displacement $q_{\mathrm{D}}$ (m)'


tau1_values = [1e-9, 1e-1, 1e0, 1e1]


labels = [r'$\tau_1={}$'.format(tau1_value) for tau1_value in [0] + tau1_values[1:]]

datay = list()

for tau1_value in tau1_values:
    datax, dy = simulation(tau1_value=tau1_value)
    datay.append(dy)


#%%
d = original_plots_config.copy()
figpath = d.pop('path')


d.pop('linestyles')
mpl.rcParams.update(d)

plots_config.update({'linestyles': ('-', '--', ':', '-.'),
                     })

path = os.path.join(figpath, 'submeca_time_t1')
plots_config['path'] = path

singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel, labels=labels,
           **plots_config)

plt.grid('on')
