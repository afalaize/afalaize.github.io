#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 12 11:21:46 2018

@author: afalaize
"""

import pyphs as phs
from effective_wire_turns import np as Np
from effective_wire_lenght import lc
from parameters import pars_model2, update_pars_model2
import numpy as np


def build_model_2(subs_update={}, label=None):
    """
    Return the pyphs.core associated with loudspeaker model 2.
    """
    if label is None:
        label = 'model2'
    else:
        label = 'model2_{}'.format(label)

    # ----------------------------------------------------------------------- #
    # init core object
    core = phs.Core(label='model2')

    Plin = core.symbols('Plin')
    Psat = core.symbols('Psat')
    phiSat = core.symbols('phiSat')

    # ----------------------------------------------------------------------- #
    # storage
    x = core.symbols(['xLeak', 'pM', 'qD', 'phiPG'])

    Lleak = core.symbols('Lleak')
    Hleak = x[0]**2/(2*Lleak)

    Mcda = core.symbols('Mcda')
    Hm = x[1]**2/(2*Mcda)

    Ksa = core.symbols('Ksa')
    Hk = Ksa*x[2]**2/2

    from sympy import pi, ln, cos
    phiPG = x[3]
    temp_phi = pi*phiPG/(2*phiSat)
    Hsat = Plin*(phiPG**2/2. -
                 (8*Psat*phiSat/(pi*(4-pi)))*(ln(cos(temp_phi)) +
                                              temp_phi**2/2))

    H = Hleak + Hm + Hk + Hsat

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipations
    w = core.symbols(['iC', 'dtqd', 'dtphiPG'])

    Rc = core.symbols('Rc')
    Rsa = core.symbols('Rsa')
    Rec = core.symbols('Rec')

    z = [Rc*w[0], Rsa*w[1], w[2]/Rec]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Port
    u = core.symbols(['vI', 'psiMagnet'])
    y = core.symbols(['iC', 'dtphiP'])

    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # B lc

    Ql, Pl, lc0 = core.symbols(['Ql', 'Pl', 'lc0'])
    LC = lc(x[2], lc0, Pl, Ql)

    Nc, qplus, qminus = core.symbols(['Nc', 'qplus', 'qminus'])
    NP = Np(x[2], Nc, qplus, qminus)

    BL = LC*phiPG/core.symbols('Sg')

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[ 0, -BL, -1,  0],
                  [BL,   0,  0,  0],
                  [ 1,   0,  0,  0],
                  [ 0,   0,  0,  0]])

    core.set_Jxw([[-1,  0, -NP],
                  [ 0, -1,   0],
                  [ 0,  0,   0],
                  [ 0,  0,   1]])

    core.set_Jxy([[1, 0],
                  [0, 0],
                  [0, 0],
                  [0, 0]])

    core.set_Jwy([[0, 0],
                  [0, 0],
                  [0, -1]])

    # ----------------------------------------------------------------------- #
    # Parameters
    # ----------------------------------------------------------------------- #
    # Parameters

    pars_model2.update(subs_update)
    update_pars_model2()

    # Update subs values
    subs = dict([(phs.Core.symbols(str(p)), pars_model2[p])
                 for p in pars_model2])

    # Update core parameters
    core.subs.update(subs)

    return core
