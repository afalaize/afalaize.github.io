#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np

from pyphs.misc.plots.singleplots import singleplot
from pyphs.misc.signals.analysis import transferFunction


from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl

import os

# Define the path to this file
here = os.path.realpath(__file__)[:os.path.realpath(__file__).rfind(os.sep)]

from parameters import model1 as m1pars
from parameters import update_model1

plots_config = original_plots_config.copy()
plt.close('all')


def simulation(tau1_value=1, PK_value=0.5):

    # ----------------------------------------------------------------------- #
    # Core

    core = phs.Core(label='model_1_submeca')

    # ----------------------------------------------------------------------- #
    # Storage

    x = core.symbols(['pM', 'q0', 'q1'])

    Mcda = core.symbols('Mcda')
    Hm = x[0]**2/(2*Mcda)

    K0 = core.symbols('K0')
    H0 = K0*x[1]**2/2

    K1 = core.symbols('K1')
    H1 = K1*x[2]**2/2

    H = Hm + H0 + H1

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipation

    w = core.symbols(['dtqd', 'fR1'])

    Rsa = core.symbols('Rsa')
    R1 = core.symbols('R1')

    z = [Rsa*w[0], w[1]/R1]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Ports

    y, u = core.symbols(['vD', 'fL'])
    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # observer for qD

    qD_symb = core.symbols('qD')
    qD_expr = x[1] + x[2]

    core.add_observer({qD_symb: qD_expr})

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[0, -1, 0],
                  [1, 0, 0],
                  [0,  0,  0]])

    core.set_Jxw([[1, 0],
                  [0, 1],
                  [0, -1]])

    core.set_Jxy([[1],
                  [0],
                  [0]])

    # ----------------------------------------------------------------------- #
    # Parameters

    # Update values
    m1pars['t1'] = tau1_value
    m1pars['Pk'] = PK_value

    update_model1()

    # Update core parameters
    subs = dict([(phs.Core.symbols(p), m1pars[p]) for p in m1pars])
    core.subs.update(subs)

    # ----------------------------------------------------------------------- #
    # Signal

    config_signal = {'which': 'noise',
                     'fs': 1e3,
                     'tsig': 100.,
                     'A': 5.,
                     }

    sig = list(phs.signalgenerator(**config_signal)())
    nt = len(sig)

    def u():
        for u_elt in sig:
            yield np.array([u_elt, ])

    # ----------------------------------------------------------------------- #
    # Simulation

    config = {'fs': config_signal['fs'],  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 10,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': True,
              'lang': 'c++'
              }

    simu = core.to_simulation(config=config)

    simu.init(u=u(), nt=nt)

    simu.process()

    # ----------------------------------------------------------------------- #
    # Return transfer function

    fL = simu.data['u', :, 0]
    qD = simu.data['o', :, 0]

    return transferFunction(fL, qD, fs=config['fs'],
                            nfft=2**15, limits=(2e-2, 2e2))

# ----------------------------------------------------------------------- #

xlabel = r'Frequency $f$ (Hz)'
ylabel = r'Compliance (N.m$^{-1}$)'


tau1_values = [1e-9, 1e-1, 1e0, 1e1]


labels = [r'$\tau_1={}$'.format(tau1_value) for tau1_value in [0] + tau1_values[1:]]

datay = list()

for tau1_value in tau1_values:
    datax, dy = simulation(tau1_value=tau1_value)
    datay.append(dy)


#%%
d = original_plots_config.copy()
figpath = d.pop('path')
linestyles = d.pop('linestyles')

mpl.rcParams.update(d)

plots_config.update({'linestyles': ('-', '--', ':', '-.'),
                     'log': 'xy',
                     })

path = os.path.join(figpath, 'submeca_freq_t1')
plots_config['path'] = path


singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel, labels=labels,
           **plots_config)
