#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np
import sympy as sy

import os

from pyphs.misc.plots.multiplots import multiplot

from effective_wire_lenght import lc

from plots.config import plots_config_model0 as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl

from parameters import model1 as m1pars

plots_config = original_plots_config.copy()
plt.close('all')

subs = dict([(phs.Core.symbols(p), m1pars[p]) for p in m1pars])


def simulation_model_1(Psat_value):

    # ----------------------------------------------------------------------- #
    # init core object
    core = phs.Core(label='model_1')

    # ----------------------------------------------------------------------- #
    # storage
    x = core.symbols(['phiC', 'pM', 'q1', 'q0'])

    Lc = core.symbols('Lc')
    Hphi = x[0]**2/(2*Lc)

    Mcda = core.symbols('Mcda')
    Hm = x[1]**2/(2*Mcda)

    K0, K1 = core.symbols('K:2')

    H1 = K1*x[2]**2/2

    Psat = core.symbols('Psat')
    qsat = core.symbols('qsat')

    from sympy import pi, ln, cos
    q0 = x[3]
    temp_q = pi*q0/(2*qsat)
    Hsat = K0*(q0**2/2. -
               (8*Psat*qsat/(pi*(4-pi)))*(ln(cos(temp_q)) + temp_q**2/2))

    H = Hphi + Hm + H1 + Hsat

    core.add_storages(x, H)

    # ----------------------------------------------------------------------- #
    # Dissipations
    w = core.symbols(['iC', 'dtqd', 'fR1'])

    Rc = core.symbols('Rc')
    Rsa = core.symbols('Rsa')
    R1 = core.symbols('R1')

    z = [Rc*w[0], Rsa*w[1], w[2]/R1]

    core.add_dissipations(w, z)

    # ----------------------------------------------------------------------- #
    # Port
    y, u = core.symbols(['iC', 'vI'])

    core.add_ports(u, y)

    # ----------------------------------------------------------------------- #
    # observer for qD

    qD_symb = core.symbols('qD')
    qD_expr = x[2] + x[3]

    core.add_observer({qD_symb: qD_expr})

    # ----------------------------------------------------------------------- #
    # B lc

    B = core.symbols('B')
    Ql, Pl, lc0 = core.symbols(['Ql', 'Pl', 'lc0'])

    BL = B*lc(qD_symb, lc0, Pl, Ql)

    # ----------------------------------------------------------------------- #
    # Structure

    core.set_Jxx([[ 0, -BL,  0,  0],
                  [BL,   0,  0, -1],
                  [ 0,   0,  0,  0],
                  [ 0,   1,  0,  0]])

    core.set_Jxw([[1, 0,  0],
                  [0, 1,  0],
                  [0, 0,  1],
                  [0, 0, -1]])

    core.set_Jxy([[1],
                  [0],
                  [0],
                  [0]])

    # ----------------------------------------------------------------------- #
    # Parameters

    # Update Psat value
    subs[core.symbols('Psat')] = Psat_value

    # Update core parameters
    core.subs.update(subs)

    # ----------------------------------------------------------------------- #
    # Signal

    config_signal = {'fs': 96e3,
                     'tsig': 1e-1,
                     'tdeb': 0,
                     'tend': 0,
                     'f0': 100.,
                     'A': 50.,
                     'attack_ratio': 1.
                     }

    sig = phs.signalgenerator(which='sin', **config_signal)

    u = sig[:, np.newaxis]

    config = {'fs': config_signal['fs'],  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 10,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': True,
              'lang': 'c++'
              }

    simu = core.to_simulation(config=config)

    simu.init(u=u)

    simu.process()

    datax = list(simu.data.t())

    vI = simu.data['u', :, 0]
    phiC = simu.data['x', :, 0]
    pM = simu.data['x', :, 1]
    qD = simu.data['o', :, 0]

    print(simu.data.args_o().shape)
    if isinstance(BL.subs(subs), (float, int, sy.Float, sy.Integer)):
        BL_value = BL.subs(subs)

        def BL_lambda(x):
            return BL_value*np.ones(x.shape)

    else:
        BL_lambda = phs.numerics.lambdify([qD_symb, ], BL, subs=subs,
                                          simplify=True, theano=False)

    Bl = simu.data.x(vslice=3, postprocess=BL_lambda)
    Ps = simu.data.ps()
    Pd = simu.data.pd()
    Psd = np.array(list(map(sum, zip(Ps, Pd))))
    dtE = simu.data.dtE(vslice=0, postprocess=lambda el: -el)

    datay = [vI, phiC, pM, qD, Bl, (dtE, Psd)]

    return datax, datay


#%%
if __name__ == '__main__':

    values = [0.1, 0.]
    all_datay = list()

    for p in values:
        datax, datay_p = simulation_model_1(p)
        all_datay.append(datay_p)

    datay = all_datay[0]

    datay[1:-1] = list(zip(*[el[1:-1] for el in all_datay]))
    labels = [None, ]+[[r'$P_\mathrm{sat}^\mathrm{s}'+r'={}$'.format(e) for e in values]]*4 + [(r'$-\frac{\delta \mathrm{E}}{\delta t}$',
                                                                      r'$\mathrm{P_S}+\mathrm{P_D}$')]
    plots_config['labels'] = labels

#%%
    ylabels = [r'$v_{\mathrm{I}}$ (V)',
               r'$\phi_{\mathrm{C}}$ (Wb)',
               r'$p_{\mathrm{M}}$ (kg.m/s)',
               r'$q_{\mathrm{D}}$ (m)',
               r'$B\,\ell_{\mathrm{C}}$ (T.m)',
               'Power (W)']

    plots_config['xlabel'] = r'Time $t$ (s)'

    plots_config['ylabels'] = ylabels

    d = original_plots_config.copy()
    figpath = d.pop('path')
    loc = d.pop('loc')
    linestyles = d.pop('linestyles')
    mpl.rcParams.update(d)

    path = os.path.join(figpath, 'simu_model1')
    plots_config['path'] = path
    plots_config['grid'] = original_plots_config['axes.grid']

    fig, axs = multiplot(datax, datay, **plots_config)
