#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 12 11:36:19 2018

@author: afalaize
"""


import pyphs as phs
from model2_blocked import build_model_2

from pyphs.misc.plots.singleplots import singleplot
from pyphs.misc.plots.tools import annotate
from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl


import numpy as np
import os

fs = 96e3
dur = 2e-1
tdeb = dur/10.
VccModul = 50.

cases = {0: {'tauEC': 1e-1,
             'Vcc': VccModul},
         1: {'tauEC': 1e-2,
             'Vcc': VccModul},
         2: {'tauEC': 1e-3,
             'Vcc': VccModul},
         3: {'tauEC': 1e-1,
             'Vcc': -VccModul},
         4: {'tauEC': 1e-2,
             'Vcc': -VccModul},
         5: {'tauEC': 1e-3,
             'Vcc': -VccModul}}

plt.close('all')

# %%

def input_voltage(amp=50):
    pars_sig = {'which': 'const',
                'tsig': dur,
                'A': amp,
                'tdeb': tdeb,
                'tend': 0.,
                'fs': fs,
                'attack_ratio': 0.001
                }
    return phs.signalgenerator(**pars_sig)


def input_all(VccValue, psiM):
    u = input_voltage(amp=VccValue)
    return np.vstack((u, psiM*np.ones_like(u))).T


def init_simulation(core, u, inits=None):

    phiSS = core.symbols('phiSS')
    config = {'fs': fs,
              'maxit': 50,
              'lang': 'c++',
              'pbar': True}

    nx = core.dims.x()
    xinit = np.zeros(nx)
    index = core.index('x', 'phiPG')
    xinit[index] = core.subs[phiSS]
    if inits is None:
        inits = {'x': list(xinit)}
    simu = core.to_simulation(config=config, inits=inits)

    simu.init(u=u)

    return simu

# %%

if __name__ == '__main__':

    Vcc = phs.Core.symbols('Vcc')
    psiM = phs.Core.symbols('psiM')

    all_phi = list()
    all_v = list()
    all_x = list()
    pars = list()
    for case in range(6):
        subs = cases[case]
        core = build_model_2(subs)
        u = input_all(core.subs[Vcc], core.subs[psiM])
        simu = init_simulation(core, u)
        simu.process()
        t = simu.data.t()
        all_v.append(simu.data['y', :, 0])
        all_phi.append(simu.data['x', :, 3])
        all_x.append(simu.data['x'])
        pars.append(core.subs[core.symbols('tauEC')])

    # %%

    labels = [r'$\tau_{\mathrm{P}}='+'{}$'.format(tauEC)
              for tauEC in pars]

    datay = list()
    for i, par in enumerate(pars):
        datay.append(all_phi[i]/core.subs[core.symbols('phiSS')])

    datax = t - tdeb
    # %%

    d = original_plots_config.copy()

    figpath = d.pop('path')
    figpath = '../AAuA_Loudspeaker_part1_V2/figures'
    linestyles = d.pop('linestyles')
    mpl.rcParams.update(d)

    plots_config = original_plots_config.copy()
    plots_config['linestyles'] = ('-C0', '--C1', ':C2')*2

    path = os.path.join(figpath, 'blocked_time_tauEC')
#    plots_config['path'] = path
    plots_config['path'] = None

    xlabel = r'Time $t$ (s)'
    ylabel = r'$\phi_{\mathrm{PG}}(t)/\phi_{\mathrm{SS}}$'

    fig, ax = singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel,
                         labels=labels[:3], **plots_config)

    annotate(r'$V_{\mathrm{cc}}=+50$V', (0.8, 0.85), ax)
    annotate(r'$V_{\mathrm{cc}}=-50$V', (0.8, 0.15), ax)
    plt.savefig(path+'.png')

    # %%
    from pyphs.numerics import lambdify
    expr = core.hessH()[-1, -1]**-1
    f = lambdify([core.x[-1], ], expr.subs(core.subs))
    eva = core.to_evaluation(names=['dxH', ])
    index = simu.method.index('x', core.symbols('phiPG'))

    datay = list()
    #plt.close('all')
    plt.figure()
    def func(x):
        return f(x)

    vec_func = np.vectorize(func)

    mpl.rcParams.update(d)

    plots_config = original_plots_config.copy()
    plots_config['linestyles'] = ('--', 'o', 'x')

    path = os.path.join(figpath, 'psiPG')
    plots_config['path'] = None

    xlabel = r'$\phi_{\mathrm{PG}}/\phi_{\mathrm{SS}}$ (d.u.)'
    ylabel = r'$\psi_{\mathrm{PG}}/C_{\mathrm{SS}}$ (d.u.)'

    datax = np.linspace(0.9*core.subs[core.symbols('phiSS')],
                        1.1*core.subs[core.symbols('phiSS')],
                        200)

    dx = (datax[1:] - datax[:-1])
    datay = vec_func(datax)
    ddatay = np.diff(datay)
    fig, ax = singleplot(datax[:-1]/core.subs[core.symbols('phiSS')],
                         ddatay/dx/func(core.subs[core.symbols('phiSS')]), xlabel=xlabel, ylabel=ylabel,
                         **plots_config)

    phi = all_x[0][-1, index]
    plt.plot(phi/core.subs[core.symbols('phiSS')],
             func(phi)/func(core.subs[core.symbols('Css')]), '^',
             label = '$V_{cc}=+50V$')


    phi = core.subs[core.symbols('phiSS')]
    plt.plot(phi/core.subs[core.symbols('phiSS')],
             func(phi)/func(core.subs[core.symbols('phiSS')]), 'o',
             label = '$V_{cc}=  0V$')

    phi = all_x[-1][-1, index]
    plt.plot(phi/core.subs[core.symbols('phiSS')],
             func(phi)/func(core.subs[core.symbols('phiSS')]), 'v',
             label = '$V_{cc}=-50V$')

    ax.legend(loc=0)