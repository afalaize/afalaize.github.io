#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 20:39:56 2018

@author: afalaize
"""

from numpy import pi, cos, tan

# --------------------------------------------------------------------------- #
# Parameters for model 0

model0 = {'lc0': 10.,               # coil wire length (m)
          'Rc':  10.,               # coil wire resistance (Ohms)
          'Lc': 3e-4,               # coil self inductance (H)
          'Mcda': 1e-2,             # Total moving mass (kg)
          'Ksa': 2e3,               # Total stiffness (N/m)
          'Rsa': 1.,                # Damping (N.s/m)
          'B': 0.5,                 # Magnetic induction (T)
          'Ql': 5e-3,               # overhang parameter (m)
          'Pl': 1.,                 # shape parameter (d.u)
          }

# --------------------------------------------------------------------------- #
# Parameters for model 1

model1 = {'Pk': 0.8,
          't1': 1.,
          'qsat': 1e-2,
          'Psat': 1.}

model1.update(model0)


def update_model1():
    model1['K0'] = model1['Ksa']/(1.-model1['Pk'])
    model1['K1'] = model1['Ksa']/model1['Pk']
    model1['w1'] = 2*pi/model1['t1']
    model1['R1'] = model1['K1']/model1['w1']

update_model1()


# --------------------------------------------------------------------------- #
# Parameters for model 2

pars_model2 = {'qplus': 2e-2,
               'qminus': -1e-3,
               'Nc': 100,
               'Ac': 2e-2,
               'Dc': 2e-2,
               'tauEC': 1e-4,
               'ellP': 5e-1,
               'phiSat': 0.8e-3,
               'Psat': 1e4,
               'mu0': 4*pi*1e-7,
               'xiAir': 3.6*1e-7
               }

pars_model2.update(model0)


def psiM(phiSS, phiSat, Plin, Psat):
    """
    Compute the magnet mmf.

    Parameters
    ----------

    phiSS : steady state magnetic flux in the pole piece

    phiSat : Magnetic flux at ferromagnetic saturation in the pole piece

    Plin : Linear behavior of ferromagnetic constitutive law (around origin)

    Psat : Shape parameter for ferromagnetic constitutive law

    """
    temp = (pi*phiSS)/(2*phiSat)
    return -Plin*(phiSS + ((4*Psat)/(4-pi))*(tan(temp)-temp))


def pLin(phiSS, phiSat, Css, Psat):
    """
    Compute the parameter Plin associated with linear behavior of ferromagnetic
    constitutive law (around origin).

    Parameters
    ----------

    phiSS : steady state magnetic flux in the pole piece

    phiSat : Magnetic flux at ferromagnetic saturation in the pole piece

    Css : Linear capacitance of ferromagnetic at steady state

    Psat : Shape parameter for ferromagnetic constitutive law

    """
    return (pi-4)*phiSat / \
        (Css * (2*pi*Psat*(1-cos(pi*phiSS/(2*phiSat))**-2) + (pi-4)*phiSat))


def update_pars_model2():
    pars_model2['Sg'] = pi*pars_model2['Dc']*pars_model2['Ac']
    pars_model2['Sp'] = pars_model2['Sg']
    alpha = 0.2
    pars_model2['Sleak'] = pi*pars_model2['Dc']**2*(2*alpha-alpha**2)/4.
    pars_model2['Cleak'] = (pars_model2['Sleak']*pars_model2['mu0']*(1+pars_model2['xiAir']))/(2*pars_model2['Ac'])
    pars_model2['Lleak'] = pars_model2['Nc']**2*pars_model2['Cleak']
    pars_model2['omegaC'] = pars_model2['Rc']/pars_model2['Lleak']
    pars_model2['tauC'] = 2*pi/pars_model2['omegaC']
    pars_model2['omegaEC'] = 2*pi/pars_model2['tauEC']
    pars_model2['Lp'] = pars_model2['Lc'] - pars_model2['Lleak']
    pars_model2['Css'] = pars_model2['Lp']/(pars_model2['Nc']**2)
    pars_model2['Rec'] = (pars_model2['omegaEC']*pars_model2['Css'])**-1
    pars_model2['phiSS'] = pars_model2['B']*pars_model2['Sp']

    pars_model2['Plin'] = pLin(pars_model2['phiSS'],
                               pars_model2['phiSat'],
                               pars_model2['Css'],
                               pars_model2['Psat'])

    pars_model2['psiM'] = psiM(pars_model2['phiSS'],
                               pars_model2['phiSat'],
                               pars_model2['Plin'],
                               pars_model2['Psat'])

update_pars_model2()
