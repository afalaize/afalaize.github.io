#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 12 23:07:10 2018

@author: afalaize
"""


import pyphs as phs
from model2 import build_model_2

from pyphs.misc.plots.singleplots import singleplot
from plots.config import plots_config as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl


import numpy as np
import os

fs = 96e3
dur = 1e-1

VccModul = 50.

cases = {0: {'tauEC': 1e-1,
             'Vcc': VccModul},
         1: {'tauEC': 1e-2,
             'Vcc': VccModul},
         2: {'tauEC': 1e-3,
             'Vcc': VccModul},
         3: {'tauEC': 1e-1,
             'Vcc': -VccModul},
         4: {'tauEC': 1e-2,
             'Vcc': -VccModul},
         5: {'tauEC': 1e-3,
             'Vcc': -VccModul}}

plt.close('all')
# %%
plt.close('all')
styles = ('r+', 'bx', 'g.')*2
nx = 200
def rms(sig):
    #square
    square = sig**2
    mean = sum(square)/nx
    root = mean**0.5
    return root

for P in [1e-3, 1e-2, 5e-2]:
    print(P)
    core = build_model_2({'Psat': P})
    eva = core.to_evaluation(names=['dxH', ])
    index = core.index('x', core.symbols('phiPG'))

    def func(x):
        temp_x = np.zeros(4)
        temp_x[index] = x
        return eva.dxH(*temp_x)[index]

    vec_func = np.vectorize(func)
    xplot = np.linspace(0,
                        0.7*core.subs[core.symbols('phiSat')],
                        nx)
    plt.plot(xplot, vec_func(xplot),
             label='$P_{\mathrm{sat}}=' + '{}$'.format(P))
plt.plot(core.subs[core.symbols('phiSS')],
         func(core.subs[core.symbols('phiSS')]), 'o')

plt.legend(loc=0)
