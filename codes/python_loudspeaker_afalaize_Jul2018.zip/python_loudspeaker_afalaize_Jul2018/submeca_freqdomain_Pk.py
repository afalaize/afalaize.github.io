#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np

from pyphs.misc.plots.singleplots import singleplot
from pyphs.misc.signals.analysis import transferFunction


from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl

import os

# Define the path to this file
here = os.path.realpath(__file__)[:os.path.realpath(__file__).rfind(os.sep)]

from parameters import model1 as m1pars
from parameters import update_model1

from submeca_freqdomain_t1 import simulation

plots_config = original_plots_config.copy()
plt.close('all')


# ----------------------------------------------------------------------- #

xlabel = r'Frequency $f$ (Hz)'
ylabel = r'Compliance (N.m$^{-1}$)'


Pk_values = [0.1, 0.5, 0.9]


labels = [r'$P_K={}$'.format(PK_value) for PK_value in Pk_values]

datay = list()

for PK_value in Pk_values:
    datax, dy = simulation(PK_value=PK_value)
    datay.append(dy)


#%%
d = original_plots_config.copy()
figpath = d.pop('path')
linestyles = d.pop('linestyles')
loc = d.pop('loc')

mpl.rcParams.update(d)

plots_config.update({'linestyles': ('-', '--', ':', '-.'),
                     'log': 'xy',
                     'loc': loc
                     })

path = os.path.join(figpath, 'submeca_freq_pK')
plots_config['path'] = path


singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel, labels=labels,
           **plots_config)
