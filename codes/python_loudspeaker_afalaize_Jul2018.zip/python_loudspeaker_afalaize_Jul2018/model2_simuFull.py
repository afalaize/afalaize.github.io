#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 11:42:52 2017

@author: afalaize
"""

import pyphs as phs
import numpy as np
import sympy as sy

import os

from pyphs.misc.plots.multiplots import multiplot

from effective_wire_lenght import lc

from model2 import build_model_2

from plots.config import plots_config_model0 as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl

from parameters import model1 as m1pars

from model_0 import simulation_model_0

plots_config = original_plots_config.copy()
plt.close('all')

subs = dict([(phs.Core.symbols(p), m1pars[p]) for p in m1pars])

fs = 96e3


def input_all(psiM):
    config_signal = {'fs': fs,
                     'tsig': 1e-1,
                     'tdeb': 0,
                     'tend': 0,
                     'f0': 100.,
                     'A': 50.,
                     'attack_ratio': 1.
                     }

    u = phs.signalgenerator(**config_signal)

    return np.vstack((u, psiM*np.ones_like(u))).T


def simu_model2():
    # ----------------------------------------------------------------------- #
    # init core object
    core = build_model_2()

    # ----------------------------------------------------------------------- #
    # Signal
    u = input_all(core.subs[core.symbols('psiM')])

    config = {'fs': fs,  # Sample rate (Hz)
              'grad': 'discret',  # In {'discret', 'theta', 'trapez'}
              'theta': 0.,  # Theta-scheme for the structure
              'split': True,  # split implicit from explicit part
              'maxit': 50,  # Max number of iterations for NL solvers
              'eps': 1e-10,  # Global numerical tolerance
              'pbar': True,
              'lang': 'c++'
              }

    # ----------------------------------------------------------------------- #
    # Simu

    simu = core.to_simulation(config=config)

    simu.init(u=u, inits={'x': [0, 0, 0, core.subs[core.symbols('phiSS')]]})

    simu.process()

    datax = simu.data.t()

    # ----------------------------------------------------------------------- #
    # Data

    vI = simu.data['u', :, 0]
    iC = simu.data['y', :, 0]
    pM = simu.data['x', :, 1]
    qD = simu.data['x', :, 2]
    phiPG = simu.data['x', :, 3]

    Ps = simu.data.ps()
    Pd = simu.data.pd()
    Psd = np.array(list(map(sum, zip(Ps, Pd))))
    dtE = simu.data.dtE(vslice=0, postprocess=lambda el: -el)

    func_lc = phs.numerics.lambdify([core.symbols('qD'), ],
                                    lc(core.symbols('qD'),
                                        core.subs[core.symbols('lc0')],
                                        core.subs[core.symbols('Pl')],
                                        core.subs[core.symbols('Ql')]),
                                    theano=False)

    Bl = func_lc(qD)*phiPG/core.subs[core.symbols('Sg')]

    datay = [vI, iC, pM, qD, Bl, (dtE, Psd)]

    return datax, datay

# ----------------------------------------------------------------------- #
# %% Simu

all_datay = list()

model2_x, model2_y = simu_model2()

all_datay.append(model2_y)

model0_x, model0_y = simulation_model_0(0)

all_datay.append(model0_y)

# %% Simu

datay = all_datay[0]

datay[1:-1] = list(zip(*[el[1:-1] for el in all_datay]))

labels = [None, ]+[(r'model 2', r'TS')]*4 + [(r'$-\frac{\delta \mathrm{E}}{\delta t}$',
                                     r'$\mathrm{P_S}+\mathrm{P_D}$')]
plots_config['labels'] = labels

ylabels = [r'$v_{\mathrm{I}}$ (V)',
           r'$i_{\mathrm{C}}$ (A)',
           r'$p_{\mathrm{M}}$ (kg.m/s)',
           r'$q_{\mathrm{D}}$ (m)',
           r'$B\ell$ (T.m)',
           'Power (W)']

plots_config['xlabel'] = r'Time $t$ (s)'

plots_config['ylabels'] = ylabels

d = original_plots_config.copy()
figpath = d.pop('path')
loc = d.pop('loc')
linestyles = d.pop('linestyles')
mpl.rcParams.update(d)

path = os.path.join(figpath, 'simu_model2')
plots_config['path'] = path
plots_config['grid'] = original_plots_config['axes.grid']

fig, axs = multiplot(model2_x, datay, **plots_config)
