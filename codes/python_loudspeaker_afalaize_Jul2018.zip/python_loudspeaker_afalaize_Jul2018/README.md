This folder contains the Python code used to generate all the figures of the paper 

Antoine Falaize & Thomas Hélie, Passive modelling of the electrodynamic loudspeaker: from the Thiele-Small model to nonlinear Port-Hamiltonian Systems, submitted to Acta-Acustica united with Acustica on Saturday the 21st of Audust 2018.

The prerequisites are 
    - a workning installation of Python 3.5 or above (see e.g. https://www.anaconda.com/distribution/)
    - the PyPHS package version 0.4 or above (see https://pyphs.github.io/pyphs/)



