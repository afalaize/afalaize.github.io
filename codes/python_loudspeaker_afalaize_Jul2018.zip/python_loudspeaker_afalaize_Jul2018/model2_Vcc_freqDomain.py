#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 12 11:36:19 2018

@author: afalaize
"""

import pyphs as phs
from model2_blocked import build_model_2

from pyphs.misc.plots.singleplots import singleplot
from plots.config import plots_config_single as original_plots_config
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import os
from pyphs.misc.signals.analysis import transferFunction
from model2_tauEC_timeDomain import init_simulation


fs = 96e3
dur = 1e-1
tdeb = dur/5.
VccModul = 50.

fmin, fmax = 2e0, 2*1e4

cases = {0: {'Vcc': VccModul},
         1: {'Vcc': 0.},
         2: {'Vcc': -VccModul},
         }

plt.close('all')


def input_all_trans(VccValue, psiM):
    config_signal = {'which': 'zero',
                     'fs': fs,
                     'tsig': 0.3,
                     'offset': VccValue
                     }
    u = phs.signalgenerator(**config_signal)

    return np.vstack((u, psiM*np.ones_like(u))).T


def input_all_noise(VccValue, psiM):
    config_signal = {'which': 'noise',
                     'fs': fs,
                     'tsig': 2.,
                     'A': 1e-1,
                     'offset': VccValue
                     }

    u = phs.signalgenerator(**config_signal)

    return np.vstack((u, psiM*np.ones_like(u))).T


if __name__ == '__main__':

    Vcc = phs.Core.symbols('Vcc')
    psiM = phs.Core.symbols('psiM')

    all_phi = list()
    all_v = list()
    all_i = list()
    all_x = list()
    pars = list()

    for case in cases:

        subs = cases[case]
        core = build_model_2(subs)
        pars.append(core.subs[Vcc])

        u = input_all_trans(core.subs[Vcc], core.subs[psiM])
        simu = init_simulation(core, u)
        simu.process()

        inits = {'x': simu.data['x', len(u)-1, :][0]}

        u = input_all_noise(core.subs[Vcc], core.subs[psiM])
        simu = init_simulation(core, u, inits)
        simu.process()

        all_v.append(simu.data['u', :, 0])
        all_i.append(simu.data['y', :, 0])
        all_x.append(simu.data['x'])

    t = simu.data.t()
    labels = [r'$V_{\mathrm{cc}}='+'{}$'.format(vcc)
              for vcc in pars]

    # %% ----------------------------------------------------------------------
    nframes = 1e1

    nt = len(all_v[0])
    nfft = 2**12
    noverlap = min(nfft/2., int(float(nt-nfft)/nframes) + 1)

    datay = list()

    for i, p in enumerate(pars):
        datax, datay_case = transferFunction(all_i[i], all_v[i],
                                             fs=simu.data.config['fs'],
                                             nfft=nfft, limits=(fmin, fmax),
                                             noverlap=noverlap)

        datay.append(datay_case)

    d = original_plots_config.copy()
    figpath = d.pop('path')
    linestyles = d.pop('linestyles')

    mpl.rcParams.update(d)

    plots_config = original_plots_config.copy()
    plots_config.update({'linestyles': ('-', '--', '-.', ':'),
                         'log': 'x',
                         'format': 'png',
                         })
    xlabel = r'Frequency $f$ (Hz)'
    ylabel = r'Impedance ($\Omega$)'

    path = os.path.join(figpath, 'model2_blocked_freq_vcc')
    plots_config['path'] = path

    fig, ax = singleplot(datax, datay, xlabel=xlabel, ylabel=ylabel, labels=labels,
                         **plots_config)
